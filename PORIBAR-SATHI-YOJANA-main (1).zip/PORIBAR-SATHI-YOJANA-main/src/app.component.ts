import { Component, ChangeDetectionStrategy, signal, effect, computed, inject } from '@angular/core';
import { HomeComponent } from './components/home/home.component';
import { ImageEditorComponent } from './components/image-editor/image-editor.component';
import { SubsidyStoreComponent } from './components/subsidy-store/subsidy-store.component';
import { HealthServicesComponent } from './components/health-services/health-services.component';
import { EducationComponent } from './components/education/education.component';
import { PsyBenefitsComponent } from './components/psy-benefits/psy-benefits.component';
import { ApplyPsyComponent, ApplicationData } from './components/apply-psy/apply-psy.component';
import { WalletComponent } from './components/wallet/wallet.component';
import { AdminPanelComponent } from './components/admin-panel/admin-panel.component';
import { OfficerPanelComponent } from './components/officer-panel/officer-panel.component';
import { LoginComponent, User as OfficialUser } from './components/login/login.component';
import { OfficerManagementComponent } from './components/officer-management/officer-management.component';
import { PublicRegistrationComponent } from './components/public-registration/public-registration.component';
import { ViewRegistrationsComponent } from './components/view-registrations/view-registrations.component';
import { ViewAllRegistrationsComponent } from './components/view-all-registrations/view-all-registrations.component';
import { ChangePasswordComponent, PasswordChangeEvent as AdminPasswordChangeEvent } from './components/change-password/change-password.component';
import { BannerManagementComponent, Banner } from './components/banner-management/banner-management.component';
import { PublicLoginComponent } from './components/public-login/public-login.component';
import { PublicPanelComponent } from './components/public-panel/public-panel.component';
import { WalletManagementComponent, WalletUpdateEvent } from './components/wallet-management/wallet-management.component';
import { TransactionDetailModalComponent } from './components/transaction-detail-modal/transaction-detail-modal.component';
import { UserManagementComponent } from './components/user-management/user-management.component';
import { DailyReportsComponent, DailyReportSubmission } from './components/daily-reports/daily-reports.component';
import { OfficerIdCardComponent } from './components/officer-id-card/officer-id-card.component';
import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { PsyCardComponent } from './components/psy-card/psy-card.component';
import { ProductManagementComponent } from './components/product-management/product-management.component';
import { CategoryManagementComponent } from './components/category-management/category-management.component';
import { OrderManagementComponent } from './components/order-management/order-management.component';
import { PurchaseHistoryComponent } from './components/purchase-history/purchase-history.component';
import { LogoManagementComponent } from './components/logo-management/logo-management.component';
import { RoleManagementComponent } from './components/role-management/role-management.component';
import { LevelManagementComponent, OfficerLevel } from './components/level-management/level-management.component';
import { IncentiveReportComponent } from './components/incentive-report/incentive-report.component';
import { MyTeamComponent } from './components/my-team/my-team.component';
import { BmiCalculatorComponent } from './components/bmi-calculator/bmi-calculator.component';
import { AiHealthGuideComponent } from './components/ai-health-guide/ai-health-guide.component';
import { AiNutritionScannerComponent } from './components/ai-nutrition-scanner/ai-nutrition-scanner.component';
import { SarkariSevaComponent } from './components/sarkari-seva/sarkari-seva.component';
import { SarkariSevaFinderComponent } from './components/sarkari-seva-finder/sarkari-seva-finder.component';
import { WithdrawalManagementComponent } from './components/withdrawal-management/withdrawal-management.component';
import { P2pTransferComponent } from './components/p2p-transfer/p2p-transfer.component';
import { TopUpComponent } from './components/top-up/top-up.component';
import { TopUpManagementComponent } from './components/top-up-management/top-up-management.component';
import { QrCodeManagementComponent } from './components/qr-code-management/qr-code-management.component';
import { QrScannerComponent } from './components/qr-scanner/qr-scanner.component';
import { ApplicationManagementComponent } from './components/application-management/application-management.component';
import { CardOrderManagementComponent } from './components/card-order-management/card-order-management.component';
import { TermsManagementComponent } from './components/terms-management/terms-management.component';
import { HealthTipsComponent, HealthArticle } from './components/health-tips/health-tips.component';
import { ArticleManagementComponent } from './components/article-management/article-management.component';
import { FindSchoolsComponent } from './components/find-schools/find-schools.component';
import { ScholarshipsComponent, Scholarship } from './components/scholarships/scholarships.component';
import { OnlineCoursesComponent, OnlineCourse } from './components/online-courses/online-courses.component';
import { ScholarshipManagementComponent } from './components/scholarship-management/scholarship-management.component';
import { CourseManagementComponent } from './components/course-management/course-management.component';
import { LanguageService } from './services/language.service';
import { TranslatePipe } from './pipes/translate.pipe';
import { ExamResultsComponent, ExamLink } from './components/exam-results/exam-results.component';
import { ExamLinkManagementComponent } from './components/exam-link-management/exam-link-management.component';
import { DistanceEducationComponent } from './components/distance-education/distance-education.component';
import { CareerCounselingComponent } from './components/career-counseling/career-counseling.component';
import { EducationLeadsManagementComponent } from './components/education-leads-management/education-leads-management.component';
import { SkillDevelopmentComponent, UserSkillEnrollment } from './components/skill-development/skill-development.component';
import { SkillProgramManagementComponent, SkillProgram } from './components/skill-program-management/skill-program-management.component';
import { ViewCertificateComponent } from './components/view-certificate/view-certificate.component';
import { DoctorManagementComponent } from './components/doctor-management/doctor-management.component';
import { HospitalManagementComponent } from './components/hospital-management/hospital-management.component';
import { AppointmentManagementComponent } from './components/appointment-management/appointment-management.component';
import { BookAppointmentComponent } from './components/book-appointment/book-appointment.component';
import { FindHospitalsComponent } from './components/find-hospitals/find-hospitals.component';
import { VideoConsultationComponent } from './components/video-consultation/video-consultation.component';
import { ViewHealthRecordsComponent } from './components/view-health-records/view-health-records.component';
import { MyAppointmentsComponent } from './components/my-appointments/my-appointments.component';
import { AiSymptomCheckerComponent } from './components/ai-symptom-checker/ai-symptom-checker.component';
import { NewsComponent } from './components/news/news.component';
import { NewsManagementComponent } from './components/news-management/news-management.component';
import { IdCardManagementComponent } from './components/id-card-management/id-card-management.component';
import { ComplaintBoxComponent, Complaint } from './components/complaint-box/complaint-box.component';
import { ComplaintManagementComponent } from './components/complaint-management/complaint-management.component';
import { GameComponent } from './components/game/game.component';
import { GameManagementComponent } from './components/game-management/game-management.component';
import { PopupMessageComponent, PopupMessage } from './components/popup-message/popup-message.component';
import { PopupManagementComponent } from './components/popup-management/popup-management.component';
import { SchemeSettingsComponent } from './components/scheme-settings/scheme-settings.component';
import { CoinPriceManagementComponent } from './components/coin-price-management/coin-price-management.component';
import { UserChangePasswordComponent, UserPasswordChangeEvent } from './components/user-change-password/user-change-password.component';
import { ForgotPasswordComponent, PasswordResetEvent } from './components/forgot-password/forgot-password.component';
import { AiAssistantComponent } from './components/ai-assistant/ai-assistant.component';
import { ServicesComponent } from './components/services/services.component';
import { ServiceManagementComponent } from './components/service-management/service-management.component';
import { AdvertisementManagementComponent, Advertisement } from './components/advertisement-management/advertisement-management.component';


export const ALL_PERMISSIONS = [
    'is_officer',
    'register_public_user',
    'view_own_registrations',
    'submit_daily_reports',
    'is_admin',
    'manage_officers',
    'manage_roles',
    'manage_users',
    'manage_wallets',
    'manage_top_ups',
    'manage_qr_code',
    'view_all_registrations',
    'manage_banners',
    'manage_advertisements',
    'manage_products',
    'manage_categories',
    'manage_orders',
    'manage_logo',
    'manage_id_card_assets',
    'manage_level_titles',
    'view_incentive_reports',
    'manage_applications',
    'manage_card_orders',
    'manage_articles',
    'manage_scholarships',
    'manage_courses',
    'manage_exam_links',
    'manage_education_leads',
    'manage_skill_programs',
    'manage_doctors',
    'manage_hospitals',
    'manage_appointments',
    'manage_news',
    'manage_game_url',
    'manage_complaints',
    'manage_popup_message',
    'manage_scheme_settings',
    'manage_coin_price',
    'manage_external_services'
] as const;
export type Permission = typeof ALL_PERMISSIONS[number];

export interface Role {
  id: string;
  name: string;
  permissions: Permission[];
}

export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  originalPrice: number;
  imageUrl: string;
  description: string;
}

export interface Category {
    id: number;
    name: string;
}

export interface Order {
    id: string;
    userId: string;
    productId: number;
    productName: string;
    productImageUrl: string;
    pricePaid: number;
    orderDate: string;
    status: 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
    courierName?: string;
    trackingNumber?: string;
}

export interface Transaction {
  id: string;
  description: string;
  date: string;
  amount: number; // positive for credit, negative for debit
  type: 'credit' | 'debit';
  wallet: 'main' | 'subsidy' | 'incentive' | 'pf' | 'psyCoin';
}

export interface Wallet {
    balance: number;
    transactions: Transaction[];
}

export interface Wallets {
  main: Wallet;
  subsidy: Wallet;
  incentive: Wallet;
  pf: Wallet;
  psyCoin: Wallet;
}

export interface RegisteredIndividual {
  id: string;
  fullName: string;
  phoneNumber: string;
  address: string;
  dob: string;
  panNumber: string;
  registeredBy: string; // officer's username
  state: string;
  occupation?: string;
  nomineeName?: string;
  nomineeAge?: number;
  nomineeRelation?: string;
}

export interface PublicUser extends RegisteredIndividual {
    username: string;
    password?: string;
    wallets: Wallets;
    status: 'active' | 'suspended';
    profilePicture?: string; // base64
    bankAccountNumber?: string;
    bankName?: string;
    ifscCode?: string;
}

export interface Officer {
  id: string;
  username: string;
  password?: string;
  wallets: Wallets;
  fullName?: string;
  phoneNumber?: string;
  address?: string;
  profilePicture?: string; // base64
  bankAccountNumber?: string;
  bankName?: string;
  ifscCode?: string;
  state: string;
  roleId: string;
  level: number;
  reportsTo: string | null; // Officer ID or null for admin
  status: 'active' | 'suspended';
  dob?: string;
}

export interface DailyReport {
    officerUsername: string;
    date: string; // YYYY-MM-DD
    registrationsCompleted: number;
    applicationsAssisted: number;
    villagesVisited: string;
    summary: string;
}

export interface LoggedInOfficial {
    username: string;
    role: Role;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userType: 'public' | 'officer';
  walletType: 'subsidy' | 'incentive';
  amount: number;
  requestDate: string;
  status: 'pending' | 'approved' | 'rejected';
  bankAccountNumber?: string;
  bankName?: string;
  ifscCode?: string;
  fullName?: string;
  username?: string;
}

export interface TopUpRequest {
  id: string;
  userId: string;
  userType: 'public' | 'officer';
  amount: number;
  paymentMethod: string;
  transactionId: string;
  requestDate: string;
  status: 'pending' | 'approved' | 'rejected';
  fullName?: string;
  username?: string;
}

export interface PendingApplication {
  id: string;
  submissionDate: string;
  status: 'pending' | 'approved' | 'rejected';
  fullName: string;
  guardianName: string;
  gender: 'male' | 'female' | 'other';
  dob: string;
  phoneNumber: string;
  email?: string;
  address: string;
  state: string;
  district: string;
  pinCode: string;
  panNumber: string;
  voterId?: string;
  profilePicture?: string; // base64
  panCardImage?: string; // base64
  username: string;
  password: string;
  occupation: string;
  nomineeName?: string;
  nomineeAge?: number;
  nomineeRelation?: string;
}

export interface PhysicalCardOrder {
  id: string;
  userId: string;
  fullName: string;
  address: string;
  phoneNumber: string;
  orderDate: string;
  status: 'Pending' | 'Printed' | 'Shipped';
}

export interface EducationLead {
    id: string;
    userId: string;
    username: string;
    fullName: string;
    type: 'Distance Education' | 'Career Counseling';
    requestDetails: string; // e.g., "Course: PhD" or the user's question
    date: string;
    status: 'Pending' | 'Contacted';
}

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  qualifications: string;
  experience: number; // in years
  consultationFee: number;
  profilePicture?: string; // base64
}

export interface Hospital {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  ambulancePhone: string;
  type: 'Government' | 'Private';
}

export interface Appointment {
  id: string;
  userId: string;
  username: string;
  fullName: string;
  doctorId: string;
  doctorName: string;
  requestDate: string; // YYYY-MM-DD
  status: 'pending' | 'approved' | 'completed' | 'rejected';
  scheduledTime?: string; // YYYY-MM-DDTHH:mm
  notes?: string; // Notes from user
}

export interface HealthRecord {
  id: string;
  userId: string;
  appointmentId: string;
  recordDate: string; // YYYY-MM-DD
  doctorName: string;
  specialization: string;
  diagnosis: string;
  prescription: string; // medication details
}

export interface ExternalService {
  id: string;
  name: string;
  description: string;
  icon: string;
  url: string;
}


type AppView = 'home' | 'ai_assistant' | 'complaint_box' | 'complaint_management' | 'editor' | 'store' | 'health' | 'education' | 'benefits' | 'apply' | 'wallet' | 'admin' | 'officer' | 'login' | 'officer_management' | 'public_registration' | 'view_registrations' | 'view_all_registrations' | 'change_password' | 'banner_management' | 'public_login' | 'public_panel' | 'wallet_management' | 'user_management' | 'daily_reports' | 'officer_id_card' | 'my_profile' | 'psy_card' | 'product_management' | 'category_management' | 'order_management' | 'purchase_history' | 'logo_management' | 'role_management' | 'level_management' | 'incentive_report' | 'my_team' | 'bmi_calculator' | 'health_guide' | 'nutrition_scanner' | 'sarkari_seva' | 'sarkari_seva_finder' | 'coming_soon' | 'withdrawal_management' | 'p2p_transfer' | 'top_up' | 'top_up_management' | 'qr_code_management' | 'qr_scanner' | 'application_management' | 'card_order_management' | 'terms_management' | 'health_tips' | 'article_management' | 'find_schools' | 'scholarships' | 'online_courses' | 'scholarship_management' | 'course_management' | 'exam_results' | 'exam_link_management' | 'distance_education' | 'career_counseling' | 'education_leads_management' | 'skill_development' | 'skill_program_management' | 'view_certificate' | 'doctor_management' | 'hospital_management' | 'appointment_management' | 'book_appointment' | 'find_hospitals' | 'video_consultation' | 'view_health_records' | 'my_appointments' | 'ai_symptom_checker' | 'news' | 'news_management' | 'id_card_management' | 'game' | 'game_management' | 'popup_management' | 'scheme_settings' | 'manage_coin_price' | 'user_change_password' | 'forgot_password' | 'services' | 'service_management' | 'advertisement_management';

const VIEW_PERMISSIONS: Partial<Record<AppView, Permission>> = {
    'admin': 'is_admin',
    'officer_management': 'manage_officers',
    'role_management': 'manage_roles',
    'user_management': 'manage_users',
    'wallet_management': 'manage_wallets',
    'withdrawal_management': 'manage_wallets',
    'top_up_management': 'manage_top_ups',
    'qr_code_management': 'manage_qr_code',
    'view_all_registrations': 'view_all_registrations',
    'banner_management': 'manage_banners',
    'advertisement_management': 'manage_advertisements',
    'product_management': 'manage_products',
    'category_management': 'manage_categories',
    'order_management': 'manage_orders',
    'card_order_management': 'manage_card_orders',
    'logo_management': 'manage_logo',
    'id_card_management': 'manage_id_card_assets',
    'level_management': 'manage_level_titles',
    'change_password': 'is_admin',
    'application_management': 'manage_applications',
    'article_management': 'manage_articles',
    'scholarship_management': 'manage_scholarships',
    'course_management': 'manage_courses',
    'exam_link_management': 'manage_exam_links',
    'education_leads_management': 'manage_education_leads',
    'skill_program_management': 'manage_skill_programs',
    'doctor_management': 'manage_doctors',
    'hospital_management': 'manage_hospitals',
    'appointment_management': 'manage_appointments',
    'news_management': 'manage_news',
    'game_management': 'manage_game_url',
    'complaint_management': 'manage_complaints',
    'popup_management': 'manage_popup_message',
    'scheme_settings': 'manage_scheme_settings',
    'manage_coin_price': 'manage_coin_price',
    'service_management': 'manage_external_services',
    'officer': 'is_officer',
    'public_registration': 'register_public_user',
    'view_registrations': 'view_own_registrations',
    'daily_reports': 'submit_daily_reports',
    'my_team': 'is_officer',
    'incentive_report': 'view_incentive_reports'
};

const PURCHASE_DIRECT_COMMISSION_RATE = 0.07; // 7% for the registering officer

const initialBanners: Banner[] = [
    { id: 1, title: 'Empowering Families', description: 'Access subsidies and services easily.', colorClass: 'bg-green-600' },
    { id: 2, title: 'Your AI Assistant', description: 'Get instant answers to your queries.', colorClass: 'bg-green-500' },
    { id: 3, title: 'Health at your Fingertips', description: 'Connect with health services seamlessly.', colorClass: 'bg-emerald-600' },
    { id: 4, title: 'Creative Image Studio', description: 'Bring your ideas to life with AI.', colorClass: 'bg-teal-500' },
];

const initialCategories: Category[] = [
    { id: 1, name: 'Groceries' },
    { id: 2, name: 'Household' },
    { id: 3, name: 'Farming' },
    { id: 4, name: 'Essentials' },
    { id: 5, name: 'Personal Care' },
    { id: 6, name: 'Medicine' },
    { id: 7, name: 'Food' },
];

const initialProducts: Product[] = [
    { id: 1, name: 'Fortified Rice', category: 'Groceries', price: 25, originalPrice: 40, imageUrl: 'https://picsum.photos/seed/rice/200', description: 'High-quality fortified rice, rich in essential vitamins and minerals for a healthy diet.' },
    { id: 2, name: 'Lentils (Dal)', category: 'Groceries', price: 60, originalPrice: 90, imageUrl: 'https://picsum.photos/seed/lentils/200', description: 'A primary source of protein for a balanced vegetarian meal. Easy to cook and delicious.' },
    { id: 3, name: 'Mustard Oil', category: 'Groceries', price: 90, originalPrice: 130, imageUrl: 'https://picsum.photos/seed/oil/200', description: 'Pure, cold-pressed mustard oil, perfect for traditional Indian cooking and preserving pickles.' },
    { id: 4, name: 'LED Bulb Pack', category: 'Household', price: 150, originalPrice: 250, imageUrl: 'https://picsum.photos/seed/bulb/200', description: 'Pack of 4 energy-efficient 9W LED bulbs. Bright, long-lasting, and saves on your electricity bill.' },
    { id: 5, name: 'Cleaning Liquid', category: 'Household', price: 50, originalPrice: 75, imageUrl: 'https://picsum.photos/seed/cleaning/200', description: 'All-purpose surface cleaning liquid with a pleasant fragrance. Kills 99.9% of germs.' },
    { id: 6, name: 'Fertilizer Bag', category: 'Farming', price: 300, originalPrice: 500, imageUrl: 'https://picsum.photos/seed/fertilizer/200', description: 'NPK balanced fertilizer to boost crop yield and soil health. Ideal for all types of crops.' },
    { id: 7, name: 'High-Yield Seeds', category: 'Farming', price: 120, originalPrice: 200, imageUrl: 'https://picsum.photos/seed/seeds/200', description: 'Certified high-yield seeds for seasonal vegetables. Ensures a bountiful harvest.' },
    { id: 8, name: 'Sugar', category: 'Groceries', price: 35, originalPrice: 50, imageUrl: 'https://picsum.photos/seed/sugar/200', description: 'Refined crystal sugar for your daily needs. Perfect for tea, coffee, and sweets.' },
    { id: 9, name: 'Soap Bar Pack', category: 'Personal Care', price: 40, originalPrice: 60, imageUrl: 'https://picsum.photos/seed/soap/200', description: 'Pack of 4 moisturizing soap bars with natural ingredients for daily hygiene.' },
    { id: 10, name: 'Toothpaste', category: 'Personal Care', price: 30, originalPrice: 50, imageUrl: 'https://picsum.photos/seed/toothpaste/200', description: 'Fluoride toothpaste for complete dental care, protects against cavities and strengthens gums.' },
    { id: 11, name: 'Paracetamol Tablets', category: 'Medicine', price: 20, originalPrice: 30, imageUrl: 'https://picsum.photos/seed/paracetamol/200', description: 'Strip of 10 paracetamol 500mg tablets for fever and pain relief.' },
    { id: 12, name: 'Wheat Flour (Atta)', category: 'Food', price: 150, originalPrice: 220, imageUrl: 'https://picsum.photos/seed/atta/200', description: '5kg bag of whole wheat flour, perfect for making rotis and chapatis.' },
];

const initialOfficerLevels: OfficerLevel[] = [
  { level: 1, title: 'Sathi Field Executive (SFE)', rate: 7 },
  { level: 2, title: 'Sathi Development Officer (SDO)', rate: 4 },
  { level: 3, title: 'Regional Program Coordinator (RPC)', rate: 3 },
  { level: 4, title: 'Program Development Manager (PDM)', rate: 2 },
  { level: 5, title: 'Senior Mission Manager (SMM)', rate: 1 },
  { level: 6, title: 'Deputy Mission Director (DMD)', rate: 1 },
  { level: 7, title: 'National Program Director (NPD)', rate: 1 },
  { level: 8, title: 'Executive National Director (END)', rate: 1 },
  { level: 9, title: 'Chief Mission Executive (CME)', rate: 1 },
  { level: 10, title: 'Chief National Advisor (CNA)', rate: 1 },
  { level: 11, title: 'Chief Mentor of Leadership (CML)', rate: 1 },
  { level: 12, title: 'Founder’s Council Advisor (FCA)', rate: 1 },
];

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    HomeComponent, 
    ImageEditorComponent,
    SubsidyStoreComponent,
    HealthServicesComponent,
    EducationComponent,
    PsyBenefitsComponent,
    ApplyPsyComponent,
    WalletComponent,
    AdminPanelComponent,
    OfficerPanelComponent,
    LoginComponent,
    OfficerManagementComponent,
    PublicRegistrationComponent,
    ViewRegistrationsComponent,
    ViewAllRegistrationsComponent,
    ChangePasswordComponent,
    BannerManagementComponent,
    PublicLoginComponent,
    PublicPanelComponent,
    WalletManagementComponent,
    TransactionDetailModalComponent,
    UserManagementComponent,
    DailyReportsComponent,
    OfficerIdCardComponent,
    MyProfileComponent,
    PsyCardComponent,
    ProductManagementComponent,
    CategoryManagementComponent,
    OrderManagementComponent,
    PurchaseHistoryComponent,
    LogoManagementComponent,
    RoleManagementComponent,
    LevelManagementComponent,
    IncentiveReportComponent,
    MyTeamComponent,
    BmiCalculatorComponent,
    AiHealthGuideComponent,
    AiNutritionScannerComponent,
    SarkariSevaComponent,
    SarkariSevaFinderComponent,
    WithdrawalManagementComponent,
    P2pTransferComponent,
    TopUpComponent,
    TopUpManagementComponent,
    QrCodeManagementComponent,
    QrScannerComponent,
    ApplicationManagementComponent,
    CardOrderManagementComponent,
    TermsManagementComponent,
    HealthTipsComponent,
    ArticleManagementComponent,
    FindSchoolsComponent,
    ScholarshipsComponent,
    OnlineCoursesComponent,
    ScholarshipManagementComponent,
    CourseManagementComponent,
    ExamResultsComponent,
    ExamLinkManagementComponent,
    DistanceEducationComponent,
    CareerCounselingComponent,
    EducationLeadsManagementComponent,
    SkillDevelopmentComponent,
    SkillProgramManagementComponent,
    ViewCertificateComponent,
    DoctorManagementComponent,
    HospitalManagementComponent,
    AppointmentManagementComponent,
    BookAppointmentComponent,
    FindHospitalsComponent,
    VideoConsultationComponent,
    ViewHealthRecordsComponent,
    MyAppointmentsComponent,
    AiSymptomCheckerComponent,
    NewsComponent,
    NewsManagementComponent,
    IdCardManagementComponent,
    ComplaintBoxComponent,
    ComplaintManagementComponent,
    GameComponent,
    GameManagementComponent,
    PopupMessageComponent,
    PopupManagementComponent,
    SchemeSettingsComponent,
    CoinPriceManagementComponent,
    UserChangePasswordComponent,
    ForgotPasswordComponent,
    AiAssistantComponent,
    ServicesComponent,
    ServiceManagementComponent,
    AdvertisementManagementComponent,
    TranslatePipe
  ]
})
export class AppComponent {
  private languageService = inject(LanguageService);
  
  currentView = signal<AppView>('home');
  loggedInOfficial = signal<LoggedInOfficial | null>(null);
  loggedInPublicUserId = signal<string | null>(null);
  appLogoUrl = signal<string | null>(null);
  idCardLogoUrl = signal<string | null>(null);
  authorizedSignatureUrl = signal<string | null>(null);
  topUpQrCodeUrl = signal<string | null>(null);
  newsUrl = signal<string | null>(null);
  gameUrl = signal<string | null>(null);
  popupMessage = signal<PopupMessage | null>(null);
  showPopup = signal(false);
  comingSoonContext = signal<{ titleKey: string } | null>(null);
  
  officialLoginTarget = signal<AppView | null>(null);
  publicLoginTarget = signal<AppView | null>(null);
  p2pRecipientTarget = signal<{ id: string; type: 'public' | 'officer' } | null>(null);
  selectedEnrollmentForCertificate = signal<UserSkillEnrollment | null>(null);

  adminCredentials = signal({ username: 'admin', password: 'password' });
  psyCoinPrice = signal(1.25); // Admin-controlled price for 1 PSY Coin in INR
  subsidyRate = signal(20); // % of purchase price credited to subsidy wallet
  pfContributionRate = signal(5); // % of purchase price credited to PF wallet

  officers = signal<Officer[]>([]);
  roles = signal<Role[]>([]);
  officerLevels = signal<OfficerLevel[]>([]);
  banners = signal<Banner[]>([]);
  advertisementBanners = signal<Advertisement[]>([]);
  publicUsers = signal<PublicUser[]>([]);
  dailyReports = signal<DailyReport[]>([]);
  products = signal<Product[]>([]);
  categories = signal<Category[]>([]);
  orders = signal<Order[]>([]);
  withdrawalRequests = signal<WithdrawalRequest[]>([]);
  topUpRequests = signal<TopUpRequest[]>([]);
  pendingApplications = signal<PendingApplication[]>([]);
  physicalCardOrders = signal<PhysicalCardOrder[]>([]);
  termsAndConditions = signal<string>('');
  healthArticles = signal<HealthArticle[]>([]);
  scholarships = signal<Scholarship[]>([]);
  onlineCourses = signal<OnlineCourse[]>([]);
  examLinks = signal<ExamLink[]>([]);
  educationLeads = signal<EducationLead[]>([]);
  skillPrograms = signal<SkillProgram[]>([]);
  userSkillEnrollments = signal<UserSkillEnrollment[]>([]);
  doctors = signal<Doctor[]>([]);
  hospitals = signal<Hospital[]>([]);
  appointments = signal<Appointment[]>([]);
  healthRecords = signal<HealthRecord[]>([]);
  complaints = signal<Complaint[]>([]);
  externalServices = signal<ExternalService[]>([]);

  pendingApplicationsCount = computed(() => this.pendingApplications().filter(a => a.status === 'pending').length);
  pendingAppointmentsCount = computed(() => this.appointments().filter(a => a.status === 'pending').length);
  pendingComplaintsCount = computed(() => this.complaints().filter(c => c.status === 'pending').length);

  // Data corruption flags
  private officersDataCorrupted = signal(false);
  private rolesDataCorrupted = signal(false);
  private officerLevelsDataCorrupted = signal(false);
  private bannersDataCorrupted = signal(false);
  private advertisementBannersDataCorrupted = signal(false);
  private publicUsersDataCorrupted = signal(false);
  private dailyReportsDataCorrupted = signal(false);
  private productsDataCorrupted = signal(false);
  private categoriesDataCorrupted = signal(false);
  private ordersDataCorrupted = signal(false);
  private appLogoDataCorrupted = signal(false);
  private idCardLogoDataCorrupted = signal(false);
  private authorizedSignatureDataCorrupted = signal(false);
  private withdrawalRequestsDataCorrupted = signal(false);
  private topUpRequestsDataCorrupted = signal(false);
  private topUpQrCodeDataCorrupted = signal(false);
  private newsUrlDataCorrupted = signal(false);
  private gameUrlDataCorrupted = signal(false);
  private popupMessageDataCorrupted = signal(false);
  private pendingApplicationsDataCorrupted = signal(false);
  private physicalCardOrdersDataCorrupted = signal(false);
  private termsDataCorrupted = signal(false);
  private healthArticlesDataCorrupted = signal(false);
  private scholarshipsDataCorrupted = signal(false);
  private onlineCoursesDataCorrupted = signal(false);
  private examLinksDataCorrupted = signal(false);
  private educationLeadsDataCorrupted = signal(false);
  private skillProgramsDataCorrupted = signal(false);
  private userSkillEnrollmentsDataCorrupted = signal(false);
  private doctorsDataCorrupted = signal(false);
  private hospitalsDataCorrupted = signal(false);
  private appointmentsDataCorrupted = signal(false);
  private healthRecordsDataCorrupted = signal(false);
  private complaintsDataCorrupted = signal(false);
  private pfContributionRateDataCorrupted = signal(false);
  private subsidyRateDataCorrupted = signal(false);
  private psyCoinPriceDataCorrupted = signal(false);
  private externalServicesDataCorrupted = signal(false);

  allUsernames = computed(() => [
    ...this.publicUsers().map(u => u.username),
    ...this.officers().map(o => o.username)
  ]);
  
  loggedInPublicUser = computed<PublicUser | null>(() => {
    const userId = this.loggedInPublicUserId();
    if (!userId) return null;
    return this.publicUsers().find(u => u.id === userId) ?? null;
  });

  previousViewForLoggedInUser = computed(() => {
    const role = this.currentUserRole();
    switch(role) {
        case 'public': return 'public_panel';
        case 'officer': return 'officer';
        case 'admin': return 'admin';
        default: return 'home';
    }
  });

  currentUserWallets = computed<Wallets>(() => {
    if (this.loggedInPublicUser()) {
        return this.loggedInPublicUser()?.wallets ?? this.createDefaultWallets();
    }
    if (this.currentOfficer()) {
        return this.currentOfficer()?.wallets ?? this.createDefaultWallets();
    }
    return this.createDefaultWallets();
  });

  currentUserRole = computed<'public' | 'officer' | 'admin' | null>(() => {
    if (this.loggedInPublicUser()) {
        return 'public';
    }
    if (this.loggedInOfficial()) {
        return this.loggedInOfficial()!.role.id === 'admin_role' ? 'admin' : 'officer';
    }
    return null;
  });

  currentOfficer = computed<Officer | null>(() => {
    const loggedIn = this.loggedInOfficial();
    if (!loggedIn) return null;
    return this.officers().find(o => o.username === loggedIn.username) ?? null;
  });
  
  currentUserForProfile = computed<(PublicUser | Officer) | null>(() => {
    if (this.loggedInPublicUser()) {
        return this.loggedInPublicUser();
    }
    return this.currentOfficer();
  });

  currentUserOfficerReports = computed<DailyReport[]>(() => {
    const officer = this.currentOfficer();
    if (!officer) return [];
    return this.dailyReports()
        .filter(report => report.officerUsername === officer.username)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });
  
  currentUserOrders = computed<Order[]>(() => {
    const user = this.loggedInPublicUser();
    if (!user) return [];
    return this.orders()
        .filter(order => order.userId === user.id)
        .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.date).getTime());
  });

  currentUserSkillEnrollments = computed<UserSkillEnrollment[]>(() => {
    const user = this.loggedInPublicUser();
    if (!user) return [];
    return this.userSkillEnrollments().filter(e => e.userId === user.id);
  });
  
  currentUserAppointments = computed<Appointment[]>(() => {
    const user = this.loggedInPublicUser();
    if (!user) return [];
    return this.appointments()
        .filter(a => a.userId === user.id)
        .sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime());
  });

  currentUserHealthRecords = computed<HealthRecord[]>(() => {
    const user = this.loggedInPublicUser();
    if (!user) return [];
    return this.healthRecords()
        .filter(hr => hr.userId === user.id)
        .sort((a, b) => new Date(b.recordDate).getTime() - new Date(a.recordDate).getTime());
  });

  currentUserComplaints = computed<Complaint[]>(() => {
    const user = this.loggedInPublicUser();
    if (!user) return [];
    return this.complaints()
        .filter(c => c.userId === user.id)
        .sort((a, b) => new Date(b.submittedDate).getTime() - new Date(a.submittedDate).getTime());
  });

  comingSoonMessage = computed(() => {
    const context = this.comingSoonContext();
    if (!context) return '';
    const title = this.languageService.translate(context.titleKey);
    return this.languageService.translate('comingSoon.message').replace('{{feature}}', title);
  });
  
  selectedProgramForCertificate = computed(() => {
    const enrollment = this.selectedEnrollmentForCertificate();
    if (!enrollment) return null;
    return this.skillPrograms().find(p => p.id === enrollment.programId) ?? null;
  });

  constructor() {
    this.loadData();
    this.setupEffects();
  }

  private loadData() {
     // OFFICER LEVELS DATA
    try {
        const savedLevels = localStorage.getItem('PSY_OFFICER_LEVELS');
        if (savedLevels) {
            this.officerLevels.set(JSON.parse(savedLevels));
        } else {
            this.officerLevels.set(initialOfficerLevels);
        }
    } catch (e) {
        this.officerLevelsDataCorrupted.set(true);
        this.officerLevels.set(initialOfficerLevels);
        console.error("Could not load/parse PSY_OFFICER_LEVELS from localStorage.", e);
    }
    
    // ROLES DATA
    const initialRoles: Role[] = [
        { id: 'role-1', name: 'Field Officer', permissions: ['is_officer', 'register_public_user', 'view_own_registrations', 'submit_daily_reports'] },
        { id: 'role-2', name: 'Senior Officer', permissions: ['is_officer', 'register_public_user', 'view_own_registrations', 'submit_daily_reports', 'view_all_registrations'] },
    ];
    try {
        const savedRoles = localStorage.getItem('PSY_ROLES');
        if (savedRoles) {
            this.roles.set(JSON.parse(savedRoles));
        } else {
            this.roles.set(initialRoles);
        }
    } catch (e) {
        this.rolesDataCorrupted.set(true);
        this.roles.set(initialRoles);
        console.error("Could not load/parse PSY_ROLES from localStorage.", e);
    }

    // OFFICERS DATA
    const initialOfficers: Officer[] = [
      { id: 'OFF-WB-000001', username: 'officer1', password: 'password', fullName: 'Ramesh Kumar', wallets: this.createDefaultWallets(0, 500, 0), state: 'WB', roleId: 'role-1', level: 1, reportsTo: null, status: 'active', dob: '1985-05-20' },
      { id: 'OFF-WB-000002', username: 'sunita.sharma', password: 'pass123', fullName: 'Sunita Sharma', wallets: this.createDefaultWallets(0, 1250, 0), state: 'WB', roleId: 'role-2', level: 2, reportsTo: null, status: 'active', dob: '1990-11-12' },
    ];
    const savedOfficers = localStorage.getItem('PSY_OFFICERS');
    if (savedOfficers) {
        try {
            const parsedData = JSON.parse(savedOfficers);
            if (!Array.isArray(parsedData)) throw new Error("Officer data is not an array");

            const validOfficers = parsedData.reduce((acc: Officer[], o: any) => {
                try {
                    if (o && typeof o.id !== 'undefined' && o.id !== null) {
                        acc.push({
                            ...this.patchWallets(this.patchProfile(o)),
                            fullName: o.fullName || o.username,
                            state: o.state || 'WB',
                            roleId: o.roleId || this.roles()[0]?.id || 'role-1',
                            level: parseInt(String(o.level || '1'), 10),
                            reportsTo: o.reportsTo === undefined ? null : o.reportsTo,
                            id: typeof o.id === 'number' ? `OFF-${o.state || 'WB'}-${String(o.id).padStart(6, '0')}` : o.id,
                            status: o.status || 'active',
                            dob: o.dob,
                        });
                    }
                } catch (e) {
                    console.warn('Skipping corrupted officer record during load:', o, e);
                }
                return acc;
            }, []);
            this.officers.set(validOfficers);
        } catch (e) {
            this.officersDataCorrupted.set(true);
            this.officers.set(initialOfficers);
            console.error("Could not fully parse PSY_OFFICERS from localStorage. Resetting to initial data.", e);
        }
    } else {
        this.officers.set(initialOfficers);
    }

    // BANNERS DATA
    try {
        this.banners.set(JSON.parse(localStorage.getItem('PSY_BANNERS') || JSON.stringify(initialBanners)));
    } catch (e) {
        this.bannersDataCorrupted.set(true); this.banners.set(initialBanners);
        console.error("Could not load/parse PSY_BANNERS from localStorage.", e);
    }

    // ADVERTISEMENT BANNERS DATA
    try {
        this.advertisementBanners.set(JSON.parse(localStorage.getItem('PSY_AD_BANNERS') || '[]'));
    } catch (e) {
        this.advertisementBannersDataCorrupted.set(true);
        this.advertisementBanners.set([]);
        console.error("Could not load/parse PSY_AD_BANNERS from localStorage.", e);
    }

    // PUBLIC USERS DATA
    const savedPublicUsers = localStorage.getItem('PSY_PUBLIC_USERS');
    if (savedPublicUsers) {
        try {
            const parsedData = JSON.parse(savedPublicUsers);
            if (!Array.isArray(parsedData)) throw new Error("Public user data is not an array");
            
            const validUsers = parsedData.reduce((acc: PublicUser[], user: any) => {
                try {
                    if (user && typeof user.id === 'string' && user.id) {
                        acc.push({
                            ...this.patchWallets(this.patchProfile(user)),
                            status: user.status || 'active',
                            state: user.state || 'WB'
                        });
                    }
                } catch (e) {
                    console.warn('Skipping corrupted public user record during load:', user, e);
                }
                return acc;
            }, []);
            this.publicUsers.set(validUsers);
        } catch (e) {
            this.publicUsersDataCorrupted.set(true);
            this.publicUsers.set([]);
            console.error("Could not parse PSY_PUBLIC_USERS from localStorage. Resetting to empty.", e);
        }
    }
    
    // DAILY REPORTS DATA
    try {
        this.dailyReports.set(JSON.parse(localStorage.getItem('PSY_DAILY_REPORTS') || '[]'));
    } catch (e) {
        this.dailyReportsDataCorrupted.set(true); this.dailyReports.set([]);
        console.error("Could not load/parse PSY_DAILY_REPORTS from localStorage.", e);
    }

    // PRODUCTS DATA
    try {
        this.products.set(JSON.parse(localStorage.getItem('PSY_PRODUCTS') || JSON.stringify(initialProducts)));
    } catch (e) {
        this.productsDataCorrupted.set(true); this.products.set(initialProducts);
        console.error("Could not load/parse PSY_PRODUCTS from localStorage.", e);
    }

    // CATEGORIES DATA
    try {
        this.categories.set(JSON.parse(localStorage.getItem('PSY_CATEGORIES') || JSON.stringify(initialCategories)));
    } catch (e) {
        this.categoriesDataCorrupted.set(true); this.categories.set(initialCategories);
        console.error("Could not load/parse PSY_CATEGORIES from localStorage.", e);
    }

    // ORDERS DATA
    try {
        this.orders.set(JSON.parse(localStorage.getItem('PSY_ORDERS') || '[]'));
    } catch (e) {
        this.ordersDataCorrupted.set(true); this.orders.set([]);
        console.error("Could not load/parse PSY_ORDERS from localStorage.", e);
    }

    // WITHDRAWAL REQUESTS DATA
    try {
        this.withdrawalRequests.set(JSON.parse(localStorage.getItem('PSY_WITHDRAWAL_REQUESTS') || '[]'));
    } catch (e) {
        this.withdrawalRequestsDataCorrupted.set(true); this.withdrawalRequests.set([]);
        console.error("Could not load/parse PSY_WITHDRAWAL_REQUESTS from localStorage.", e);
    }
    
    // TOP UP REQUESTS DATA
    try {
        this.topUpRequests.set(JSON.parse(localStorage.getItem('PSY_TOPUP_REQUESTS') || '[]'));
    } catch (e) {
        this.topUpRequestsDataCorrupted.set(true); this.topUpRequests.set([]);
        console.error("Could not load/parse PSY_TOPUP_REQUESTS from localStorage.", e);
    }

    // PENDING APPLICATIONS DATA
    try {
        const savedData = localStorage.getItem('PSY_PENDING_APPLICATIONS');
        if (savedData) {
            this.pendingApplications.set(JSON.parse(savedData));
        } else {
            this.pendingApplications.set([]);
        }
    } catch (e) {
        this.pendingApplicationsDataCorrupted.set(true); this.pendingApplications.set([]);
        console.error("Could not load/parse PSY_PENDING_APPLICATIONS from localStorage.", e);
    }
    
    // PHYSICAL CARD ORDERS DATA
    try {
        this.physicalCardOrders.set(JSON.parse(localStorage.getItem('PSY_CARD_ORDERS') || '[]'));
    } catch (e) {
        this.physicalCardOrdersDataCorrupted.set(true); this.physicalCardOrders.set([]);
        console.error("Could not load/parse PSY_CARD_ORDERS from localStorage.", e);
    }

    // HEALTH ARTICLES DATA
    try {
        this.healthArticles.set(JSON.parse(localStorage.getItem('PSY_HEALTH_ARTICLES') || '[]'));
    } catch (e) {
        this.healthArticlesDataCorrupted.set(true);
        this.healthArticles.set([]);
        console.error("Could not load/parse PSY_HEALTH_ARTICLES from localStorage.", e);
    }

    // SCHOLARSHIPS DATA
    try {
        this.scholarships.set(JSON.parse(localStorage.getItem('PSY_SCHOLARSHIPS') || '[]'));
    } catch (e) {
        this.scholarshipsDataCorrupted.set(true); this.scholarships.set([]);
        console.error("Could not load/parse PSY_SCHOLARSHIPS from localStorage.", e);
    }

    // ONLINE COURSES DATA
    try {
        this.onlineCourses.set(JSON.parse(localStorage.getItem('PSY_ONLINE_COURSES') || '[]'));
    } catch (e) {
        this.onlineCoursesDataCorrupted.set(true); this.onlineCourses.set([]);
        console.error("Could not load/parse PSY_ONLINE_COURSES from localStorage.", e);
    }

    // EXAM LINKS DATA
    try {
        this.examLinks.set(JSON.parse(localStorage.getItem('PSY_EXAM_LINKS') || '[]'));
    } catch (e) {
        this.examLinksDataCorrupted.set(true); this.examLinks.set([]);
        console.error("Could not load/parse PSY_EXAM_LINKS from localStorage.", e);
    }

    // EDUCATION LEADS DATA
    try {
        this.educationLeads.set(JSON.parse(localStorage.getItem('PSY_EDUCATION_LEADS') || '[]'));
    } catch (e) {
        this.educationLeadsDataCorrupted.set(true); this.educationLeads.set([]);
        console.error("Could not load/parse PSY_EDUCATION_LEADS from localStorage.", e);
    }

    // SKILL PROGRAMS DATA
    try {
        this.skillPrograms.set(JSON.parse(localStorage.getItem('PSY_SKILL_PROGRAMS') || '[]'));
    } catch (e) {
        this.skillProgramsDataCorrupted.set(true); this.skillPrograms.set([]);
        console.error("Could not load/parse PSY_SKILL_PROGRAMS from localStorage.", e);
    }

    // USER SKILL ENROLLMENTS DATA
    try {
        this.userSkillEnrollments.set(JSON.parse(localStorage.getItem('PSY_USER_SKILL_ENROLLMENTS') || '[]'));
    } catch (e) {
        this.userSkillEnrollmentsDataCorrupted.set(true); this.userSkillEnrollments.set([]);
        console.error("Could not load/parse PSY_USER_SKILL_ENROLLMENTS from localStorage.", e);
    }

    // DOCTORS DATA
    try {
        this.doctors.set(JSON.parse(localStorage.getItem('PSY_DOCTORS') || '[]'));
    } catch (e) {
        this.doctorsDataCorrupted.set(true); this.doctors.set([]);
        console.error("Could not load/parse PSY_DOCTORS from localStorage.", e);
    }
    
    // HOSPITALS DATA
    try {
        this.hospitals.set(JSON.parse(localStorage.getItem('PSY_HOSPITALS') || '[]'));
    } catch (e) {
        this.hospitalsDataCorrupted.set(true); this.hospitals.set([]);
        console.error("Could not load/parse PSY_HOSPITALS from localStorage.", e);
    }
    
    // APPOINTMENTS DATA
    try {
        this.appointments.set(JSON.parse(localStorage.getItem('PSY_APPOINTMENTS') || '[]'));
    } catch (e) {
        this.appointmentsDataCorrupted.set(true); this.appointments.set([]);
        console.error("Could not load/parse PSY_APPOINTMENTS from localStorage.", e);
    }
    
    // HEALTH RECORDS DATA
    try {
        this.healthRecords.set(JSON.parse(localStorage.getItem('PSY_HEALTH_RECORDS') || '[]'));
    } catch (e) {
        this.healthRecordsDataCorrupted.set(true); this.healthRecords.set([]);
        console.error("Could not load/parse PSY_HEALTH_RECORDS from localStorage.", e);
    }

    // COMPLAINTS DATA
    try {
        this.complaints.set(JSON.parse(localStorage.getItem('PSY_COMPLAINTS') || '[]'));
    } catch (e) {
        this.complaintsDataCorrupted.set(true); this.complaints.set([]);
        console.error("Could not load/parse PSY_COMPLAINTS from localStorage.", e);
    }

    // EXTERNAL SERVICES DATA
    try {
        this.externalServices.set(JSON.parse(localStorage.getItem('PSY_EXTERNAL_SERVICES') || '[]'));
    } catch (e) {
        this.externalServicesDataCorrupted.set(true);
        this.externalServices.set([]);
        console.error("Could not load/parse PSY_EXTERNAL_SERVICES from localStorage.", e);
    }


    // APP LOGO DATA
    try {
        const savedLogo = localStorage.getItem('PSY_APP_LOGO');
        if (savedLogo && savedLogo.startsWith('data:image')) {
            this.appLogoUrl.set(savedLogo);
        } else {
            // Set a default logo if none is found in storage
            const defaultLogo = 'data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMjAwIDIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImJnX2dyYWRpZW50IiB4MT0iMCIgeTE9IjAiIHgyPSIxIiB5Mj0iMSI+PHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iIzE2YTM0YSIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iIzRhZGU4MCIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjEwMCIgcj0iOTUiIGZpbGw9InVybCgjYmdfZ3JhZGllbnQpIi8+PGcgZmlsbD0id2hpdGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAsIDEwKSI+PGNpcmNsZSBjeD0iMTAwIiBjeT0iNzAiIHI9IjIwIi8+PHBhdGggZD0iTTcwIDE1MUM3MCAxMTAsIDEzMCAxMTAsIDEzMCAxNTAgWiIvPjxjaXJjbGUgY3g9IjU1IiBjeT0iODUiIHI9IjE1Ii8+PHBhdGggZD0iTTM1IDE1MUMzNSAxMjAsIDc1IDEyMCwgNzUgMTUwIFoiLz48Y2lyY2xlIGN4PSIxNDUiIGN5PSI4NSIgcj0iMTUiLz48cGF0aCBkPSJNMTI1IDE1MUMxMjUgMTIwLCAxNjUgMTIwLCAxNjUgMTUwIFoiLz48L2c+PC9zdmc+';
            this.appLogoUrl.set(defaultLogo);
        }
    } catch (e) {
        this.appLogoDataCorrupted.set(true);
        console.error("Could not load/parse PSY_APP_LOGO from localStorage.", e);
    }

    // ID CARD LOGO DATA
    try {
        const savedLogo = localStorage.getItem('PSY_ID_CARD_LOGO');
        if (savedLogo && savedLogo.startsWith('data:image')) {
            this.idCardLogoUrl.set(savedLogo);
        }
    } catch (e) {
        this.idCardLogoDataCorrupted.set(true);
        console.error("Could not load/parse PSY_ID_CARD_LOGO from localStorage.", e);
    }

    // AUTHORIZED SIGNATURE DATA
    try {
        const savedSig = localStorage.getItem('PSY_AUTH_SIGNATURE');
        if (savedSig && savedSig.startsWith('data:image')) {
            this.authorizedSignatureUrl.set(savedSig);
        }
    } catch (e) {
        this.authorizedSignatureDataCorrupted.set(true);
        console.error("Could not load/parse PSY_AUTH_SIGNATURE from localStorage.", e);
    }

    // TOP UP QR CODE DATA
    try {
        const savedQrCode = localStorage.getItem('PSY_TOPUP_QR_CODE');
        if (savedQrCode && savedQrCode.startsWith('data:image')) {
            this.topUpQrCodeUrl.set(savedQrCode);
        }
    } catch (e) {
        this.topUpQrCodeDataCorrupted.set(true);
        console.error("Could not load/parse PSY_TOPUP_QR_CODE from localStorage.", e);
    }
    
    // NEWS URL DATA
    try {
        const savedNewsUrl = localStorage.getItem('PSY_NEWS_URL');
        this.newsUrl.set(savedNewsUrl || 'https://www.anandabazar.com/');
    } catch (e) {
        this.newsUrlDataCorrupted.set(true);
        this.newsUrl.set('https://www.anandabazar.com/');
        console.error("Could not load PSY_NEWS_URL from localStorage.", e);
    }

    // GAME URL DATA
    try {
        const savedGameUrl = localStorage.getItem('PSY_GAME_URL');
        this.gameUrl.set(savedGameUrl || 'https://poki.com/');
    } catch (e) {
        this.gameUrlDataCorrupted.set(true);
        this.gameUrl.set('https://poki.com/');
        console.error("Could not load PSY_GAME_URL from localStorage.", e);
    }

    // POPUP MESSAGE DATA
    try {
        const savedPopup = localStorage.getItem('PSY_POPUP_MESSAGE');
        if (savedPopup) {
            this.popupMessage.set(JSON.parse(savedPopup));
        } else {
            this.popupMessage.set({
                enabled: false,
                title: 'Welcome!',
                message: 'This is a sample message from the admin.',
                imageUrl: null,
                link: null,
            });
        }
    } catch (e) {
        this.popupMessageDataCorrupted.set(true);
        this.popupMessage.set(null);
        console.error("Could not load/parse PSY_POPUP_MESSAGE from localStorage.", e);
    }

    // TERMS & CONDITIONS DATA
    const defaultTerms = `শর্তাবলী ও নিয়মাবলী

১. সাধারণ শর্তাবলী
এই প্রকল্পের অধীনে প্রদত্ত সমস্ত পরিষেবা পশ্চিমবঙ্গ সরকারের নিয়মাবলী দ্বারা পরিচালিত। কর্তৃপক্ষ যেকোনো সময় শর্তাবলী পরিবর্তন করার অধিকার রাখে।

২. আবেদনকারীর যোগ্যতা
আবেদনকারীকে পশ্চিমবঙ্গের স্থায়ী বাসিন্দা হতে হবে। প্রকল্পের নির্দিষ্ট যোগ্যতার মানদণ্ড পূরণ করতে হবে।

৩. তথ্যের সত্যতা
আবেদনকারী দ্বারা প্রদত্ত সমস্ত তথ্য (নাম, ঠিকানা, প্যান কার্ড ইত্যাদি) অবশ্যই সত্য এবং সঠিক হতে হবে। কোনো ভুল বা মিথ্যা তথ্য প্রমাণিত হলে আবেদন বাতিল করা হবে এবং আইনি ব্যবস্থা নেওয়া হতে পারে।

৪. পরিষেবার ব্যবহার
ভর্তুকিযুক্ত পণ্য এবং অন্যান্য পরিষেবা শুধুমাত্র ব্যক্তিগত এবং পারিবারিক ব্যবহারের জন্য। এগুলি বাণিজ্যিক উদ্দেশ্যে ব্যবহার করা যাবে না।

৫. অ্যাকাউন্ট সুরক্ষা
আপনার ইউজারনেম এবং পাসওয়ার্ড গোপন রাখা আপনার দায়িত্ব। আপনার অ্যাকাউন্টের কোনো অপব্যবহারের জন্য কর্তৃপক্ষ দায়ী থাকবে না।

৬. ঘোষণা
আমি ঘোষণা করছি যে আমি সমস্ত শর্তাবলী পড়েছি এবং বুঝতে পেরেছি। আমি এই প্রকল্পের নিয়মাবলী মেনে চলতে সম্মত।`;
    try {
        this.termsAndConditions.set(localStorage.getItem('PSY_TERMS') || defaultTerms);
    } catch (e) {
        this.termsDataCorrupted.set(true);
        this.termsAndConditions.set(defaultTerms);
        console.error("Could not load PSY_TERMS from localStorage.", e);
    }

    // PF CONTRIBUTION RATE
    try {
        const savedPfRate = localStorage.getItem('PSY_PF_CONTRIBUTION_RATE');
        if (savedPfRate) {
            this.pfContributionRate.set(parseFloat(savedPfRate));
        } else {
            this.pfContributionRate.set(5); // Set default to 5
        }
    } catch (e) {
        this.pfContributionRateDataCorrupted.set(true);
        this.pfContributionRate.set(5);
        console.error("Could not load PF rate from localStorage.", e);
    }

    // SUBSIDY RATE
    try {
        const savedSubsidyRate = localStorage.getItem('PSY_SUBSIDY_RATE');
        if (savedSubsidyRate) {
            this.subsidyRate.set(parseFloat(savedSubsidyRate));
        } else {
            this.subsidyRate.set(20); // Set default to 20
        }
    } catch (e) {
        this.subsidyRateDataCorrupted.set(true); 
        this.subsidyRate.set(20);
        console.error("Could not load Subsidy rate from localStorage.", e);
    }

    // PSY COIN PRICE
    try {
        const savedPrice = localStorage.getItem('PSY_COIN_PRICE');
        if (savedPrice) {
            this.psyCoinPrice.set(parseFloat(savedPrice));
        } else {
            this.psyCoinPrice.set(1.25);
        }
    } catch (e) {
        this.psyCoinPriceDataCorrupted.set(true);
        this.psyCoinPrice.set(1.25);
        console.error("Could not load PSY_COIN_PRICE from localStorage.", e);
    }

    // SESSION DATA
    try {
        const savedUserId = localStorage.getItem('PSY_LOGGED_IN_PUBLIC_USER_ID');
        if(savedUserId) this.loggedInPublicUserId.set(JSON.parse(savedUserId));
    } catch (e) {
        localStorage.removeItem('PSY_LOGGED_IN_PUBLIC_USER_ID');
    }

    // Check session storage to see if popup has been shown
    const popupShown = sessionStorage.getItem('PSY_POPUP_SHOWN');
    const popupData = this.popupMessage();
    if (!popupShown && popupData && popupData.enabled) {
        this.showPopup.set(true);
    }
  }

  private setupEffects() {
    const createSaver = <T>(key: string, signal: () => T, corruptionFlag: () => boolean) => {
        effect(() => {
            if (!corruptionFlag()) {
                try {
                    localStorage.setItem(key, JSON.stringify(signal()));
                } catch (e) {
                    console.error(`Failed to save ${key} to localStorage.`, e);
                }
            }
        });
    };
    
    createSaver('PSY_OFFICERS', this.officers, this.officersDataCorrupted);
    createSaver('PSY_ROLES', this.roles, this.rolesDataCorrupted);
    createSaver('PSY_OFFICER_LEVELS', this.officerLevels, this.officerLevelsDataCorrupted);
    createSaver('PSY_BANNERS', this.banners, this.bannersDataCorrupted);
    createSaver('PSY_AD_BANNERS', this.advertisementBanners, this.advertisementBannersDataCorrupted);
    createSaver('PSY_PUBLIC_USERS', this.publicUsers, this.publicUsersDataCorrupted);
    createSaver('PSY_DAILY_REPORTS', this.dailyReports, this.dailyReportsDataCorrupted);
    createSaver('PSY_PRODUCTS', this.products, this.productsDataCorrupted);
    createSaver('PSY_CATEGORIES', this.categories, this.categoriesDataCorrupted);
    createSaver('PSY_ORDERS', this.orders, this.ordersDataCorrupted);
    createSaver('PSY_WITHDRAWAL_REQUESTS', this.withdrawalRequests, this.withdrawalRequestsDataCorrupted);
    createSaver('PSY_TOPUP_REQUESTS', this.topUpRequests, this.topUpRequestsDataCorrupted);
    createSaver('PSY_PENDING_APPLICATIONS', this.pendingApplications, this.pendingApplicationsDataCorrupted);
    createSaver('PSY_CARD_ORDERS', this.physicalCardOrders, this.physicalCardOrdersDataCorrupted);
    createSaver('PSY_HEALTH_ARTICLES', this.healthArticles, this.healthArticlesDataCorrupted);
    createSaver('PSY_SCHOLARSHIPS', this.scholarships, this.scholarshipsDataCorrupted);
    createSaver('PSY_ONLINE_COURSES', this.onlineCourses, this.onlineCoursesDataCorrupted);
    createSaver('PSY_EXAM_LINKS', this.examLinks, this.examLinksDataCorrupted);
    createSaver('PSY_EDUCATION_LEADS', this.educationLeads, this.educationLeadsDataCorrupted);
    createSaver('PSY_SKILL_PROGRAMS', this.skillPrograms, this.skillProgramsDataCorrupted);
    createSaver('PSY_USER_SKILL_ENROLLMENTS', this.userSkillEnrollments, this.userSkillEnrollmentsDataCorrupted);
    createSaver('PSY_DOCTORS', this.doctors, this.doctorsDataCorrupted);
    createSaver('PSY_HOSPITALS', this.hospitals, this.hospitalsDataCorrupted);
    createSaver('PSY_APPOINTMENTS', this.appointments, this.appointmentsDataCorrupted);
    createSaver('PSY_HEALTH_RECORDS', this.healthRecords, this.healthRecordsDataCorrupted);
    createSaver('PSY_COMPLAINTS', this.complaints, this.complaintsDataCorrupted);
    createSaver('PSY_POPUP_MESSAGE', this.popupMessage, this.popupMessageDataCorrupted);
    createSaver('PSY_EXTERNAL_SERVICES', this.externalServices, this.externalServicesDataCorrupted);
    
    effect(() => {
      if (!this.pfContributionRateDataCorrupted()) {
        try {
          localStorage.setItem('PSY_PF_CONTRIBUTION_RATE', this.pfContributionRate().toString());
        } catch (e) {
          console.error('Failed to save PF contribution rate.', e);
        }
      }
    });

    effect(() => {
      if (!this.subsidyRateDataCorrupted()) {
        try {
          localStorage.setItem('PSY_SUBSIDY_RATE', this.subsidyRate().toString());
        } catch (e) {
          console.error('Failed to save Subsidy rate.', e);
        }
      }
    });

    effect(() => {
      if (!this.psyCoinPriceDataCorrupted()) {
        try {
          localStorage.setItem('PSY_COIN_PRICE', this.psyCoinPrice().toString());
        } catch (e) {
          console.error('Failed to save PSY Coin Price.', e);
        }
      }
    });

    effect(() => {
        if (!this.appLogoDataCorrupted()) {
            try {
                const logo = this.appLogoUrl();
                if (logo) localStorage.setItem('PSY_APP_LOGO', logo);
                else localStorage.removeItem('PSY_APP_LOGO');
            } catch (e) { console.error('Failed to save app logo.', e); }
        }
    });

    effect(() => {
        if (!this.idCardLogoDataCorrupted()) {
            try {
                const logo = this.idCardLogoUrl();
                if (logo) localStorage.setItem('PSY_ID_CARD_LOGO', logo);
                else localStorage.removeItem('PSY_ID_CARD_LOGO');
            } catch (e) { console.error('Failed to save id card logo.', e); }
        }
    });

    effect(() => {
        if (!this.authorizedSignatureDataCorrupted()) {
            try {
                const sig = this.authorizedSignatureUrl();
                if (sig) localStorage.setItem('PSY_AUTH_SIGNATURE', sig);
                else localStorage.removeItem('PSY_AUTH_SIGNATURE');
            } catch (e) { console.error('Failed to save authorized signature.', e); }
        }
    });

    effect(() => {
        if (!this.topUpQrCodeDataCorrupted()) {
            try {
                const qrCode = this.topUpQrCodeUrl();
                if (qrCode) localStorage.setItem('PSY_TOPUP_QR_CODE', qrCode);
                else localStorage.removeItem('PSY_TOPUP_QR_CODE');
            } catch (e) { console.error('Failed to save Top-up QR Code.', e); }
        }
    });

    effect(() => {
        if (!this.newsUrlDataCorrupted()) {
            try {
                const url = this.newsUrl();
                if (url) localStorage.setItem('PSY_NEWS_URL', url);
                else localStorage.removeItem('PSY_NEWS_URL');
            } catch (e) { console.error('Failed to save news URL.', e); }
        }
    });

    effect(() => {
        if (!this.gameUrlDataCorrupted()) {
            try {
                const url = this.gameUrl();
                if (url) localStorage.setItem('PSY_GAME_URL', url);
                else localStorage.removeItem('PSY_GAME_URL');
            } catch (e) { console.error('Failed to save game URL.', e); }
        }
    });

    effect(() => {
        if (!this.termsDataCorrupted()) {
            try {
                localStorage.setItem('PSY_TERMS', this.termsAndConditions());
            } catch (e) { console.error('Failed to save terms and conditions.', e); }
        }
    });

    effect(() => {
        try {
            const userId = this.loggedInPublicUserId();
            if (userId) localStorage.setItem('PSY_LOGGED_IN_PUBLIC_USER_ID', JSON.stringify(userId));
            else localStorage.removeItem('PSY_LOGGED_IN_PUBLIC_USER_ID');
        } catch(e) { console.error('Failed to save session.', e); }
    });
  }

  private hasPermission(permission: Permission): boolean {
    const official = this.loggedInOfficial();
    if (!official) return false;
    return official.role.permissions.includes(permission);
  }

  private patchWallets<T extends { wallets?: Partial<Wallets> }>(user: T): T {
    const defaultWallets = this.createDefaultWallets();
    return {
      ...user,
      wallets: {
        main: user.wallets?.main || defaultWallets.main,
        subsidy: user.wallets?.subsidy || defaultWallets.subsidy,
        incentive: user.wallets?.incentive || defaultWallets.incentive,
        pf: user.wallets?.pf || defaultWallets.pf,
        psyCoin: user.wallets?.psyCoin || defaultWallets.psyCoin,
      }
    };
  }

  private patchProfile<T extends { 
    profilePicture?: string, 
    bankAccountNumber?: string, 
    ifscCode?: string, 
    bankName?: string,
    occupation?: string,
    nomineeName?: string,
    nomineeAge?: number,
    nomineeRelation?: string
  }>(user: T): T {
    return {
      ...user,
      profilePicture: user.profilePicture || undefined,
      bankAccountNumber: user.bankAccountNumber || undefined,
      bankName: user.bankName || undefined,
      ifscCode: user.ifscCode || undefined,
      occupation: user.occupation || undefined,
      nomineeName: user.nomineeName || undefined,
      nomineeAge: user.nomineeAge || undefined,
      nomineeRelation: user.nomineeRelation || undefined,
    };
  }


  createDefaultWallets(main = 0, subsidy = 0, incentive = 0, pf = 0, psyCoin = 0): Wallets {
    return {
      main: { balance: main, transactions: [] },
      subsidy: { balance: subsidy, transactions: [] },
      incentive: { balance: incentive, transactions: [] },
      pf: { balance: pf, transactions: [] },
      psyCoin: { balance: psyCoin, transactions: [] },
    };
  }

  onNavigate(view: AppView | string) {
    if (this.currentView() === 'p2p_transfer') {
        this.p2pRecipientTarget.set(null);
    }
    
    if (this.currentView() === 'view_certificate') {
        this.selectedEnrollmentForCertificate.set(null);
    }

    if (view.startsWith('coming_soon:')) {
        const titleKey = view.split(':')[1];
        this.comingSoonContext.set({ titleKey });
        this.currentView.set('coming_soon');
        return;
    }

    const targetView = view as AppView;

    const requiredPermission = VIEW_PERMISSIONS[targetView];
    if (requiredPermission) {
      if (!this.loggedInOfficial()) {
        this.officialLoginTarget.set(targetView);
        this.currentView.set('login');
        return;
      }
      if (!this.hasPermission(requiredPermission)) {
        alert("You don't have permission to access this page.");
        return;
      }
    }
    
    // Views that require ANY authenticated user (public or officer)
    const sharedAuthViews: AppView[] = ['wallet', 'my_profile', 'p2p_transfer', 'top_up', 'qr_scanner', 'user_change_password', 'store'];
    if (sharedAuthViews.includes(targetView)) {
        if (!this.loggedInPublicUser() && !this.loggedInOfficial()) {
            // Not logged in as anyone. Default to public login.
            this.publicLoginTarget.set(targetView);
            this.currentView.set('public_login');
            return;
        }
    }

    // Views that are strictly for logged-in PUBLIC users
    const publicOnlyViews: AppView[] = [
        'public_panel', 'psy_card', 'purchase_history', 'skill_development', 'view_certificate', 
        'my_appointments', 'book_appointment', 'view_health_records', 'video_consultation', 
        'complaint_box', 'distance_education', 'career_counseling', 'ai_assistant'
    ];
    if(publicOnlyViews.includes(targetView)) {
        if (!this.loggedInPublicUser()) {
            this.publicLoginTarget.set(targetView);
            this.currentView.set('public_login');
            return;
        }
    }

    if(this.currentView() === 'login') this.officialLoginTarget.set(null);
    if(this.currentView() === 'public_login') this.publicLoginTarget.set(null);

    this.currentView.set(targetView);
    window.scrollTo(0, 0);
  }

  private addTransactionToUser<T extends PublicUser | Officer>(user: T, wallet: keyof Wallets, amount: number, description: string): T {
    const newWallet: Wallet = {
        ...user.wallets[wallet],
        balance: user.wallets[wallet].balance + amount,
        transactions: [
            ...user.wallets[wallet].transactions,
            {
                id: `TXN-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
                date: new Date().toISOString().split('T')[0],
                amount: amount,
                type: amount >= 0 ? 'credit' : 'debit',
                wallet,
                description,
            }
        ]
    };

    return {
        ...user,
        wallets: {
            ...user.wallets,
            [wallet]: newWallet
        }
    };
  }

  addOfficer(officerData: Omit<Officer, 'id' | 'wallets' | 'status'>) {
    const latestIdNumber = this.officers()
      .filter(o => o.state === officerData.state && o.id.startsWith(`OFF-${officerData.state}-`))
      .map(o => {
        const parts = o.id.split('-');
        return parts.length === 3 ? parseInt(parts[2], 10) : NaN;
      })
      .filter(num => !isNaN(num))
      .reduce((max, num) => Math.max(max, num), 0);
    
    const newIdNumber = (latestIdNumber + 1).toString().padStart(6, '0');

    const newOfficer: Officer = {
      ...officerData,
      id: `OFF-${officerData.state}-${newIdNumber}`,
      wallets: this.createDefaultWallets(),
      status: 'active',
    };

    this.officers.update(officers => [...officers, newOfficer]);
  }

  handleUpdateOfficer(updatedOfficer: Officer) {
    this.officers.update(officers => 
      officers.map(o => o.id === updatedOfficer.id ? updatedOfficer : o)
    );
  }
  
  handleOfficerStatusUpdate(event: { officerId: string; status: 'active' | 'suspended' }) {
    this.officers.update(officers =>
      officers.map(o => o.id === event.officerId ? { ...o, status: event.status } : o)
    );
  }

  deleteOfficer(officerId: string) {
    this.officers.update(officers => officers.filter(o => o.id !== officerId));
  }
  
  handleUserStatusUpdate(event: { userId: string; status: 'active' | 'suspended' }) {
    this.publicUsers.update(users => 
      users.map(u => u.id === event.userId ? { ...u, status: event.status } : u)
    );
  }

  handleUserDelete(userId: string) {
    this.publicUsers.update(users => users.filter(u => u.id !== userId));
  }

  handleUserUpdate(updatedUser: PublicUser) {
    this.publicUsers.update(users =>
      users.map(u => u.id === updatedUser.id ? updatedUser : u)
    );
  }
  
  handleProfileUpdate(updatedUser: PublicUser | Officer) {
    if ('registeredBy' in updatedUser) { // It's a PublicUser
      this.publicUsers.update(users => 
        users.map(u => u.id === updatedUser.id ? updatedUser as PublicUser : u)
      );
    } else { // It's an Officer
      this.officers.update(officers => 
        officers.map(o => o.id === updatedUser.id ? updatedUser as Officer : o)
      );
    }
  }

  handleOfficialLoginSuccess(user: OfficialUser) {
    let role: Role;
    if (user.role === 'admin') {
      role = { id: 'admin_role', name: 'Administrator', permissions: [...ALL_PERMISSIONS] };
    } else {
      const officer = this.officers().find(o => o.username === user.username);
      if (!officer) { console.error('Logged in officer not found!'); return; }
      const foundRole = this.roles().find(r => r.id === officer.roleId);
      if (!foundRole) { console.error(`Role with id ${officer.roleId} not found!`); return; }
      role = foundRole;
    }
    
    this.loggedInOfficial.set({ username: user.username, role });
    const target = this.officialLoginTarget();
    this.onNavigate(target || (user.role === 'admin' ? 'admin' : 'officer'));
  }

  handlePublicLoginSuccess(user: PublicUser) {
    this.loggedInPublicUserId.set(user.id);
    const target = this.publicLoginTarget();
    this.onNavigate(target || 'public_panel');
  }

  handleOfficialLogout() { this.loggedInOfficial.set(null); this.onNavigate('home'); }
  handlePublicLogout() { this.loggedInPublicUserId.set(null); this.onNavigate('home'); }

  handlePurchase({ product, callback }: { product: Product, callback: (result: { success: boolean, message?: string }) => void }) {
    const user = this.loggedInPublicUser();
    if (!user) {
        callback({ success: false, message: this.languageService.translate('error.userNotLoggedIn') });
        return;
    }
    if (user.wallets.main.balance < product.price) {
        callback({ success: false, message: this.languageService.translate('error.insufficientBalance') });
        return;
    }

    // Update officers (commissions)
    const registeringOfficer = this.officers().find(o => o.username === user.registeredBy);
    if (registeringOfficer) {
        let officersToUpdate = new Map<string, Officer>();
        
        const directCommission = product.price * PURCHASE_DIRECT_COMMISSION_RATE;
        let updatedRegisteringOfficer = this.addTransactionToUser(registeringOfficer, 'incentive', directCommission, `Direct commission from ${user.username}`);
        officersToUpdate.set(updatedRegisteringOfficer.id, updatedRegisteringOfficer);

        let currentOfficerId = updatedRegisteringOfficer.reportsTo;
        while(currentOfficerId) {
            const superior = this.officers().find(o => o.id === currentOfficerId);
            if (!superior) break;

            const levelInfo = this.officerLevels().find(l => l.level === superior.level);
            if (levelInfo && levelInfo.rate > 0) {
                const commissionAmount = product.price * (levelInfo.rate / 100);
                const currentSuperior = officersToUpdate.get(superior.id) || superior;
                const updatedSuperior = this.addTransactionToUser(currentSuperior, 'incentive', commissionAmount, `Upline commission from ${registeringOfficer.username}'s team`);
                officersToUpdate.set(updatedSuperior.id, updatedSuperior);
            }
            currentOfficerId = superior.reportsTo;
        }
        
        this.officers.update(officers => 
            officers.map(o => officersToUpdate.get(o.id) || o)
        );
    }
    
    // Update public user by constructing a new object with all changes at once.
    this.publicUsers.update(users => users.map(u => {
      if (u.id !== user.id) {
          return u;
      }

      const subsidyAmount = product.price * (this.subsidyRate() / 100);
      const pfAmount = product.price * (this.pfContributionRate() / 100);

      // Construct the final, single, new user object with all changes
      const updatedUser: PublicUser = {
          ...u,
          wallets: {
              ...u.wallets,
              main: {
                  ...u.wallets.main,
                  balance: u.wallets.main.balance - product.price,
                  transactions: [...u.wallets.main.transactions, {
                      id: `TXN-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
                      date: new Date().toISOString().split('T')[0],
                      amount: -product.price, type: 'debit', wallet: 'main',
                      description: `${this.languageService.translate('transaction.purchase')}: ${product.name}`
                  }]
              },
              subsidy: subsidyAmount > 0 ? {
                  ...u.wallets.subsidy,
                  balance: u.wallets.subsidy.balance + subsidyAmount,
                  transactions: [...u.wallets.subsidy.transactions, {
                      id: `TXN-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
                      date: new Date().toISOString().split('T')[0],
                      amount: subsidyAmount, type: 'credit', wallet: 'subsidy',
                      description: `${this.languageService.translate('transaction.subsidyFor')} ${product.name}`
                  }]
              } : u.wallets.subsidy,
              pf: pfAmount > 0 ? {
                  ...u.wallets.pf,
                  balance: u.wallets.pf.balance + pfAmount,
                  transactions: [...u.wallets.pf.transactions, {
                      id: `TXN-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
                      date: new Date().toISOString().split('T')[0],
                      amount: pfAmount, type: 'credit', wallet: 'pf',
                      description: this.languageService.translate('transaction.pfContribution')
                  }]
              } : u.wallets.pf,
          }
      };
      return updatedUser;
    }));

    // Create order
    this.orders.update(orders => [...orders, {
        id: `ORD-${Date.now()}`, userId: user.id, productId: product.id,
        productName: product.name, productImageUrl: product.imageUrl,
        pricePaid: product.price, orderDate: new Date().toISOString().split('T')[0],
        status: 'Processing'
    }]);
    
    callback({ success: true });
}

  
  handleBuyCoins(amountInr: number) {
      this.handleCoinTrade(amountInr, 'buy');
  }

  handleSellCoins(amountCoins: number) {
      this.handleCoinTrade(amountCoins, 'sell');
  }

  private handleCoinTrade(amount: number, type: 'buy' | 'sell') {
    const user = this.currentUserForProfile();
    if (!user) return;

    const updateUserState = (u: PublicUser | Officer) => {
        if (type === 'buy') {
            const coinsToGet = amount / this.psyCoinPrice();
            let updatedUser = this.addTransactionToUser(u, 'main', -amount, `${this.languageService.translate('transaction.boughtCoins')} ${coinsToGet.toFixed(4)} PSC`);
            updatedUser = this.addTransactionToUser(updatedUser, 'psyCoin', coinsToGet, `${this.languageService.translate('transaction.receivedFromSale')}`);
            return updatedUser;
        } else { // sell
            const inrToGet = amount * this.psyCoinPrice();
            let updatedUser = this.addTransactionToUser(u, 'psyCoin', -amount, `${this.languageService.translate('transaction.soldCoins')} ${amount} PSC`);
            updatedUser = this.addTransactionToUser(updatedUser, 'main', inrToGet, `${this.languageService.translate('transaction.receivedFromSale')}`);
            return updatedUser;
        }
    };
    
    if ('registeredBy' in user) {
        this.publicUsers.update(users => users.map(u => u.id === user.id ? updateUserState(u) as PublicUser : u));
    } else {
        this.officers.update(officers => officers.map(o => o.id === user.id ? updateUserState(o) as Officer : o));
    }
  }
  
  handleAdminPasswordChange(event: AdminPasswordChangeEvent) {
    const admin = this.adminCredentials();
    if (event.currentPassword === admin.password) {
      this.adminCredentials.set({ ...admin, password: event.newPassword });
      event.callback(true);
    } else {
      event.callback(false);
    }
  }

  handleUserPasswordChange(event: UserPasswordChangeEvent) {
    const { user, currentPassword, newPassword, callback } = event;

    const updateUser = (u: PublicUser | Officer) => {
      if (u.password !== currentPassword) {
        callback(false, 'Current password does not match.');
        return u;
      }
      callback(true);
      return { ...u, password: newPassword };
    };

    if ('registeredBy' in user) {
      this.publicUsers.update(users => users.map(u => u.id === user.id ? updateUser(u) as PublicUser : u));
    } else {
      this.officers.update(officers => officers.map(o => o.id === user.id ? updateUser(o) as Officer : o));
    }
  }

  handleForgotPasswordReset(event: PasswordResetEvent) {
    const { username, panNumber, newPassword, callback } = event;
    
    const publicUser = this.publicUsers().find(u => u.username === username);
    if (!publicUser) {
        callback(false, this.languageService.translate('forgotPassword.error.userNotFound'));
        return;
    }

    if (publicUser.panNumber.toUpperCase() !== panNumber.toUpperCase()) {
        callback(false, this.languageService.translate('forgotPassword.error.panMismatch'));
        return;
    }

    this.publicUsers.update(users => users.map(u => 
        u.id === publicUser.id ? { ...u, password: newPassword } : u
    ));

    callback(true);
  }

  addBanner(banner: Omit<Banner, 'id'>) {
    this.banners.update(banners => [...banners, { ...banner, id: Date.now() }]);
  }

  deleteBanner(id: number) {
    this.banners.update(banners => banners.filter(b => b.id !== id));
  }
  
  handleCreateAdvertisement(ad: Omit<Advertisement, 'id'>) {
    this.advertisementBanners.update(ads => [...ads, { ...ad, id: `AD-${Date.now()}` }]);
  }

  handleDeleteAdvertisement(id: string) {
    this.advertisementBanners.update(ads => ads.filter(ad => ad.id !== id));
  }

  handleAdminWalletUpdate(event: WalletUpdateEvent) {
    const { targetId, targetType, wallet, transactionType, amount, reason } = event;
    
    const transactAmount = transactionType === 'credit' ? amount : -amount;
    const description = `${this.languageService.translate(transactionType === 'credit' ? 'transaction.adminCredit' : 'transaction.adminDebit')}: ${reason}`;

    if (targetType === 'public') {
        this.publicUsers.update(users => users.map(u => 
            u.id === targetId ? this.addTransactionToUser(u, wallet, transactAmount, description) : u
        ));
    } else {
        this.officers.update(officers => officers.map(o => 
            o.id === targetId ? this.addTransactionToUser(o, wallet, transactAmount, description) : o
        ));
    }
  }

  handleReportSubmission(reportData: DailyReportSubmission) {
    const officer = this.currentOfficer();
    if (!officer) return;
    const newReport: DailyReport = {
      ...reportData,
      officerUsername: officer.username,
      date: new Date().toISOString().split('T')[0]
    };
    this.dailyReports.update(reports => [...reports, newReport]);
  }

  handleAddProduct(product: Omit<Product, 'id'>) {
    this.products.update(p => [...p, { ...product, id: Date.now() }]);
  }

  handleUpdateProduct(product: Product) {
    this.products.update(p => p.map(item => item.id === product.id ? product : item));
  }

  handleDeleteProduct(id: number) {
    this.products.update(p => p.filter(item => item.id !== id));
  }

  handleCreateCategory(name: string) {
    this.categories.update(c => [...c, { id: Date.now(), name }]);
  }
  
  handleDeleteCategory(id: number) {
    this.categories.update(c => c.filter(item => item.id !== id));
  }

  handleUpdateOrder(order: Order) {
    this.orders.update(o => o.map(item => item.id === order.id ? order : item));
  }
  
  handleLogoUpdate(logoUrl: string | null) {
    this.appLogoUrl.set(logoUrl);
  }

  handleIdCardLogoUpdate(url: string | null) {
    this.idCardLogoUrl.set(url);
  }

  handleAuthorizedSignatureUpdate(url: string | null) {
    this.authorizedSignatureUrl.set(url);
  }

  handleCreateRole(role: Omit<Role, 'id'>) {
    this.roles.update(r => [...r, { ...role, id: `role-${Date.now()}` }]);
  }

  handleUpdateRole(role: Role) {
    this.roles.update(r => r.map(item => item.id === role.id ? role : item));
  }

  handleDeleteRole(id: string) {
    const isAssigned = this.officers().some(o => o.roleId === id);
    if (isAssigned) {
      alert(this.languageService.translate('alert.cannotDeleteRole'));
      return;
    }
    this.roles.update(r => r.filter(item => item.id !== id));
  }
  
  handleUpdateOfficerLevels(levels: OfficerLevel[]) {
    this.officerLevels.set(levels);
  }

  handleWithdrawalRequest(event: { amount: number; wallet: 'subsidy' | 'incentive' }) {
    const user = this.currentUserForProfile();
    if (!user) { alert(this.languageService.translate('alert.userNotFoundForWithdrawal')); return; }

    const newRequest: WithdrawalRequest = {
      id: `WDR-${Date.now()}`,
      userId: user.id,
      userType: 'registeredBy' in user ? 'public' : 'officer',
      walletType: event.wallet,
      amount: event.amount,
      requestDate: new Date().toISOString().split('T')[0],
      status: 'pending',
      bankAccountNumber: user.bankAccountNumber,
      bankName: user.bankName,
      ifscCode: user.ifscCode,
      fullName: user.fullName,
      username: user.username
    };
    this.withdrawalRequests.update(reqs => [...reqs, newRequest]);
  }

  handleResolveWithdrawalRequest({ requestId, resolution }: { requestId: string; resolution: 'approved' | 'rejected' }) {
    const request = this.withdrawalRequests().find(r => r.id === requestId);
    if (!request) return;

    this.withdrawalRequests.update(reqs => reqs.map(r => r.id === requestId ? { ...r, status: resolution } : r));

    if (resolution === 'approved') {
        const description = this.languageService.translate('transaction.withdrawalApproved');
        if (request.userType === 'public') {
            this.publicUsers.update(users => users.map(u => 
                u.id === request.userId ? this.addTransactionToUser(u, request.walletType, -request.amount, description) : u
            ));
        } else {
            this.officers.update(officers => officers.map(o =>
                o.id === request.userId ? this.addTransactionToUser(o, request.walletType, -request.amount, description) : o
            ));
        }
    }
  }
  
  handleTopUpRequest(event: Omit<TopUpRequest, 'id' | 'status' | 'requestDate' | 'userType' | 'userId' | 'fullName' | 'username'>) {
    const user = this.currentUserForProfile();
    if (!user) { alert(this.languageService.translate('alert.userNotFoundForTopUp')); return; }

    const newRequest: TopUpRequest = {
      ...event,
      id: `TUP-${Date.now()}`,
      userId: user.id,
      userType: 'registeredBy' in user ? 'public' : 'officer',
      requestDate: new Date().toISOString().split('T')[0],
      status: 'pending',
      fullName: user.fullName,
      username: user.username
    };
    this.topUpRequests.update(reqs => [...reqs, newRequest]);
  }
  
  handleResolveTopUpRequest({ requestId, resolution }: { requestId: string; resolution: 'approved' | 'rejected' }) {
    const request = this.topUpRequests().find(r => r.id === requestId);
    if (!request) return;

    this.topUpRequests.update(reqs => reqs.map(r => r.id === requestId ? { ...r, status: resolution } : r));
    
    if (resolution === 'approved') {
        const description = this.languageService.translate('transaction.topUpApproved');
        if (request.userType === 'public') {
            this.publicUsers.update(users => users.map(u => 
                u.id === request.userId ? this.addTransactionToUser(u, 'main', request.amount, description) : u
            ));
        } else {
            this.officers.update(officers => officers.map(o =>
                o.id === request.userId ? this.addTransactionToUser(o, 'main', request.amount, description) : o
            ));
        }
    }
  }
  
  handleQrCodeUpdate(qrCodeUrl: string | null) {
    this.topUpQrCodeUrl.set(qrCodeUrl);
  }
  
  handleP2pTransfer(event: { fromId: string, fromType: string, toId: string, toType: 'public' | 'officer', amount: number }) {
    const { fromId, toId, toType, amount } = event;
    const fromUser = this.currentUserForProfile();
    const recipient = toType === 'public'
      ? this.publicUsers().find(u => u.id === toId)
      : this.officers().find(o => o.id === toId);
    
    if (!fromUser || !recipient) return;

    const descSent = `${this.languageService.translate('transaction.sentTo')} ${recipient.username}`;
    const descReceived = `${this.languageService.translate('transaction.receivedFrom')} ${fromUser.username}`;

    // Debit from sender
    if ('registeredBy' in fromUser) { // Public user
      this.publicUsers.update(users => users.map(u => u.id === fromId ? this.addTransactionToUser(u, 'psyCoin', -amount, descSent) : u));
    } else { // Officer
      this.officers.update(officers => officers.map(o => o.id === fromId ? this.addTransactionToUser(o, 'psyCoin', -amount, descSent) : o));
    }

    // Credit to receiver
    if (toType === 'public') {
      this.publicUsers.update(users => users.map(u => u.id === toId ? this.addTransactionToUser(u, 'psyCoin', amount, descReceived) : u));
    } else { // Officer
      this.officers.update(officers => officers.map(o => o.id === toId ? this.addTransactionToUser(o, 'psyCoin', amount, descReceived) : o));
    }
  }
  
  handleQrCodeScanned(data: { id: string, type: 'public' | 'officer' }) {
    this.p2pRecipientTarget.set(data);
    this.onNavigate('p2p_transfer');
  }

  addPublicUser(event: { userData: Omit<PublicUser, 'id' | 'wallets' | 'status'>; callback: (newUser: PublicUser) => void; }) {
    const { userData, callback } = event;
    
    const latestIdNumber = this.publicUsers()
      .filter(u => u.state === userData.state && u.id.startsWith(`PSY-${userData.state}-`))
      .map(u => {
        const parts = u.id.split('-');
        return parts.length === 3 ? parseInt(parts[2], 10) : NaN;
      })
      .filter(num => !isNaN(num))
      .reduce((max, num) => Math.max(max, num), 0);

    const newIdNumber = (latestIdNumber + 1).toString().padStart(8, '0');

    const newUser: PublicUser = {
      ...userData,
      id: `PSY-${userData.state}-${newIdNumber}`,
      wallets: this.createDefaultWallets(),
      status: 'active',
    };

    this.publicUsers.update(users => [...users, newUser]);
    
    callback(newUser);
  }

  handleApplicationSubmission(appData: ApplicationData) {
    const newApp: PendingApplication = {
        ...appData,
        id: `APP-${Date.now()}`,
        submissionDate: new Date().toISOString().split('T')[0],
        status: 'pending'
    };
    this.pendingApplications.update(apps => [...apps, newApp]);
  }
  
  handleApproveApplication({ applicationId, officerUsername }: { applicationId: string; officerUsername: string; }) {
      const app = this.pendingApplications().find(a => a.id === applicationId);
      if (!app) return;

      this.pendingApplications.update(apps => apps.filter(a => a.id !== applicationId));
      
      const newUserData: Omit<PublicUser, 'id' | 'wallets' | 'status'> = {
        fullName: app.fullName, phoneNumber: app.phoneNumber, address: app.address,
        dob: app.dob, panNumber: app.panNumber, registeredBy: officerUsername, state: app.state,
        username: app.username, password: app.password, profilePicture: app.profilePicture,
        occupation: app.occupation,
        nomineeName: app.nomineeName,
        nomineeAge: app.nomineeAge,
        nomineeRelation: app.nomineeRelation
      };

      this.addPublicUser({ userData: newUserData, callback: () => {} });
  }

  handleRejectApplication(applicationId: string) {
      this.pendingApplications.update(apps => apps.filter(a => a.id !== applicationId));
  }
  
  handleOrderPsyCard() {
    const userId = this.loggedInPublicUserId();
    if (!userId) return;

    this.publicUsers.update(users => users.map(u => {
        if (u.id === userId) {
            const user = this.publicUsers().find(user => user.id === userId);
            if (!user || user.wallets.main.balance < 100) return u;

            const updatedUser = this.addTransactionToUser(u, 'main', -100, this.languageService.translate('transaction.orderPhysicalCard'));

            const newOrder: PhysicalCardOrder = {
              id: `CARD-ORD-${Date.now()}`,
              userId: user.id,
              fullName: user.fullName,
              address: user.address,
              phoneNumber: user.phoneNumber,
              orderDate: new Date().toISOString().split('T')[0],
              status: 'Pending'
            };
            this.physicalCardOrders.update(orders => [...orders, newOrder]);

            return updatedUser;
        }
        return u;
    }));
  }
  
  handleUpdateCardOrderStatus(event: { orderId: string, status: 'Printed' | 'Shipped' }) {
    this.physicalCardOrders.update(orders => orders.map(o => o.id === event.orderId ? { ...o, status: event.status } : o));
  }

  handleTermsUpdate(content: string) {
    this.termsAndConditions.set(content);
  }
  
  handleNewsUrlUpdate(url: string) {
    this.newsUrl.set(url);
  }

  handleGameUrlUpdate(url: string) {
    this.gameUrl.set(url);
  }

  handleCreateArticle(article: Omit<HealthArticle, 'id'>) {
    this.healthArticles.update(articles => [...articles, { ...article, id: `ART-${Date.now()}` }]);
  }

  handleDeleteArticle(id: string) {
    this.healthArticles.update(articles => articles.filter(a => a.id !== id));
  }
  
  handleCreateScholarship(scholarship: Omit<Scholarship, 'id'>) {
    this.scholarships.update(s => [...s, { ...scholarship, id: `SCH-${Date.now()}` }]);
  }

  handleDeleteScholarship(id: string) {
    this.scholarships.update(s => s.filter(item => item.id !== id));
  }

  handleCreateCourse(course: Omit<OnlineCourse, 'id'>) {
    this.onlineCourses.update(c => [...c, { ...course, id: `COU-${Date.now()}` }]);
  }

  handleDeleteCourse(id: string) {
    this.onlineCourses.update(c => c.filter(item => item.id !== id));
  }
  
  handleCreateExamLink(link: Omit<ExamLink, 'id'>) {
    this.examLinks.update(links => [...links, { ...link, id: `EXM-${Date.now()}` }]);
  }

  handleDeleteExamLink(id: string) {
    this.examLinks.update(links => links.filter(l => l.id !== id));
  }

  handleCreateEducationLead(event: { type: 'Distance Education' | 'Career Counseling'; details: string }) {
    const user = this.currentUserForProfile();
    if (!user) return;
    const newLead: EducationLead = {
      id: `LEAD-${Date.now()}`,
      userId: user.id,
      username: user.username!,
      fullName: user.fullName!,
      type: event.type,
      requestDetails: event.details,
      date: new Date().toISOString().split('T')[0],
      status: 'Pending',
    };
    this.educationLeads.update(leads => [...leads, newLead]);
  }

  handleUpdateLeadStatus(leadId: string) {
    this.educationLeads.update(leads =>
      leads.map(l => (l.id === leadId ? { ...l, status: 'Contacted' } : l))
    );
  }
  
  handleCreateSkillProgram(program: Omit<SkillProgram, 'id'>) {
    this.skillPrograms.update(programs => [...programs, { ...program, id: `SKILL-${Date.now()}` }]);
  }

  handleDeleteSkillProgram(id: string) {
    this.skillPrograms.update(programs => programs.filter(p => p.id !== id));
  }

  handleEnrollInSkillProgram(programId: string) {
    const user = this.loggedInPublicUser();
    if (!user) return;
    const newEnrollment: UserSkillEnrollment = {
      id: `ENR-${user.id}-${programId}`,
      userId: user.id,
      programId: programId,
      enrollmentDate: new Date().toISOString().split('T')[0],
      status: 'enrolled',
    };
    this.userSkillEnrollments.update(e => [...e, newEnrollment]);
  }

  handleMarkSkillComplete(enrollmentId: string) {
    this.userSkillEnrollments.update(enrollments =>
      enrollments.map(e =>
        e.id === enrollmentId ? { ...e, status: 'completed', completionDate: new Date().toISOString().split('T')[0] } : e
      )
    );
  }

  handleViewCertificate(enrollment: UserSkillEnrollment) {
    this.selectedEnrollmentForCertificate.set(enrollment);
    this.onNavigate('view_certificate');
  }

  // New Health Module Handlers
  handleCreateDoctor(doctor: Omit<Doctor, 'id'>) {
      this.doctors.update(d => [...d, { ...doctor, id: `DOC-${Date.now()}` }]);
  }
  handleUpdateDoctor(doctor: Doctor) {
      this.doctors.update(d => d.map(item => item.id === doctor.id ? doctor : item));
  }
  handleDeleteDoctor(id: string) {
      this.doctors.update(d => d.filter(item => item.id !== id));
  }
  handleCreateHospital(hospital: Omit<Hospital, 'id'>) {
      this.hospitals.update(h => [...h, { ...hospital, id: `HOS-${Date.now()}` }]);
  }
  handleUpdateHospital(hospital: Hospital) {
      this.hospitals.update(h => h.map(item => item.id === hospital.id ? hospital : item));
  }
  handleDeleteHospital(id: string) {
      this.hospitals.update(h => h.filter(item => item.id !== id));
  }
  handleCreateAppointment(event: { doctorId: string; notes?: string }) {
      const user = this.loggedInPublicUser();
      const doctor = this.doctors().find(d => d.id === event.doctorId);
      if (!user || !doctor) return;

      const newAppointment: Appointment = {
          id: `APPT-${Date.now()}`,
          userId: user.id,
          username: user.username,
          fullName: user.fullName,
          doctorId: doctor.id,
          doctorName: doctor.name,
          requestDate: new Date().toISOString().split('T')[0],
          status: 'pending',
          notes: event.notes
      };
      this.appointments.update(a => [...a, newAppointment]);
  }
  handleUpdateAppointment(appointment: Appointment) {
      this.appointments.update(a => a.map(item => item.id === appointment.id ? appointment : item));
  }
  handleCreateHealthRecord(record: Omit<HealthRecord, 'id'>) {
      this.healthRecords.update(hr => [...hr, { ...record, id: `REC-${Date.now()}` }]);
  }

  // New Complaint Box Handlers
  handleCreateComplaint(event: { subject: string; details: string; callback: (complaintId: string) => void }) {
    const user = this.loggedInPublicUser();
    if (!user) return;

    const newComplaint: Complaint = {
        id: `CMP-${Date.now()}`,
        userId: user.id,
        username: user.username,
        subject: event.subject,
        details: event.details,
        submittedDate: new Date().toISOString(),
        status: 'pending'
    };
    this.complaints.update(c => [...c, newComplaint]);
    event.callback(newComplaint.id);
  }

  handleResolveComplaint(event: { complaintId: string; resolution: string }) {
    this.complaints.update(complaints => 
      complaints.map(c => 
        c.id === event.complaintId 
          ? { ...c, status: 'resolved', resolution: event.resolution, resolvedDate: new Date().toISOString() } 
          : c
      )
    );
  }
  
  handlePopupUpdate(message: PopupMessage) {
    this.popupMessage.set(message);
  }

  handleClosePopup() {
    this.showPopup.set(false);
    sessionStorage.setItem('PSY_POPUP_SHOWN', 'true');
  }

  handleSchemeRatesUpdate(rates: { subsidyRate: number, pfRate: number }) {
    this.subsidyRate.set(rates.subsidyRate);
    this.pfContributionRate.set(rates.pfRate);
  }

  handlePsyCoinPriceUpdate(newPrice: number) {
    this.psyCoinPrice.set(newPrice);
  }

  handleCreateExternalService(service: Omit<ExternalService, 'id'>) {
    this.externalServices.update(s => [...s, { ...service, id: `EXTSVC-${Date.now()}` }]);
  }

  handleUpdateExternalService(service: ExternalService) {
    this.externalServices.update(s => s.map(item => item.id === service.id ? service : item));
  }

  handleDeleteExternalService(id: string) {
    this.externalServices.update(s => s.filter(item => item.id !== id));
  }
}