
import { Injectable } from '@angular/core';
// FIX: GroundingChunk is not an exported member of @google/genai. It is defined locally below.
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";

// FIX: Added local definition for GroundingChunk based on Gemini API documentation.
export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  groundingChunks?: GroundingChunk[];
}

export interface Nutrient {
  name: string;
  amount: string;
}
export interface NutritionInfo {
  foodName: string;
  description: string;
  nutrients: Nutrient[];
  error?: string;
}


@Injectable({ providedIn: 'root' })
export class GeminiService {
  private ai: GoogleGenAI;
  private apiKey = process.env.API_KEY;

  constructor() {
    if (!this.apiKey) {
      console.error("API_KEY environment variable not set.");
      throw new Error("API Key is missing.");
    }
    this.ai = new GoogleGenAI({ apiKey: this.apiKey });
  }

  async generateGroundedResponse(prompt: string): Promise<GenerateContentResponse> {
    return await this.ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
  }

  async generateFastResponse(prompt: string): Promise<GenerateContentResponse> {
    return await this.ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: { thinkingConfig: { thinkingBudget: 0 } }
    });
  }

  async generateThoughtfulResponse(prompt: string): Promise<GenerateContentResponse> {
    // FIX: Updated model to 'gemini-2.5-flash' as per guidelines.
    // For high-quality responses, thinkingConfig is omitted to use the default thinking process.
    return await this.ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
  }

  async analyzeFoodImage(base64Data: string): Promise<NutritionInfo> {
    const imagePart = {
      inlineData: { mimeType: 'image/jpeg', data: base64Data },
    };
    
    const textPart = {
      text: `Analyze the food item in this image and provide a nutritional breakdown per 100g serving. If the food is not identifiable, explain why in the 'error' field.`
    };

    try {
        const response = await this.ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        foodName: { 
                            type: Type.STRING,
                            description: "The name of the food item identified."
                        },
                        description: { 
                            type: Type.STRING,
                            description: "A brief, one-sentence description of the food."
                        },
                        nutrients: {
                            type: Type.ARRAY,
                            description: "A list of nutrients and their amounts per 100g.",
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    name: { 
                                        type: Type.STRING,
                                        description: "Name of the nutrient (e.g., Calories, Protein)."
                                    },
                                    amount: { 
                                        type: Type.STRING,
                                        description: "Amount of the nutrient with units (e.g., 52 kcal, 0.3 g)."
                                    }
                                },
                            }
                        },
                        error: { 
                            type: Type.STRING,
                            description: "An error message if the food cannot be identified."
                        }
                    }
                }
            }
        });
        
        const responseText = response.text.trim();
        return JSON.parse(responseText) as NutritionInfo;

    } catch (e) {
        console.error("GeminiService.analyzeFoodImage Error:", e);
        throw e;
    }
  }

  async generateImage(prompt: string): Promise<string> {
    const response = await this.ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: prompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/png',
        aspectRatio: '1:1',
      },
    });

    const base64ImageBytes = response.generatedImages[0].image.imageBytes;
    return `data:image/png;base64,${base64ImageBytes}`;
  }

  async generateImagePromptFromImage(base64Data: string, userInstruction: string): Promise<string> {
    const imagePart = {
      inlineData: { mimeType: 'image/jpeg', data: base64Data },
    };
    
    const instructionText = userInstruction.trim() 
        ? `The user wants to modify this image with the following instruction: "${userInstruction}".`
        : `The user has not provided any specific instruction; describe the image creatively.`;

    const textPart = {
      text: `Analyze the provided image. ${instructionText} Based on this, generate a new, highly detailed, and creative text prompt that an AI image generator can use to create the final desired image. The prompt should be a single, descriptive paragraph. Do not add any conversational text, just output the raw prompt itself.`
    };

    const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, textPart] },
    });
    
    return response.text.trim();
  }
}
