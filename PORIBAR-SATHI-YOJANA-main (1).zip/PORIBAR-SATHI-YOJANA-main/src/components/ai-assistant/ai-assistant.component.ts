import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GeminiService, ChatMessage } from '../../services/gemini.service';
import { LanguageService } from '../../services/language.service';
import { TranslatePipe } from '../../pipes/translate.pipe';

type AiMode = 'fast' | 'thinking' | 'grounded';

@Component({
  selector: 'app-ai-assistant',
  standalone: true,
  imports: [FormsModule, TranslatePipe],
  templateUrl: './ai-assistant.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AiAssistantComponent {
  @Output() navigate = new EventEmitter<string>();
  appLogoUrl = input<string | null>(null);
  
  private geminiService = inject(GeminiService);
  private languageService = inject(LanguageService);

  prompt = signal('');
  messages = signal<ChatMessage[]>([]);
  loading = signal(false);
  error = signal<string | null>(null);
  selectedMode = signal<AiMode>('fast');

  constructor() {
    this.messages.set([{ role: 'model', content: this.languageService.translate('aiAssistant.hello') }]);
  }

  async handleSubmit() {
    const currentPrompt = this.prompt().trim();
    if (!currentPrompt || this.loading()) return;

    this.loading.set(true);
    this.error.set(null);
    this.messages.update(m => [...m, { role: 'user', content: currentPrompt }]);
    this.prompt.set('');

    try {
      let response;
      switch(this.selectedMode()) {
        case 'fast':
          response = await this.geminiService.generateFastResponse(currentPrompt);
          break;
        case 'thinking':
          response = await this.geminiService.generateThoughtfulResponse(currentPrompt);
          break;
        case 'grounded':
          response = await this.geminiService.generateGroundedResponse(currentPrompt);
          break;
      }

      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      this.messages.update(m => [...m, { role: 'model', content: response.text, groundingChunks }]);
      
    } catch (e) {
      console.error('AI Assistant Error:', e);
      let userFriendlyMessage = this.languageService.translate('aiAssistant.error.unexpected');

      if (e instanceof Error) {
        const message = e.message.toLowerCase();
        if (message.includes('api key')) {
          userFriendlyMessage = this.languageService.translate('aiAssistant.error.apiKey');
        } else if (message.includes('quota')) {
          userFriendlyMessage = this.languageService.translate('aiAssistant.error.quota');
        } else if (message.includes('fetch') || message.includes('network')) {
          userFriendlyMessage = this.languageService.translate('aiAssistant.error.network');
        } else if (message.includes('blocked')) {
          userFriendlyMessage = this.languageService.translate('aiAssistant.error.blocked');
        } else {
          userFriendlyMessage = this.languageService.translate('aiAssistant.error.server');
          console.error('Unhandled AI Error details:', e.message);
        }
      }
      
      const fullErrorMessage = this.languageService.translate('aiAssistant.error.apology').replace('{{message}}', userFriendlyMessage);
      this.error.set(userFriendlyMessage);
      this.messages.update(m => [...m, { role: 'model', content: fullErrorMessage }]);
    } finally {
      this.loading.set(false);
    }
  }

  goBack() {
    this.navigate.emit('home');
  }
}