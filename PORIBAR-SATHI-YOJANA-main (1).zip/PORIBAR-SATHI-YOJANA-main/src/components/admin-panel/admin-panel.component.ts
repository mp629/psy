import { Component, ChangeDetectionStrategy, Output, EventEmitter, input, computed, inject } from '@angular/core';
import { Officer } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { LanguageService } from '../../services/language.service';

interface Kpi {
  titleKey: string;
  value: string;
  icon: string;
  color: string;
}

interface AdminAction {
  titleKey: string;
  descriptionKey: string;
  icon: string;
  action: string;
}

@Component({
  selector: 'app-admin-panel',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './admin-panel.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminPanelComponent {
  @Output() navigate = new EventEmitter<string>();
  @Output() logout = new EventEmitter<void>();
  registeredIndividualsCount = input(0);
  pendingApplicationsCount = input(0);
  pendingAppointmentsCount = input(0);
  pendingComplaintsCount = input(0);
  allOfficers = input<Officer[]>([]);
  appLogoUrl = input<string | null>(null);

  languageService = inject(LanguageService);

  kpis = computed<Kpi[]>(() => [
    { titleKey: 'adminPanel.kpi.totalOfficers', value: this.allOfficers()!.length.toString(), icon: 'supervised_user_circle', color: 'text-blue-500' },
    { titleKey: 'adminPanel.kpi.totalRegistrations', value: this.registeredIndividualsCount().toString(), icon: 'groups', color: 'text-green-500' },
    { titleKey: 'adminPanel.kpi.pendingApplications', value: this.pendingApplicationsCount().toString(), icon: 'pending_actions', color: 'text-amber-500' },
    { titleKey: 'adminPanel.kpi.pendingAppointments', value: this.pendingAppointmentsCount().toString(), icon: 'event_busy', color: 'text-red-500' },
    { titleKey: 'adminPanel.kpi.pendingComplaints', value: this.pendingComplaintsCount().toString(), icon: 'report_problem', color: 'text-orange-500' },
    
  ]);

  actions: AdminAction[] = [
    {
      titleKey: 'adminPanel.action.applicationManagement',
      descriptionKey: 'adminPanel.action.applicationManagement.desc',
      icon: 'rule',
      action: 'application_management'
    },
    {
      titleKey: 'adminPanel.action.complaintManagement',
      descriptionKey: 'adminPanel.action.complaintManagement.desc',
      icon: 'support_agent',
      action: 'complaint_management'
    },
    {
      titleKey: 'adminPanel.action.appointmentManagement',
      descriptionKey: 'adminPanel.action.appointmentManagement.desc',
      icon: 'event_available',
      action: 'appointment_management'
    },
    {
      titleKey: 'adminPanel.action.doctorManagement',
      descriptionKey: 'adminPanel.action.doctorManagement.desc',
      icon: 'medical_services',
      action: 'doctor_management'
    },
    {
      titleKey: 'adminPanel.action.hospitalManagement',
      descriptionKey: 'adminPanel.action.hospitalManagement.desc',
      icon: 'local_hospital',
      action: 'hospital_management'
    },
    {
      titleKey: 'adminPanel.action.userManagement',
      descriptionKey: 'adminPanel.action.userManagement.desc',
      icon: 'manage_accounts',
      action: 'user_management'
    },
    {
      titleKey: 'adminPanel.action.walletManagement',
      descriptionKey: 'adminPanel.action.walletManagement.desc',
      icon: 'savings',
      action: 'wallet_management'
    },
    {
      titleKey: 'adminPanel.action.withdrawalManagement',
      descriptionKey: 'adminPanel.action.withdrawalManagement.desc',
      icon: 'approval',
      action: 'withdrawal_management'
    },
    {
      titleKey: 'adminPanel.action.topUpManagement',
      descriptionKey: 'adminPanel.action.topUpManagement.desc',
      icon: 'add_card',
      action: 'top_up_management'
    },
    {
      titleKey: 'adminPanel.action.topUpQrCode',
      descriptionKey: 'adminPanel.action.topUpQrCode.desc',
      icon: 'qr_code_2',
      action: 'qr_code_management'
    },
     {
      titleKey: 'adminPanel.action.viewAllRegistrations',
      descriptionKey: 'adminPanel.action.viewAllRegistrations.desc',
      icon: 'list_alt',
      action: 'view_all_registrations'
    },
    {
      titleKey: 'adminPanel.action.incentiveReports',
      descriptionKey: 'adminPanel.action.incentiveReports.desc',
      icon: 'bar_chart',
      action: 'incentive_report'
    },
    {
      titleKey: 'adminPanel.action.orderManagement',
      descriptionKey: 'adminPanel.action.orderManagement.desc',
      icon: 'local_shipping',
      action: 'order_management'
    },
    {
      titleKey: 'adminPanel.action.physicalCardOrders',
      descriptionKey: 'adminPanel.action.physicalCardOrders.desc',
      icon: 'credit_card',
      action: 'card_order_management'
    },
    {
      titleKey: 'adminPanel.action.coinPriceManagement',
      descriptionKey: 'adminPanel.action.coinPriceManagement.desc',
      icon: 'price_change',
      action: 'manage_coin_price'
    },
    {
      titleKey: 'adminPanel.action.schemeSettings',
      descriptionKey: 'adminPanel.action.schemeSettings.desc',
      icon: 'schema',
      action: 'scheme_settings'
    },
    {
      titleKey: 'adminPanel.action.subsidyStoreControl',
      descriptionKey: 'adminPanel.action.subsidyStoreControl.desc',
      icon: 'store',
      action: 'product_management'
    },
    {
      titleKey: 'adminPanel.action.categoryManagement',
      descriptionKey: 'adminPanel.action.categoryManagement.desc',
      icon: 'category',
      action: 'category_management'
    },
    {
      titleKey: 'adminPanel.action.newsManagement',
      descriptionKey: 'adminPanel.action.newsManagement.desc',
      icon: 'link',
      action: 'news_management'
    },
    {
      titleKey: 'adminPanel.action.gameManagement',
      descriptionKey: 'adminPanel.action.gameManagement.desc',
      icon: 'sports_esports',
      action: 'game_management'
    },
    {
      titleKey: 'adminPanel.action.articleManagement',
      descriptionKey: 'adminPanel.action.articleManagement.desc',
      icon: 'article',
      action: 'article_management'
    },
    {
      titleKey: 'adminPanel.action.examLinkManagement',
      descriptionKey: 'adminPanel.action.examLinkManagement.desc',
      icon: 'grading',
      action: 'exam_link_management'
    },
    {
      titleKey: 'adminPanel.action.scholarshipManagement',
      descriptionKey: 'adminPanel.action.scholarshipManagement.desc',
      icon: 'school',
      action: 'scholarship_management'
    },
    {
      titleKey: 'adminPanel.action.courseManagement',
      descriptionKey: 'adminPanel.action.courseManagement.desc',
      icon: 'video_library',
      action: 'course_management'
    },
    {
      titleKey: 'adminPanel.action.skillProgramManagement',
      descriptionKey: 'adminPanel.action.skillProgramManagement.desc',
      icon: 'construction',
      action: 'skill_program_management'
    },
    {
      titleKey: 'adminPanel.action.educationLeads',
      descriptionKey: 'adminPanel.action.educationLeads.desc',
      icon: 'contact_mail',
      action: 'education_leads_management'
    },
    {
      titleKey: 'adminPanel.action.officerManagement',
      descriptionKey: 'adminPanel.action.officerManagement.desc',
      icon: 'badge',
      action: 'officer_management'
    },
    {
      titleKey: 'adminPanel.action.officerLevelTitles',
      descriptionKey: 'adminPanel.action.officerLevelTitles.desc',
      icon: 'military_tech',
      action: 'level_management'
    },
    {
      titleKey: 'adminPanel.action.roleManagement',
      descriptionKey: 'adminPanel.action.roleManagement.desc',
      icon: 'admin_panel_settings',
      action: 'role_management'
    },
    {
      titleKey: 'adminPanel.action.logoManagement',
      descriptionKey: 'adminPanel.action.logoManagement.desc',
      icon: 'image',
      action: 'logo_management'
    },
    {
      titleKey: 'adminPanel.action.idCardManagement',
      descriptionKey: 'adminPanel.action.idCardManagement.desc',
      icon: 'contact_card',
      action: 'id_card_management'
    },
    {
      titleKey: 'adminPanel.action.termsManagement',
      descriptionKey: 'adminPanel.action.termsManagement.desc',
      icon: 'gavel',
      action: 'terms_management'
    },
    {
      titleKey: 'adminPanel.action.changePassword',
      descriptionKey: 'adminPanel.action.changePassword.desc',
      icon: 'lock_reset',
      action: 'change_password'
    },
    {
      titleKey: 'adminPanel.action.bannerManagement',
      descriptionKey: 'adminPanel.action.bannerManagement.desc',
      icon: 'view_carousel',
      action: 'banner_management'
    },
    {
      titleKey: 'adminPanel.action.advertisementBanners',
      descriptionKey: 'adminPanel.action.advertisementBanners.desc',
      icon: 'campaign',
      action: 'advertisement_management'
    },
    {
      titleKey: 'adminPanel.action.popupManagement',
      descriptionKey: 'adminPanel.action.popupManagement.desc',
      icon: 'chat_bubble',
      action: 'popup_management'
    },
    {
      titleKey: 'adminPanel.action.serviceManagement',
      descriptionKey: 'adminPanel.action.serviceManagement.desc',
      icon: 'settings_applications',
      action: 'service_management'
    },
     {
      titleKey: 'adminPanel.action.sendNotifications',
      descriptionKey: 'adminPanel.action.sendNotifications.desc',
      icon: 'campaign',
      action: 'send_notifications'
    }
  ];

  goBack() {
    this.navigate.emit('home');
  }
  
  onLogout() {
    this.logout.emit();
  }

  onAdminActionClick(action: string) {
    const service = this.actions.find(a => a.action === action);
    if (!service) {
      this.navigate.emit(`coming_soon:a feature`);
      return;
    }

    const implementedActions = ['officer_management', 'view_all_registrations', 'change_password', 'banner_management', 'wallet_management', 'user_management', 'product_management', 'category_management', 'order_management', 'logo_management', 'id_card_management', 'role_management', 'level_management', 'incentive_report', 'withdrawal_management', 'top_up_management', 'qr_code_management', 'application_management', 'card_order_management', 'terms_management', 'article_management', 'scholarship_management', 'course_management', 'exam_link_management', 'education_leads_management', 'skill_program_management', 'doctor_management', 'hospital_management', 'appointment_management', 'news_management', 'game_management', 'complaint_management', 'popup_management', 'scheme_settings', 'manage_coin_price', 'service_management', 'advertisement_management'];
    if (implementedActions.includes(action)) {
      this.navigate.emit(action);
    } else {
      this.navigate.emit(`coming_soon:${service.titleKey}`);
    }
  }
}
