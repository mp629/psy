import { Component, ChangeDetectionStrategy, Output, EventEmitter, input } from '@angular/core';
import { PublicUser } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

interface HealthService {
  title: string;
  description: string;
  icon: string;
  action: string;
}

@Component({
  selector: 'app-health-services',
  standalone: true,
  templateUrl: './health-services.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [TranslatePipe]
})
export class HealthServicesComponent {
  @Output() navigate = new EventEmitter<string>();
  appLogoUrl = input<string | null>(null);
  loggedInPublicUser = input<PublicUser | null>(null);

  services: HealthService[] = [
    {
      title: 'health.service.symptomChecker',
      description: 'health.service.symptomChecker.desc',
      icon: 'monitor_heart',
      action: 'ai_symptom_checker'
    },
    {
      title: 'health.service.appointment',
      description: 'health.service.appointment.desc',
      icon: 'event',
      action: 'book_appointment'
    },
    {
      title: 'health.service.myAppointments',
      description: 'health.service.myAppointments.desc',
      icon: 'pending_actions',
      action: 'my_appointments'
    },
    {
      title: 'health.service.videoConsult',
      description: 'health.service.videoConsult.desc',
      icon: 'videocam',
      action: 'video_consultation'
    },
    {
      title: 'health.service.findHospitals',
      description: 'health.service.findHospitals.desc',
      icon: 'local_hospital',
      action: 'find_hospitals'
    },
    {
      title: 'health.service.viewRecords',
      description: 'health.service.viewRecords.desc',
      icon: 'receipt_long',
      action: 'view_health_records'
    },
    {
      title: 'health.service.healthTips',
      description: 'health.service.healthTips.desc',
      icon: 'lightbulb',
      action: 'health_tips'
    },
    {
      title: 'health.service.bmi',
      description: 'health.service.bmi.desc',
      icon: 'scale',
      action: 'bmi_calculator'
    },
    {
      title: 'health.service.orderMedicines',
      description: 'health.service.orderMedicines.desc',
      icon: 'medication',
      action: 'order_medicines'
    },
  ];

  goBack() {
    this.navigate.emit(this.loggedInPublicUser() ? 'public_panel' : 'home');
  }

  onServiceClick(service: HealthService) {
    switch(service.action) {
        case 'order_medicines':
            this.navigate.emit('store');
            break;
        default:
            this.navigate.emit(service.action);
    }
  }
}