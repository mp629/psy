import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { PublicUser, Officer } from '../../app.component';

// Custom validator to check for unique username
export function uniqueUsernameValidator(existingUsernames: string[]) {
  return (control: AbstractControl): ValidationErrors | null => {
    if (existingUsernames.includes(control.value)) {
      return { usernameTaken: true };
    }
    return null;
  };
}

@Component({
  selector: 'app-public-registration',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './public-registration.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PublicRegistrationComponent {
  @Output() navigate = new EventEmitter<void>();
  @Output() register = new EventEmitter<{
    userData: Omit<PublicUser, 'id' | 'wallets' | 'status'>;
    callback: (newUser: PublicUser) => void;
  }>();
  
  loggedInOfficer = input<Officer | null>(null);
  existingUsernames = input.required<string[]>();
  appLogoUrl = input<string | null>(null);
  
  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);

  loading = signal(false);
  newlyCreatedUser = signal<PublicUser | null>(null);

  registrationForm = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(3)]],
    phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
    address: ['', [Validators.required, Validators.minLength(10)]],
    dob: ['', [Validators.required]],
    panNumber: ['', [Validators.required, Validators.pattern('^[A-Z]{5}[0-9]{4}[A-Z]{1}$')]],
    username: ['', [Validators.required, Validators.minLength(4)]],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  constructor() {
    effect(() => {
        const usernameControl = this.registrationForm.get('username');
        if (usernameControl) {
            usernameControl.setValidators([
                Validators.required,
                Validators.minLength(4),
                uniqueUsernameValidator(this.existingUsernames())
            ]);
            usernameControl.updateValueAndValidity();
        }
    });
  }

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.registrationForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  getControlError(controlName: string, errorName: string): boolean {
    const control = this.registrationForm.get(controlName);
    return !!control && control.hasError(errorName) && (control.dirty || control.touched);
  }

  toUpperCase(event: Event, controlName: string) {
    const input = event.target as HTMLInputElement;
    const uppercaseValue = input.value.toUpperCase();
    this.registrationForm.get(controlName)?.setValue(uppercaseValue, { emitEvent: false });
    input.value = uppercaseValue;
  }

  onSubmit() {
    if (this.registrationForm.invalid) {
      this.registrationForm.markAllAsTouched();
      return;
    }
    
    const officer = this.loggedInOfficer();
    if (!officer) {
        alert('Error: No logged in officer found. Cannot complete registration.');
        return;
    }

    this.loading.set(true);
    // Simulate API call
    setTimeout(() => {
      const formData = this.registrationForm.value;
      const registeredData: Omit<PublicUser, 'id' | 'wallets' | 'status'> = {
        fullName: formData.fullName!,
        phoneNumber: formData.phoneNumber!,
        address: formData.address!,
        dob: formData.dob!,
        panNumber: formData.panNumber!,
        username: formData.username!,
        password: formData.password!,
        registeredBy: officer.username,
        state: officer.state
      };

      this.register.emit({
        userData: registeredData,
        callback: (newUser: PublicUser) => {
          this.loading.set(false);
          this.newlyCreatedUser.set(newUser);
          this.registrationForm.reset();
        }
      });
    }, 1500);
  }

  startNewRegistration() {
    this.newlyCreatedUser.set(null);
  }
}