import { Component, ChangeDetectionStrategy, input, output, inject, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-game-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './game-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GameManagementComponent {
  currentGameUrl = input<string | null>(null);
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  gameUrlUpdate = output<string>();

  private fb: FormBuilder = inject(FormBuilder);

  gameForm = this.fb.group({
    url: ['', [Validators.required, Validators.pattern('^https?://.+$')]],
  });

  constructor() {
    effect(() => {
      this.gameForm.patchValue({ url: this.currentGameUrl() || '' });
    });
  }

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.gameForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onSubmit() {
    if (this.gameForm.invalid) {
      this.gameForm.markAllAsTouched();
      return;
    }
    this.gameUrlUpdate.emit(this.gameForm.value.url!);
    alert('Game URL updated successfully!');
    this.gameForm.markAsPristine();
  }
}