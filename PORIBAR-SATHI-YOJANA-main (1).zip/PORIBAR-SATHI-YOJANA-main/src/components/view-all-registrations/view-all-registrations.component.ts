import { Component, ChangeDetectionStrategy, Output, EventEmitter, input } from '@angular/core';
import { RegisteredIndividual } from '../../app.component';

@Component({
  selector: 'app-view-all-registrations',
  standalone: true,
  templateUrl: './view-all-registrations.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ViewAllRegistrationsComponent {
  @Output() navigate = new EventEmitter<string>();
  
  allRegistrations = input.required<RegisteredIndividual[]>();
  appLogoUrl = input<string | null>(null);

  goBack() {
    this.navigate.emit('admin');
  }
}