import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-terms-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './terms-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TermsManagementComponent {
  currentTerms = input.required<string>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() termsUpdate = new EventEmitter<string>();

  private fb: FormBuilder = inject(FormBuilder);

  termsForm = this.fb.group({
    content: ['', [Validators.required, Validators.minLength(50)]],
  });

  constructor() {
    effect(() => {
      this.termsForm.get('content')?.setValue(this.currentTerms());
    });
  }

  goBack() {
    this.navigate.emit();
  }

  onSubmit() {
    if (this.termsForm.invalid) {
      this.termsForm.markAllAsTouched();
      return;
    }
    const newContent = this.termsForm.value.content!;
    this.termsUpdate.emit(newContent);
    alert('Terms and Conditions updated successfully!');
    this.termsForm.markAsPristine();
  }
}
