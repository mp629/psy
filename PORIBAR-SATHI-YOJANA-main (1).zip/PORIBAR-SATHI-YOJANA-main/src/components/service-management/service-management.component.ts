import { Component, ChangeDetectionStrategy, input, output, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ExternalService } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-service-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './service-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ServiceManagementComponent {
  services = input.required<ExternalService[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createService = output<Omit<ExternalService, 'id'>>();
  updateService = output<ExternalService>();
  deleteService = output<string>();

  private fb: FormBuilder = inject(FormBuilder);
  
  editingService = signal<ExternalService | null>(null);

  serviceForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(3)]],
    description: ['', [Validators.required, Validators.minLength(10)]],
    icon: ['public', [Validators.required]],
    url: ['', [Validators.required, Validators.pattern('^https?://.+$')]],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.serviceForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }
  
  onEdit(service: ExternalService) {
    this.editingService.set(service);
    this.serviceForm.patchValue(service);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  onCancelEdit() {
    this.editingService.set(null);
    this.serviceForm.reset({ icon: 'public' });
  }

  onDelete(id: string) {
    if (confirm('Are you sure you want to delete this service link?')) {
      this.deleteService.emit(id);
    }
  }

  onSubmit() {
    if (this.serviceForm.invalid) {
      this.serviceForm.markAllAsTouched();
      return;
    }

    const formValue = this.serviceForm.getRawValue();

    if (this.editingService()) {
      const updatedService: ExternalService = {
        ...this.editingService()!,
        ...formValue,
      };
      this.updateService.emit(updatedService);
    } else {
      this.createService.emit(formValue as Omit<ExternalService, 'id'>);
    }
    this.onCancelEdit();
  }
}
