import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input, DestroyRef, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslatePipe } from '../../pipes/translate.pipe';

export interface ApplicationData {
  fullName: string;
  guardianName: string;
  gender: 'male' | 'female' | 'other';
  dob: string;
  phoneNumber: string;
  email?: string;
  address: string;
  state: string;
  district: string;
  pinCode: string;
  panNumber: string;
  voterId?: string;
  profilePicture?: string; // base64
  panCardImage?: string; // base64
  username: string;
  password: string;
  occupation: string;
  nomineeName?: string;
  nomineeAge?: number;
  nomineeRelation?: string;
}

// Custom validator to check if new password and confirm password match
export function passwordsMatchValidator(control: AbstractControl): ValidationErrors | null {
  const password = control.get('password');
  const confirmPassword = control.get('confirmPassword');
  
  if (password && confirmPassword && password.value !== confirmPassword.value) {
    return { passwordsMismatch: true };
  }
  
  return null;
}

// Custom validator factory to check for unique username
export function uniqueUsernameValidator(existingUsernames: string[]) {
  return (control: AbstractControl): ValidationErrors | null => {
    if (existingUsernames.includes(control.value)) {
      return { usernameTaken: true };
    }
    return null;
  };
}


@Component({
  selector: 'app-apply-psy',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './apply-psy.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ApplyPsyComponent {
  @Output() navigate = new EventEmitter<void>();
  @Output() submitApplication = new EventEmitter<ApplicationData>();
  appLogoUrl = input<string | null>(null);
  allUsernames = input.required<string[]>();
  termsAndConditions = input.required<string>();

  private fb: FormBuilder = inject(FormBuilder);
  private destroyRef = inject(DestroyRef);

  loading = signal(false);
  submissionSuccess = signal(false);
  showTermsModal = signal(false);
  
  profilePicturePreview = signal<string | null>(null);
  panCardImagePreview = signal<string | null>(null);
  districts = signal<string[]>([]);

  private districtsByState: { [key: string]: string[] } = {
    AN: ['Nicobar', 'North and Middle Andaman', 'South Andaman'],
    AP: ['Anantapur', 'Chittoor', 'East Godavari', 'Guntur', 'Krishna', 'Kurnool', 'Prakasam', 'Srikakulam', 'Sri Potti Sriramulu Nellore', 'Visakhapatnam', 'Vizianagaram', 'West Godavari', 'Y.S.R. Kadapa'],
    AR: ['Tawang', 'West Kameng', 'East Kameng', 'Papum Pare', 'Kurung Kumey', 'Kra Daadi', 'Lower Subansiri', 'Upper Subansiri', 'West Siang', 'East Siang', 'Siang', 'Upper Siang', 'Lower Siang', 'Lower Dibang Valley', 'Dibang Valley', 'Anjaw', 'Lohit', 'Namsai', 'Changlang', 'Tirap', 'Longding'],
    AS: ['Baksa', 'Barpeta', 'Biswanath', 'Bongaigaon', 'Cachar', 'Charaideo', 'Chirang', 'Darrang', 'Dhemaji', 'Dhubri', 'Dibrugarh', 'Dima Hasao', 'Goalpara', 'Golaghat', 'Hailakandi', 'Hojai', 'Jorhat', 'Kamrup', 'Kamrup Metropolitan', 'Karbi Anglong', 'Karimganj', 'Kokrajhar', 'Lakhimpur', 'Majuli', 'Morigaon', 'Nagaon', 'Nalbari', 'Sivasagar', 'Sonitpur', 'South Salmara-Mankachar', 'Tinsukia', 'Udalguri', 'West Karbi Anglong'],
    BR: ['Araria', 'Arwal', 'Aurangabad', 'Banka', 'Begusarai', 'Bhagalpur', 'Bhojpur', 'Buxar', 'Darbhanga', 'East Champaran', 'Gaya', 'Gopalganj', 'Jamui', 'Jehanabad', 'Kaimur', 'Katihar', 'Khagaria', 'Kishanganj', 'Lakhisarai', 'Madhepura', 'Madhubani', 'Munger', 'Muzaffarpur', 'Nalanda', 'Nawada', 'Patna', 'Purnia', 'Rohtas', 'Saharsa', 'Samastipur', 'Saran', 'Sheikhpura', 'Sheohar', 'Sitamarhi', 'Siwan', 'Supaul', 'Vaishali', 'West Champaran'],
    CH: ['Chandigarh'],
    CG: ['Balod', 'Baloda Bazar', 'Balrampur', 'Bastar', 'Bemetara', 'Bijapur', 'Bilaspur', 'Dantewada', 'Dhamtari', 'Durg', 'Gariaband', 'Gaurela-Pendra-Marwahi', 'Janjgir-Champa', 'Jashpur', 'Kabirdham', 'Kanker', 'Kondagaon', 'Korba', 'Koriya', 'Mahasamund', 'Mungeli', 'Narayanpur', 'Raigarh', 'Raipur', 'Rajnandgaon', 'Sukma', 'Surajpur', 'Surguja'],
    DD: ['Daman', 'Diu', 'Dadra and Nagar Haveli'],
    DL: ['Central Delhi', 'East Delhi', 'New Delhi', 'North Delhi', 'North East Delhi', 'North West Delhi', 'Shahdara', 'South Delhi', 'South East Delhi', 'South West Delhi', 'West Delhi'],
    GA: ['North Goa', 'South Goa'],
    GJ: ['Ahmedabad', 'Amreli', 'Anand', 'Aravalli', 'Banaskantha', 'Bharuch', 'Bhavnagar', 'Botad', 'Chhota Udaipur', 'Dahod', 'Dang', 'Devbhoomi Dwarka', 'Gandhinagar', 'Gir Somnath', 'Jamnagar', 'Junagadh', 'Kheda', 'Kutch', 'Mahisagar', 'Mehsana', 'Morbi', 'Narmada', 'Navsari', 'Panchmahal', 'Patan', 'Porbandar', 'Rajkot', 'Sabarkantha', 'Surat', 'Surendranagar', 'Tapi', 'Vadodara', 'Valsad'],
    HR: ['Ambala', 'Bhiwani', 'Charkhi Dadri', 'Faridabad', 'Fatehbad', 'Gurugram', 'Hisar', 'Jhajjar', 'Jind', 'Kaithal', 'Karnal', 'Kurukshetra', 'Mahendragarh', 'Nuh', 'Palwal', 'Panchkula', 'Panipat', 'Rewari', 'Rohtak', 'Sirsa', 'Sonipat', 'Yamunanagar'],
    HP: ['Bilaspur', 'Chamba', 'Hamirpur', 'Kangra', 'Kinnaur', 'Kullu', 'Lahaul and Spiti', 'Mandi', 'Shimla', 'Sirmaur', 'Solan', 'Una'],
    JK: ['Anantnag', 'Bandipora', 'Baramulla', 'Budgam', 'Doda', 'Ganderbal', 'Jammu', 'Kathua', 'Kishtwar', 'Kulgam', 'Kupwara', 'Poonch', 'Pulwama', 'Rajouri', 'Ramban', 'Reasi', 'Samba', 'Shopian', 'Srinagar', 'Udhampur'],
    JH: ['Bokaro', 'Chatra', 'Deoghar', 'Dhanbad', 'Dumka', 'East Singhbhum', 'Garhwa', 'Giridih', 'Godda', 'Gumla', 'Hazaribagh', 'Jamtara', 'Khunti', 'Koderma', 'Latehar', 'Lohardaga', 'Pakur', 'Palamu', 'Ramgarh', 'Ranchi', 'Sahebganj', 'Seraikela Kharsawan', 'Simdega', 'West Singhbhum'],
    KA: ['Bagalkot', 'Ballari', 'Belagavi', 'Bengaluru Rural', 'Bengaluru Urban', 'Bidar', 'Chamarajanagar', 'Chikballapur', 'Chikkamagaluru', 'Chitradurga', 'Dakshina Kannada', 'Davanagere', 'Dharwad', 'Gadag', 'Hassan', 'Haveri', 'Kalaburagi', 'Kodagu', 'Kolar', 'Koppal', 'Mandya', 'Mysuru', 'Raichur', 'Ramanagara', 'Shivamogga', 'Tumakuru', 'Udupi', 'Uttara Kannada', 'Vijayanagara', 'Vijayapura', 'Yadgir'],
    KL: ['Alappuzha', 'Ernakulam', 'Idukki', 'Kannur', 'Kasaragod', 'Kollam', 'Kottayam', 'Kozhikode', 'Malappuram', 'Palakkad', 'Pathanamthitta', 'Thiruvananthapuram', 'Thrissur', 'Wayanad'],
    LA: ['Kargil', 'Leh'],
    LD: ['Lakshadweep'],
    MP: ['Agar Malwa', 'Alirajpur', 'Anuppur', 'Ashoknagar', 'Balaghat', 'Barwani', 'Betul', 'Bhind', 'Bhopal', 'Burhanpur', 'Chhatarpur', 'Chhindwara', 'Damoh', 'Datia', 'Dewas', 'Dhar', 'Dindori', 'Guna', 'Gwalior', 'Harda', 'Hoshangabad', 'Indore', 'Jabalpur', 'Jhabua', 'Katni', 'Khandwa', 'Khargone', 'Mandla', 'Mandsaur', 'Morena', 'Narsinghpur', 'Neemuch', 'Panna', 'Raisen', 'Rajgarh', 'Ratlam', 'Rewa', 'Sagar', 'Satna', 'Sehore', 'Seoni', 'Shahdol', 'Shajapur', 'Sheopur', 'Shivpuri', 'Sidhi', 'Singrauli', 'Tikamgarh', 'Ujjain', 'Umaria', 'Vidisha'],
    MH: ['Ahmednagar', 'Akola', 'Amravati', 'Aurangabad', 'Beed', 'Bhandara', 'Buldhana', 'Chandrapur', 'Dhule', 'Gadchiroli', 'Gondia', 'Hingoli', 'Jalgaon', 'Jalna', 'Kolhapur', 'Latur', 'Mumbai City', 'Mumbai Suburban', 'Nagpur', 'Nanded', 'Nandurbar', 'Nashik', 'Osmanabad', 'Palghar', 'Parbhani', 'Pune', 'Raigad', 'Ratnagiri', 'Sangli', 'Satara', 'Sindhudurg', 'Solapur', 'Thane', 'Wardha', 'Washim', 'Yavatmal'],
    MN: ['Bishnupur', 'Chandel', 'Churachandpur', 'Imphal East', 'Imphal West', 'Jiribam', 'Kakching', 'Kamjong', 'Kangpokpi', 'Noney', 'Pherzawl', 'Senapati', 'Tamenglong', 'Tengnoupal', 'Thoubal', 'Ukhrul'],
    ML: ['East Garo Hills', 'East Jaintia Hills', 'East Khasi Hills', 'North Garo Hills', 'Ri Bhoi', 'South Garo Hills', 'South West Garo Hills', 'South West Khasi Hills', 'West Garo Hills', 'West Jaintia Hills', 'West Khasi Hills'],
    MZ: ['Aizawl', 'Champhai', 'Kolasib', 'Lawngtiai', 'Lunglei', 'Mamit', 'Saiha', 'Serchhip'],
    NL: ['Dimapur', 'Kiphire', 'Kohima', 'Longleng', 'Mokokchung', 'Mon', 'Peren', 'Phek', 'Tuensang', 'Wokha', 'Zunheboto'],
    OD: ['Angul', 'Balangir', 'Balasore', 'Bargarh', 'Bhadrak', 'Boudh', 'Cuttack', 'Deogarh', 'Dhenkanal', 'Gajapati', 'Ganjam', 'Jagatsinghpur', 'Jajpur', 'Jharsuguda', 'Kalahandi', 'Kandhamal', 'Kendrapara', 'Kendujhar', 'Khordha', 'Koraput', 'Malkangiri', 'Mayurbhanj', 'Nabarangpur', 'Nayagarh', 'Nuapada', 'Puri', 'Rayagada', 'Sambalpur', 'Subarnapur', 'Sundargarh'],
    PY: ['Karaikal', 'Mahe', 'Puducherry', 'Yanam'],
    PB: ['Amritsar', 'Barnala', 'Bathinda', 'Faridkot', 'Fatehgarh Sahib', 'Fazilka', 'Ferozepur', 'Gurdaspur', 'Hoshiarpur', 'Jalandhar', 'Kapurthala', 'Ludhiana', 'Mansa', 'Moga', 'Mohali', 'Muktsar', 'Pathankot', 'Patiala', 'Rupnagar', 'Sangrur', 'Shaheed Bhagat Singh Nagar', 'Tarn Taran'],
    RJ: ['Ajmer', 'Alwar', 'Banswara', 'Baran', 'Barmer', 'Bharatpur', 'Bhilwara', 'Bikaner', 'Bundi', 'Chittorgarh', 'Churu', 'Dausa', 'Dholpur', 'Dungarpur', 'Hanumangarh', 'Jaipur', 'Jaisalmer', 'Jalore', 'Jhalawar', 'Jhunjhunu', 'Jodhpur', 'Karauli', 'Kota', 'Nagaur', 'Pali', 'Pratapgarh', 'Rajsamand', 'Sawai Madhopur', 'Sikar', 'Sirohi', 'Sri Ganganagar', 'Tonk', 'Udaipur'],
    SK: ['East Sikkim', 'North Sikkim', 'South Sikkim', 'West Sikkim'],
    TN: ['Ariyalur', 'Chengalpattu', 'Chennai', 'Coimbatore', 'Cuddalore', 'Dharmapuri', 'Dindigul', 'Erode', 'Kallakurichi', 'Kanchipuram', 'Kanyakumari', 'Karur', 'Krishnagiri', 'Madurai', 'Mayiladuthurai', 'Nagapattinam', 'Namakkal', 'Nilgiris', 'Perambalur', 'Pudukkottai', 'Ramanathapuram', 'Ranipet', 'Salem', 'Sivaganga', 'Tenkasi', 'Thanjavur', 'Theni', 'Thoothukudi', 'Tiruchirappalli', 'Tirunelveli', 'Tirupathur', 'Tiruppur', 'Tiruvallur', 'Tiruvannamalai', 'Tiruvarur', 'Vellore', 'Viluppuram', 'Virudhunagar'],
    TG: ['Adilabad', 'Bhadradri Kothagudem', 'Hyderabad', 'Jagtial', 'Jangaon', 'Jayashankar Bhupalpally', 'Jogulamba Gadwal', 'Kamareddy', 'Karimnagar', 'Khammam', 'Komaram Bheem', 'Mahabubabad', 'Mahbubnagar', 'Mancherial', 'Medak', 'Medchal-Malkajgiri', 'Mulugu', 'Nagarkurnool', 'Nalgonda', 'Narayanpet', 'Nirmal', 'Nizamabad', 'Peddapalli', 'Rajanna Sircilla', 'Ranga Reddy', 'Sangareddy', 'Siddipet', 'Suryapet', 'Vikarabad', 'Wanaparthy', 'Warangal Rural', 'Warangal Urban', 'Yadadri Bhuvanagiri'],
    TR: ['Dhalai', 'Gomati', 'Khowai', 'North Tripura', 'Sepahijala', 'South Tripura', 'Unakoti', 'West Tripura'],
    UP: ['Agra', 'Aligarh', 'Allahabad', 'Ambedkar Nagar', 'Amethi', 'Amroha', 'Auraiya', 'Azamgarh', 'Baghpat', 'Bahraich', 'Ballia', 'Balrampur', 'Banda', 'Barabanki', 'Bareilly', 'Basti', 'Bijnor', 'Budaun', 'Bulandshahr', 'Chandauli', 'Chitrakoot', 'Deoria', 'Etah', 'Etawah', 'Faizabad', 'Farrukhabad', 'Fatehpur', 'Firozabad', 'Gautam Buddha Nagar', 'Ghaziabad', 'Ghazipur', 'Gonda', 'Gorakhpur', 'Hamirpur', 'Hapur', 'Hardoi', 'Hathras', 'Jalaun', 'Jaunpur', 'Jhansi', 'Kannauj', 'Kanpur Dehat', 'Kanpur Nagar', 'Kasganj', 'Kaushambi', 'Kheri', 'Kushinagar', 'Lalitpur', 'Lucknow', 'Maharajganj', 'Mahoba', 'Mainpuri', 'Mathura', 'Mau', 'Meerut', 'Mirzapur', 'Moradabad', 'Muzaffarnagar', 'Pilibhit', 'Pratapgarh', 'Raebareli', 'Rampur', 'Saharanpur', 'Sambhal', 'Sant Kabir Nagar', 'Sant Ravidas Nagar', 'Shahjahanpur', 'Shamli', 'Shravasti', 'Siddharthnagar', 'Sitapur', 'Sonbhadra', 'Sultanpur', 'Unnao', 'Varanasi'],
    UK: ['Almora', 'Bageshwar', 'Chamoli', 'Champawat', 'Dehradun', 'Haridwar', 'Nainital', 'Pauri Garhwal', 'Pithoragrah', 'Rudraprayag', 'Tehri Garhwal', 'Udham Singh Nagar', 'Uttarkashi'],
    WB: ['Alipurduar', 'Bankura', 'Birbhum', 'Cooch Behar', 'Dakshin Dinajpur', 'Darjeeling', 'Hooghly', 'Howrah', 'Jalpaiguri', 'Jhargram', 'Kalimpong', 'Kolkata', 'Malda', 'Murshidabad', 'Nadia', 'North 24 Parganas', 'Paschim Bardhaman', 'Paschim Medipur', 'Purba Bardhaman', 'Purba Medipur', 'Purulia', 'South 24 Parganas', 'Uttar Dinajpur'],
  };

  states = [
    { name: 'West Bengal', code: 'WB' },
    { name: 'Andhra Pradesh', code: 'AP' }, { name: 'Arunachal Pradesh', code: 'AR' }, { name: 'Assam', code: 'AS' },
    { name: 'Bihar', code: 'BR' }, { name: 'Chhattisgarh', code: 'CG' }, { name: 'Goa', code: 'GA' }, { name: 'Gujarat', code: 'GJ' },
    { name: 'Haryana', code: 'HR' }, { name: 'Himachal Pradesh', code: 'HP' }, { name: 'Jharkhand', code: 'JH' }, { name: 'Karnataka', code: 'KA' },
    { name: 'Kerala', code: 'KL' }, { name: 'Madhya Pradesh', code: 'MP' }, { name: 'Maharashtra', code: 'MH' }, { name: 'Manipur', code: 'MN' },
    { name: 'Meghalaya', code: 'ML' }, { name: 'Mizoram', code: 'MZ' }, { name: 'Nagaland', code: 'NL' }, { name: 'Odisha', code: 'OD' },
    { name: 'Punjab', code: 'PB' }, { name: 'Rajasthan', code: 'RJ' }, { name: 'Sikkim', code: 'SK' }, { name: 'Tamil Nadu', code: 'TN' },
    { name: 'Telangana', code: 'TG' }, { name: 'Tripura', code: 'TR' }, { name: 'Uttar Pradesh', code: 'UP' }, { name: 'Uttarakhand', code: 'UK' },
    { name: 'Andaman and Nicobar Islands', code: 'AN' }, { name: 'Chandigarh', code: 'CH' },
    { name: 'Dadra and Nagar Haveli and Daman and Diu', code: 'DD' }, { name: 'Delhi', code: 'DL' }, { name: 'Jammu and Kashmir', code: 'JK' },
    { name: 'Ladakh', code: 'LA' }, { name: 'Lakshadweep', code: 'LD' }, { name: 'Puducherry', code: 'PY' },
  ];

  applyForm = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(3)]],
    guardianName: ['', [Validators.required, Validators.minLength(3)]],
    gender: ['male' as const, Validators.required],
    dob: ['', Validators.required],
    phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
    email: ['', [Validators.email]],
    address: ['', [Validators.required, Validators.minLength(10)]],
    state: ['WB', Validators.required],
    district: ['', Validators.required],
    pinCode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
    panNumber: ['', [Validators.required, Validators.pattern('^[A-Z]{5}[0-9]{4}[A-Z]{1}$')]],
    voterId: ['', Validators.pattern('^[A-Z]{3}[0-9]{7}$')],
    profilePicture: [null as string | null],
    panCardImage: [null as string | null, Validators.required],
    username: ['', [Validators.required, Validators.minLength(4)]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', [Validators.required]],
    agreeToTerms: [false, Validators.requiredTrue],
    occupation: ['', Validators.required],
    nomineeName: [''],
    nomineeAge: [null as number | null],
    nomineeRelation: [''],
  }, { validators: passwordsMatchValidator });

  constructor() {
    this.applyForm.get('state')?.valueChanges.pipe(
      takeUntilDestroyed(this.destroyRef)
    ).subscribe(stateCode => {
      const newDistricts = this.districtsByState[stateCode || ''] || [];
      this.districts.set(newDistricts);
      this.applyForm.get('district')?.setValue('');
    });

    // Set initial districts based on default form value
    const initialStateCode = this.applyForm.get('state')?.value;
    const initialDistricts = this.districtsByState[initialStateCode || ''] || [];
    this.districts.set(initialDistricts);
    
    // Add dynamic unique username validator
    effect(() => {
        const usernameControl = this.applyForm.get('username');
        if (usernameControl) {
            usernameControl.setValidators([
                Validators.required,
                Validators.minLength(4),
                uniqueUsernameValidator(this.allUsernames())
            ]);
            usernameControl.updateValueAndValidity();
        }
    });
  }

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.applyForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  getControlError(controlName: string, errorName: string): boolean {
    const control = this.applyForm.get(controlName);
    return !!control && control.hasError(errorName) && (control.dirty || control.touched);
  }
  
  isFormInvalid(errorName: string): boolean {
    return this.applyForm.hasError(errorName) && (this.applyForm.get('confirmPassword')?.dirty || this.applyForm.get('confirmPassword')?.touched);
  }

  async handleFileInput(event: Event, controlName: 'profilePicture' | 'panCardImage', previewSignal: any) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      
      const isPanCard = controlName === 'panCardImage';
      const maxWidth = isPanCard ? 1200 : 800;
      const maxHeight = isPanCard ? 1200 : 800;
      const quality = isPanCard ? 0.95 : 0.92;

      try {
        const compressedDataUrl = await this.compressImage(file, maxWidth, maxHeight, quality);
        previewSignal.set(compressedDataUrl);
        this.applyForm.get(controlName)?.setValue(compressedDataUrl);
        this.applyForm.get(controlName)?.markAsDirty();
      } catch (error) {
        console.error('Image compression failed:', error);
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          previewSignal.set(result);
          this.applyForm.get(controlName)?.setValue(result);
          this.applyForm.get(controlName)?.markAsDirty();
        };
        reader.readAsDataURL(file);
      }
    }
  }

  private async compressImage(file: File, maxWidth: number, maxHeight: number, quality: number): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxWidth) {
                        height = Math.round(height * (maxWidth / width));
                        width = maxWidth;
                    }
                } else {
                    if (height > maxHeight) {
                        width = Math.round(width * (maxHeight / height));
                        height = maxHeight;
                    }
                }
                
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    return reject(new Error('Could not get canvas context'));
                }
                
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.onerror = (error) => reject(error);
        };
        reader.onerror = (error) => reject(error);
    });
  }

  toUpperCase(event: Event, controlName: string) {
    const input = event.target as HTMLInputElement;
    const uppercaseValue = input.value.toUpperCase();
    this.applyForm.get(controlName)?.setValue(uppercaseValue, { emitEvent: false });
    input.value = uppercaseValue;
  }

  onSubmit() {
    if (this.applyForm.invalid) {
      this.applyForm.markAllAsTouched();
      return;
    }

    this.loading.set(true);
    // Simulate API call
    setTimeout(() => {
      this.loading.set(false);
      this.submissionSuccess.set(true);
      this.submitApplication.emit(this.applyForm.getRawValue() as ApplicationData);
    }, 2000);
  }

  startNewApplication() {
    this.submissionSuccess.set(false);
    this.applyForm.reset({
      gender: 'male',
      state: 'WB',
      agreeToTerms: false
    });
    this.profilePicturePreview.set(null);
    this.panCardImagePreview.set(null);
  }

  openTermsModal(event: Event) {
    event.preventDefault();
    this.showTermsModal.set(true);
  }

  closeTermsModal() {
    this.showTermsModal.set(false);
  }
}