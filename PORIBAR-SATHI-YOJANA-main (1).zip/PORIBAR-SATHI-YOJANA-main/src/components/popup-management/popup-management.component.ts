import { Component, ChangeDetectionStrategy, input, output, inject, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { PopupMessage, PopupMessageComponent } from '../popup-message/popup-message.component';

@Component({
  selector: 'app-popup-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe, PopupMessageComponent],
  templateUrl: './popup-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PopupManagementComponent {
  currentPopupMessage = input.required<PopupMessage | null>();
  navigate = output<void>();
  popupUpdate = output<PopupMessage>();

  private fb: FormBuilder = inject(FormBuilder);

  popupForm = this.fb.group({
    enabled: [false],
    title: ['', Validators.required],
    message: ['', Validators.required],
    imageUrl: [''],
    link: [''],
  });

  constructor() {
    effect(() => {
      const data = this.currentPopupMessage();
      if (data) {
        this.popupForm.patchValue(data);
      }
    });
  }

  goBack() {
    this.navigate.emit();
  }

  onSubmit() {
    if (this.popupForm.invalid) {
      this.popupForm.markAllAsTouched();
      return;
    }
    this.popupUpdate.emit(this.popupForm.getRawValue() as PopupMessage);
    alert('Popup message settings saved!');
    this.popupForm.markAsPristine();
  }
}
