import { Component, ChangeDetectionStrategy, input, output, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TranslatePipe } from '../../pipes/translate.pipe';

export interface SkillProgram {
  id: string;
  title: string;
  description: string;
  duration: string;
}

@Component({
  selector: 'app-skill-program-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './skill-program-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SkillProgramManagementComponent {
  skillPrograms = input.required<SkillProgram[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createSkillProgram = output<Omit<SkillProgram, 'id'>>();
  deleteSkillProgram = output<string>();

  private fb: FormBuilder = inject(FormBuilder);

  programForm = this.fb.group({
    title: ['', [Validators.required, Validators.minLength(5)]],
    description: ['', [Validators.required, Validators.minLength(10)]],
    duration: ['', Validators.required],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.programForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onAdd() {
    if (this.programForm.invalid) {
      this.programForm.markAllAsTouched();
      return;
    }
    this.createSkillProgram.emit(this.programForm.value as Omit<SkillProgram, 'id'>);
    this.programForm.reset();
  }

  onDelete(id: string) {
    if (confirm('Are you sure you want to delete this skill program?')) {
      this.deleteSkillProgram.emit(id);
    }
  }
}
