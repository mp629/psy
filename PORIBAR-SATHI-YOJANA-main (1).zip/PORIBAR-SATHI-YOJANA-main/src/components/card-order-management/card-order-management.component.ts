import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, computed } from '@angular/core';
import { PhysicalCardOrder } from '../../app.component';

@Component({
  selector: 'app-card-order-management',
  standalone: true,
  templateUrl: './card-order-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CardOrderManagementComponent {
  cardOrders = input.required<PhysicalCardOrder[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() updateOrderStatus = new EventEmitter<{ orderId: string, status: 'Printed' | 'Shipped' }>();

  sortedOrders = computed(() => {
    return [...this.cardOrders()].sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());
  });

  goBack() {
    this.navigate.emit();
  }

  onUpdateStatus(orderId: string, status: 'Printed' | 'Shipped') {
    this.updateOrderStatus.emit({ orderId, status });
  }
}
