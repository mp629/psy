import { Component, ChangeDetectionStrategy, input, output, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { OnlineCourse } from '../online-courses/online-courses.component';

@Component({
  selector: 'app-course-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './course-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CourseManagementComponent {
  courses = input.required<OnlineCourse[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createCourse = output<Omit<OnlineCourse, 'id'>>();
  deleteCourse = output<string>();

  private fb: FormBuilder = inject(FormBuilder);

  courseForm = this.fb.group({
    title: ['', [Validators.required, Validators.minLength(5)]],
    description: ['', [Validators.required, Validators.minLength(10)]],
    videoUrl: ['', [Validators.required, Validators.pattern('^https?://.+$')]],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.courseForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onAdd() {
    if (this.courseForm.invalid) {
      this.courseForm.markAllAsTouched();
      return;
    }
    this.createCourse.emit(this.courseForm.value as Omit<OnlineCourse, 'id'>);
    this.courseForm.reset();
  }

  onDelete(id: string) {
    if (confirm('Are you sure you want to delete this course?')) {
      this.deleteCourse.emit(id);
    }
  }
}
