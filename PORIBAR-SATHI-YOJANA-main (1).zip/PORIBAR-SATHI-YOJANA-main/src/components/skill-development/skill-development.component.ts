import { Component, ChangeDetectionStrategy, input, output, computed } from '@angular/core';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { SkillProgram } from '../skill-program-management/skill-program-management.component';
import { PublicUser } from '../../app.component';

export interface UserSkillEnrollment {
  id: string; // "ENR-${userId}-${programId}"
  userId: string;
  programId: string;
  enrollmentDate: string;
  status: 'enrolled' | 'completed';
  completionDate?: string;
}

@Component({
  selector: 'app-skill-development',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './skill-development.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SkillDevelopmentComponent {
  skillPrograms = input.required<SkillProgram[]>();
  enrollments = input.required<UserSkillEnrollment[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  enroll = output<string>();
  markComplete = output<string>();
  viewCertificate = output<UserSkillEnrollment>();

  getEnrollmentStatus(programId: string): UserSkillEnrollment | null {
    return this.enrollments().find(e => e.programId === programId) || null;
  }

  goBack() {
    this.navigate.emit();
  }

  onEnroll(programId: string) {
    this.enroll.emit(programId);
  }

  onMarkComplete(enrollmentId: string) {
    this.markComplete.emit(enrollmentId);
  }

  onViewCertificate(enrollment: UserSkillEnrollment) {
    this.viewCertificate.emit(enrollment);
  }
}
