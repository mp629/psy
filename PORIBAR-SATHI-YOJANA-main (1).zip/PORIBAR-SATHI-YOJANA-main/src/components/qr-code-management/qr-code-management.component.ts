import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, signal } from '@angular/core';

@Component({
  selector: 'app-qr-code-management',
  standalone: true,
  templateUrl: './qr-code-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QrCodeManagementComponent {
  currentQrCodeUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() qrCodeUpdate = new EventEmitter<string | null>();

  newQrCodePreview = signal<string | null>(null);
  selectedFile = signal<File | null>(null);

  goBack() {
    this.navigate.emit();
  }

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      if (file.type.startsWith('image/')) {
        this.selectedFile.set(file);
        const reader = new FileReader();
        reader.onload = (e) => {
          this.newQrCodePreview.set(e.target?.result as string);
        };
        reader.readAsDataURL(file);
      } else {
        alert('Please select a valid image file (PNG, JPG, etc.).');
      }
    }
  }

  saveQrCode() {
    if (this.newQrCodePreview()) {
      this.qrCodeUpdate.emit(this.newQrCodePreview());
      this.reset();
    }
  }

  removeQrCode() {
    if (confirm('Are you sure you want to remove the Top-up QR Code?')) {
      this.qrCodeUpdate.emit(null);
      this.reset();
    }
  }

  private reset() {
    this.selectedFile.set(null);
    this.newQrCodePreview.set(null);
    const fileInput = document.getElementById('qr-code-upload') as HTMLInputElement;
    if (fileInput) {
        fileInput.value = '';
    }
  }
}
