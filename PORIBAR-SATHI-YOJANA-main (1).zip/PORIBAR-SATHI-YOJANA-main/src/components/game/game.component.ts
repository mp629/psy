import { Component, ChangeDetectionStrategy, input, output, effect } from '@angular/core';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-game',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './game.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GameComponent {
  appLogoUrl = input<string | null>(null);
  gameUrl = input.required<string | null>();
  navigate = output<void>();

  constructor() {
    effect(() => {
      const url = this.gameUrl();
      if (url) {
        window.open(url, '_blank');
        // Navigate back immediately after attempting to open the new tab
        this.goBack();
      }
    });
  }

  goBack() {
    this.navigate.emit();
  }
}