import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { HealthArticle } from '../health-tips/health-tips.component';

@Component({
  selector: 'app-article-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './article-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ArticleManagementComponent {
  articles = input.required<HealthArticle[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() createArticle = new EventEmitter<Omit<HealthArticle, 'id'>>();
  @Output() deleteArticle = new EventEmitter<string>();

  private fb: FormBuilder = inject(FormBuilder);

  articleForm = this.fb.group({
    title: ['', [Validators.required, Validators.minLength(5)]],
    description: ['', [Validators.required, Validators.minLength(10)]],
    url: ['', [Validators.required, Validators.pattern('^https?://.+$')]],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.articleForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onAddArticle() {
    if (this.articleForm.invalid) {
      this.articleForm.markAllAsTouched();
      return;
    }
    this.createArticle.emit(this.articleForm.value as Omit<HealthArticle, 'id'>);
    this.articleForm.reset();
  }

  onDeleteArticle(id: string) {
    if (confirm('Are you sure you want to delete this article?')) {
      this.deleteArticle.emit(id);
    }
  }
}
