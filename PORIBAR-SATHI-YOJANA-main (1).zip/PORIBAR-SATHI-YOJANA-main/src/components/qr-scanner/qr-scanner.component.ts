import { Component, ChangeDetectionStrategy, Output, EventEmitter, signal, input, ViewChild, ElementRef, OnDestroy, AfterViewInit } from '@angular/core';

// Declare jsQR to avoid TypeScript errors since it's loaded from a script tag.
declare var jsQR: any;

@Component({
  selector: 'app-qr-scanner',
  standalone: true,
  templateUrl: './qr-scanner.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QrScannerComponent implements OnDestroy, AfterViewInit {
  @Output() navigate = new EventEmitter<void>();
  @Output() qrCodeScanned = new EventEmitter<{ id: string, type: 'public' | 'officer' }>();
  appLogoUrl = input<string | null>(null);

  @ViewChild('videoElement') videoElement!: ElementRef<HTMLVideoElement>;
  @ViewChild('canvasElement') canvasElement!: ElementRef<HTMLCanvasElement>;

  state = signal<'camera' | 'loading'>('camera');
  error = signal<string | null>(null);
  stream = signal<MediaStream | null>(null);
  private animationFrameId: number | null = null;

  ngAfterViewInit() {
    this.startCameraStream();
  }

  ngOnDestroy() {
    this.stopCamera();
  }

  goBack() {
    this.stopCamera();
    this.navigate.emit();
  }

  private async startCameraStream() {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API is not supported by your browser.');
      }
      
      let stream: MediaStream;
      const environmentConstraint = { video: { facingMode: 'environment' } };
      const anyCameraConstraint = { video: true };

      try {
        // Prefer the rear camera
        stream = await navigator.mediaDevices.getUserMedia(environmentConstraint);
      } catch (err) {
        console.warn('Could not get environment camera, trying any camera...', err);
        // If rear camera fails (e.g., on a laptop), try any camera
        stream = await navigator.mediaDevices.getUserMedia(anyCameraConstraint);
      }
      
      this.stream.set(stream);
      if (this.videoElement) {
        const video = this.videoElement.nativeElement;
        video.srcObject = stream;
        video.onloadedmetadata = () => {
          video.play();
          this.scan(); // Start scanning once the video is playing
        };
      }
    } catch (err) {
      console.error("Camera access error:", err);
      let errorMessage = "Could not access the camera. Please ensure you have granted permission.";
      
      if (err && typeof err === 'object' && 'name' in err) {
        const errorName = (err as Error).name;
        if (errorName === 'NotFoundError' || errorName === 'DevicesNotFoundError') {
            errorMessage = "No camera was found on your device. This can happen if your device has no camera, or if it is disabled in your system settings.";
        } else if (errorName === 'NotAllowedError' || errorName === 'PermissionDeniedError') {
            errorMessage = "Camera access was denied. To use this feature, please grant permission in your browser or system settings.";
        } else if (errorName === 'NotReadableError' || errorName === 'TrackStartError') {
            errorMessage = "The camera is currently in use by another application or a hardware error occurred. Please close other apps using the camera and try again.";
        } else if (errorName === 'OverconstrainedError' || errorName === 'ConstraintNotSatisfiedError') {
            errorMessage = "The camera on your device does not support the required settings.";
        }
      }

      this.error.set(errorMessage);
      this.state.set('camera'); 
    }
  }

  stopCamera() {
    this.stream()?.getTracks().forEach(track => track.stop());
    this.stream.set(null);
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  private scan() {
    if (this.videoElement?.nativeElement.readyState === this.videoElement.nativeElement.HAVE_ENOUGH_DATA) {
      const video = this.videoElement.nativeElement;
      const canvas = this.canvasElement.nativeElement;
      const context = canvas.getContext('2d');

      canvas.height = video.videoHeight;
      canvas.width = video.videoWidth;

      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code) {
          this.handleQrCode(code.data);
          return; // Stop scanning
        }
      }
    }
    // Continue scanning
    this.animationFrameId = requestAnimationFrame(() => this.scan());
  }

  private handleQrCode(data: string) {
    this.stopCamera();
    this.state.set('loading');
    this.error.set(null);

    try {
      const parsedData = JSON.parse(data);
      if (parsedData.id && parsedData.type && (parsedData.type === 'public' || parsedData.type === 'officer')) {
        this.qrCodeScanned.emit(parsedData);
      } else {
        throw new Error("QR code does not contain valid user data.");
      }
    } catch (e) {
      console.error("QR Scanner Error:", e);
      const message = e instanceof Error ? e.message : "An unknown error occurred.";
      this.error.set(`Failed to scan QR code. ${message}`);
      this.state.set('camera');
      setTimeout(() => this.startCameraStream(), 500); // Restart camera to allow retry
    }
  }
}