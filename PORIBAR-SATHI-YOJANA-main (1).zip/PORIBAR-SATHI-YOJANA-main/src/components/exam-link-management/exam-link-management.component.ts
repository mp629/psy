import { Component, ChangeDetectionStrategy, input, output, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ExamLink } from '../exam-results/exam-results.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-exam-link-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './exam-link-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExamLinkManagementComponent {
  examLinks = input.required<ExamLink[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createExamLink = output<Omit<ExamLink, 'id'>>();
  deleteExamLink = output<string>();

  private fb: FormBuilder = inject(FormBuilder);

  linkForm = this.fb.group({
    title: ['', [Validators.required, Validators.minLength(5)]],
    url: ['', [Validators.required, Validators.pattern('^https?://.+$')]],
    type: ['government' as 'government' | 'private', Validators.required],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.linkForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onAdd() {
    if (this.linkForm.invalid) {
      this.linkForm.markAllAsTouched();
      return;
    }
    this.createExamLink.emit(this.linkForm.value as Omit<ExamLink, 'id'>);
    this.linkForm.reset({ type: 'government' });
  }

  onDelete(id: string) {
    if (confirm('Are you sure you want to delete this exam link?')) {
      this.deleteExamLink.emit(id);
    }
  }
}
