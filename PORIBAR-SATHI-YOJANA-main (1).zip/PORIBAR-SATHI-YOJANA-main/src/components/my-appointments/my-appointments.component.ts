import { Component, ChangeDetectionStrategy, input, output, computed } from '@angular/core';
import { Appointment } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-my-appointments',
  standalone: true,
  imports: [TranslatePipe, DatePipe],
  templateUrl: './my-appointments.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MyAppointmentsComponent {
  appointments = input.required<Appointment[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();

  sortedAppointments = computed(() => {
    return [...this.appointments()].sort((a, b) => {
        // Sort by scheduled time if available, otherwise by request date
        const dateA = a.scheduledTime ? new Date(a.scheduledTime) : new Date(a.requestDate);
        const dateB = b.scheduledTime ? new Date(b.scheduledTime) : new Date(b.requestDate);
        return dateB.getTime() - dateA.getTime();
    });
  });

  goBack() {
    this.navigate.emit();
  }
}