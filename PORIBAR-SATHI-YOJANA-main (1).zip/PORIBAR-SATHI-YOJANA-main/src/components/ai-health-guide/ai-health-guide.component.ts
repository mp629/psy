import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input } from '@angular/core';
import { GeminiService } from '../../services/gemini.service';

interface HealthAdvice {
  immediateSteps: string[];
  dietChart: string[];
}

@Component({
  selector: 'app-ai-health-guide',
  standalone: true,
  templateUrl: './ai-health-guide.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AiHealthGuideComponent {
  @Output() navigate = new EventEmitter<void>();
  appLogoUrl = input<string | null>(null);
  
  private geminiService = inject(GeminiService);

  isRecording = signal(false);
  transcript = signal('');
  loading = signal(false);
  error = signal<string | null>(null);
  healthAdvice = signal<HealthAdvice | null>(null);

  private recognition: any;

  constructor() {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = false; // We only need the final transcript
      this.recognition.lang = 'en-US';

      this.recognition.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        this.transcript.update(t => t + finalTranscript + ' ');
      };

      this.recognition.onend = () => {
        if (this.isRecording()) { // if it stops on its own
          this.isRecording.set(false);
          if (this.transcript().trim()) {
            this.getHealthAdvice();
          }
        }
      };

      this.recognition.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        this.error.set(`Speech recognition error: ${event.error}. Please ensure microphone permission is granted.`);
        this.isRecording.set(false);
      };
    } else {
      this.error.set('Speech recognition is not supported by your browser.');
    }
  }

  goBack() {
    // Stop recording if active when going back
    if (this.isRecording()) {
      this.recognition.stop();
      this.isRecording.set(false);
    }
    this.navigate.emit();
  }

  toggleRecording() {
    if (!this.recognition) return;

    if (this.isRecording()) {
      this.recognition.stop();
      this.isRecording.set(false);
      if (this.transcript().trim()) {
        this.getHealthAdvice();
      }
    } else {
      this.transcript.set('');
      this.healthAdvice.set(null);
      this.error.set(null);
      this.recognition.start();
      this.isRecording.set(true);
    }
  }

  async getHealthAdvice() {
    const promptText = this.transcript().trim();
    if (!promptText) return;

    this.loading.set(true);
    this.error.set(null);

    const prompt = `
      A person has the following health concern: "${promptText}".

      Provide a response in a JSON object format with two keys: "immediateSteps" and "dietChart".
      - "immediateSteps": An array of strings with simple, actionable first steps. The VERY FIRST step MUST be a disclaimer: "This is not medical advice. Always consult a qualified doctor for any health concerns."
      - "dietChart": An array of strings outlining a basic, general diet plan that could be beneficial.

      Only return the raw JSON object, with no other text or markdown formatting.
    `;

    try {
      const response = await this.geminiService.generateThoughtfulResponse(prompt);
      const responseText = response.text;
      
      const jsonString = responseText.replace(/```json/g, '').replace(/```/g, '').trim();

      try {
        const parsedResponse: HealthAdvice = JSON.parse(jsonString);
        if (parsedResponse.immediateSteps && parsedResponse.dietChart) {
          this.healthAdvice.set(parsedResponse);
        } else {
          throw new Error("AI response did not match the expected format (missing keys).");
        }
      } catch (parseError) {
        console.error("Failed to parse AI response:", parseError);
        console.error("Raw AI response:", jsonString);
        this.error.set("The AI returned an invalid response. Please try rephrasing your concern.");
        this.healthAdvice.set({
            immediateSteps: ["Could not get a valid response from the AI."],
            dietChart: ["Please try rephrasing your question or check the error message."]
        });
      }

    } catch (e) {
      console.error('Gemini Service Error:', e);
      this.error.set("An error occurred while contacting the AI health guide. Please try again later.");
    } finally {
      this.loading.set(false);
    }
  }
}