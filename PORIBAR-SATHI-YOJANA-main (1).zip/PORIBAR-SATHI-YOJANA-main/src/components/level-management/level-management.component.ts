
import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators, FormArray, FormGroup } from '@angular/forms';

export interface OfficerLevel {
  level: number;
  title: string;
  rate: number; // Commission rate in percentage
}

@Component({
  selector: 'app-level-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './level-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LevelManagementComponent {
  levels = input.required<OfficerLevel[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() saveLevels = new EventEmitter<OfficerLevel[]>();

  private fb: FormBuilder = inject(FormBuilder);

  levelForm = this.fb.group({
    levels: this.fb.array([])
  });

  constructor() {
    effect(() => {
      const currentLevels = this.levels();
      if (currentLevels) {
        this.levelsFormArray.clear();
        currentLevels
            .sort((a, b) => a.level - b.level)
            .forEach(level => {
                this.levelsFormArray.push(this.fb.group({
                  title: [level.title, Validators.required],
                  rate: [level.rate, [Validators.required, Validators.min(0), Validators.max(100)]]
                }));
            });
      }
    });
  }

  get levelsFormArray() {
    return this.levelForm.get('levels') as FormArray;
  }
  
  getLevel(index: number): number {
    // Find the original level based on the sorted index.
    const sortedLevels = [...this.levels()].sort((a,b) => a.level - b.level);
    return sortedLevels[index]?.level || index + 1;
  }

  goBack() {
    this.navigate.emit();
  }

  onSubmit() {
    if (this.levelForm.invalid) {
      this.levelForm.markAllAsTouched();
      return;
    }

    const formValue = this.levelForm.value.levels as {title: string, rate: number}[];

    const updatedLevels: OfficerLevel[] = formValue.map((levelData, index) => ({
      level: this.getLevel(index),
      title: levelData.title,
      rate: levelData.rate
    }));
    
    this.saveLevels.emit(updatedLevels);
    alert('Officer level titles and rates saved successfully!');
    this.levelForm.markAsPristine();
  }
}
