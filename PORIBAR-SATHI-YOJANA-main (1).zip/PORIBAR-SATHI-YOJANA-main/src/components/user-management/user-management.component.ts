import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, signal } from '@angular/core';
import { PublicUser } from '../../app.component';
import { EditUserModalComponent } from '../edit-user-modal/edit-user-modal.component';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [EditUserModalComponent],
  templateUrl: './user-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserManagementComponent {
  publicUsers = input.required<PublicUser[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() userStatusUpdate = new EventEmitter<{ userId: string; status: 'active' | 'suspended' }>();
  @Output() deleteUser = new EventEmitter<string>();
  @Output() updateUser = new EventEmitter<PublicUser>();

  selectedUserForEdit = signal<PublicUser | null>(null);

  goBack() {
    this.navigate.emit();
  }

  toggleStatus(user: PublicUser) {
    const newStatus = user.status === 'active' ? 'suspended' : 'active';
    if (confirm(`Are you sure you want to set status to '${newStatus}' for ${user.username}?`)) {
      this.userStatusUpdate.emit({ userId: user.id, status: newStatus });
    }
  }

  onDeleteUser(user: PublicUser) {
    if (confirm(`Are you sure you want to permanently delete user '${user.username}'? This action cannot be undone.`)) {
      this.deleteUser.emit(user.id);
    }
  }
  
  onEditUser(user: PublicUser) {
    this.selectedUserForEdit.set(user);
  }

  closeEditModal() {
    this.selectedUserForEdit.set(null);
  }

  saveUser(user: PublicUser) {
    this.updateUser.emit(user);
    this.closeEditModal();
  }
}
