
import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-image-editor',
  standalone: true,
  imports: [FormsModule, TranslatePipe],
  templateUrl: './image-editor.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ImageEditorComponent {
  @Output() navigate = new EventEmitter<void>();
  appLogoUrl = input<string | null>(null);

  private geminiService = inject(GeminiService);

  prompt = signal('');
  uploadedImage = signal<string | null>(null);
  generatedImageUrl = signal<string | null>(null);
  loading = signal(false);
  error = signal<string | null>(null);
  statusMessage = signal<string | null>(null);
  aiGeneratedPrompt = signal<string | null>(null);

  async handleFileInput(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        this.uploadedImage.set(e.target?.result as string);
        this.generatedImageUrl.set(null); // Clear previous generation
        this.error.set(null);
      };
      reader.readAsDataURL(file);
    }
  }

  clearImage() {
    this.uploadedImage.set(null);
    this.aiGeneratedPrompt.set(null);
    const fileInput = document.getElementById('image-upload') as HTMLInputElement;
    if (fileInput) fileInput.value = '';
  }

  async generateImage() {
    if (!this.prompt().trim() && !this.uploadedImage()) return;
    if (this.loading()) return;

    this.loading.set(true);
    this.error.set(null);
    this.generatedImageUrl.set(null);
    this.aiGeneratedPrompt.set(null);

    try {
      let finalPrompt = this.prompt().trim();
      const userImage = this.uploadedImage();

      if (userImage) {
        // Image-to-image flow
        this.statusMessage.set('Analyzing image & generating new prompt...');
        const base64Data = userImage.split(',')[1];
        const newPrompt = await this.geminiService.generateImagePromptFromImage(base64Data, finalPrompt);
        this.aiGeneratedPrompt.set(newPrompt);
        finalPrompt = newPrompt;
      }

      this.statusMessage.set('Generating your masterpiece...');
      const imageUrl = await this.geminiService.generateImage(finalPrompt);
      this.generatedImageUrl.set(imageUrl);
    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred while generating the image.';
      this.error.set(errorMessage);
    } finally {
      this.loading.set(false);
      this.statusMessage.set(null);
    }
  }

  goBack() {
    this.navigate.emit();
  }
}
