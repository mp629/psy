import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';

interface ServiceResult {
  name: string;
  description: string;
  url: string;
}

@Component({
  selector: 'app-sarkari-seva-finder',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './sarkari-seva-finder.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SarkariSevaFinderComponent {
  @Output() navigate = new EventEmitter<void>();
  appLogoUrl = input<string | null>(null);

  private fb: FormBuilder = inject(FormBuilder);
  private geminiService = inject(GeminiService);

  states = [
    { code: 'Central', name: 'Central Government' },
    { code: 'WB', name: 'West Bengal' },
    { code: 'DL', name: 'Delhi' },
    { code: 'MH', name: 'Maharashtra' },
    { code: 'UP', name: 'Uttar Pradesh' },
    // Add more states
  ];

  finderForm = this.fb.group({
    state: ['Central', Validators.required],
    problem: ['', [Validators.required, Validators.minLength(10)]],
  });

  viewState = signal<'form' | 'loading' | 'results'>('form');
  error = signal<string | null>(null);
  results = signal<ServiceResult[]>([]);

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.finderForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }
  
  startNewSearch() {
    this.viewState.set('form');
    this.results.set([]);
    this.error.set(null);
    this.finderForm.reset({ state: 'Central', problem: '' });
  }

  async findServices() {
    if (this.finderForm.invalid) {
      this.finderForm.markAllAsTouched();
      return;
    }

    this.viewState.set('loading');
    this.error.set(null);
    const { state, problem } = this.finderForm.value;

    const prompt = `
      A user from "${state}" in India needs help with the following issue: "${problem}".
      Based on this, find up to 5 relevant government (central or state) websites or schemes that could help them.
      
      Provide a response ONLY as a valid JSON array of objects. Do not include any other text or markdown.
      Each object in the array should have this exact structure:
      {
        "name": "string (The official name of the scheme/website)",
        "description": "string (A brief, one-sentence description of what it does)",
        "url": "string (The full, valid URL to the official website)"
      }
    `;

    try {
      const response = await this.geminiService.generateThoughtfulResponse(prompt);
      const responseText = response.text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsedResults: ServiceResult[] = JSON.parse(responseText);
      this.results.set(parsedResults);
      this.viewState.set('results');
    } catch (e) {
      console.error("AI Service Finder Error:", e);
      this.error.set("The AI could not process your request. Please try rephrasing your problem or try again later.");
      this.viewState.set('results'); // Show results view to display the error
    }
  }
  
  visitWebsite(url: string) {
    window.open(url, '_blank');
  }
}
