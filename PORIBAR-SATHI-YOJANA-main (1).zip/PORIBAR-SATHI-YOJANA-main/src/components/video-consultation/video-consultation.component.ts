import { Component, ChangeDetectionStrategy, input, output, computed } from '@angular/core';
import { Appointment } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-video-consultation',
  standalone: true,
  imports: [TranslatePipe, DatePipe],
  templateUrl: './video-consultation.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VideoConsultationComponent {
  appointments = input.required<Appointment[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();

  upcomingAppointments = computed(() => {
    const now = new Date();
    return this.appointments()
      .filter(a => a.status === 'approved' && a.scheduledTime && new Date(a.scheduledTime) > now)
      .sort((a, b) => new Date(a.scheduledTime!).getTime() - new Date(b.scheduledTime!).getTime());
  });

  goBack() {
    this.navigate.emit();
  }

  isJoinable(scheduledTime: string | undefined): boolean {
    if (!scheduledTime) return false;
    const now = new Date();
    const apptTime = new Date(scheduledTime);
    const timeDiff = apptTime.getTime() - now.getTime();
    const minutesUntil = timeDiff / (1000 * 60);
    // Joinable if appointment is in the past or up to 60 minutes in the future
    return minutesUntil <= 60;
  }
}