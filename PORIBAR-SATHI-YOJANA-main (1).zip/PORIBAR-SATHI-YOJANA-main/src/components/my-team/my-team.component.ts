import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, computed } from '@angular/core';
import { Officer } from '../../app.component';
import { OfficerLevel } from '../level-management/level-management.component';

interface FlatTeamMember {
  officer: Officer;
  depth: number;
}

@Component({
  selector: 'app-my-team',
  standalone: true,
  templateUrl: './my-team.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MyTeamComponent {
  currentOfficer = input.required<Officer | null>();
  allOfficers = input.required<Officer[]>();
  officerLevels = input.required<OfficerLevel[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();

  flatTeamView = computed<FlatTeamMember[]>(() => {
    const officer = this.currentOfficer();
    const all = this.allOfficers();
    if (!officer || all.length === 0) return [];

    const team: FlatTeamMember[] = [];
    const buildHierarchy = (officerId: string, depth: number) => {
      const subordinates = all.filter(o => o.reportsTo === officerId);
      for (const sub of subordinates) {
        team.push({ officer: sub, depth: depth });
        buildHierarchy(sub.id, depth + 1);
      }
    };

    buildHierarchy(officer.id, 1);
    return team;
  });
  
  getOfficerTitle(level: number): string {
    return this.officerLevels().find(l => l.level === level)?.title || `Level ${level}`;
  }

  goBack() {
    this.navigate.emit();
  }
}