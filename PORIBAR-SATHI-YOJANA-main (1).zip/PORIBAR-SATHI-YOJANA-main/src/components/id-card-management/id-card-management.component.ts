import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, signal } from '@angular/core';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-id-card-management',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './id-card-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class IdCardManagementComponent {
  currentIdCardLogoUrl = input<string | null>(null);
  currentAuthorizedSignatureUrl = input<string | null>(null);
  
  @Output() navigate = new EventEmitter<void>();
  @Output() idCardLogoUpdate = new EventEmitter<string | null>();
  @Output() authorizedSignatureUpdate = new EventEmitter<string | null>();

  newLogoPreview = signal<string | null>(null);
  newSignaturePreview = signal<string | null>(null);

  goBack() {
    this.navigate.emit();
  }

  onFileChange(event: Event, type: 'logo' | 'signature') {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          if (type === 'logo') {
            this.newLogoPreview.set(result);
          } else {
            this.newSignaturePreview.set(result);
          }
        };
        reader.readAsDataURL(file);
      } else {
        alert('Please select a valid image file.');
      }
    }
  }

  saveLogo() {
    if (this.newLogoPreview()) {
      this.idCardLogoUpdate.emit(this.newLogoPreview());
      this.newLogoPreview.set(null);
      this.resetFileInput('logo-upload');
    }
  }

  removeLogo() {
    if (confirm('Are you sure you want to remove the ID card logo?')) {
      this.idCardLogoUpdate.emit(null);
      this.newLogoPreview.set(null);
      this.resetFileInput('logo-upload');
    }
  }

  saveSignature() {
    if (this.newSignaturePreview()) {
      this.authorizedSignatureUpdate.emit(this.newSignaturePreview());
      this.newSignaturePreview.set(null);
      this.resetFileInput('signature-upload');
    }
  }

  removeSignature() {
    if (confirm('Are you sure you want to remove the authorized signature?')) {
      this.authorizedSignatureUpdate.emit(null);
      this.newSignaturePreview.set(null);
      this.resetFileInput('signature-upload');
    }
  }

  private resetFileInput(elementId: string) {
    const fileInput = document.getElementById(elementId) as HTMLInputElement;
    if (fileInput) {
        fileInput.value = '';
    }
  }
}