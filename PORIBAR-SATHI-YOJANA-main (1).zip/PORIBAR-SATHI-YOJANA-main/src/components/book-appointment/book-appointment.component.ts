import { Component, ChangeDetectionStrategy, input, output, signal, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Doctor } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-book-appointment',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './book-appointment.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BookAppointmentComponent {
  doctors = input.required<Doctor[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createAppointment = output<{ doctorId: string; notes?: string }>();

  private fb: FormBuilder = inject(FormBuilder);
  
  selectedDoctor = signal<Doctor | null>(null);
  state = signal<'list' | 'success'>('list');

  appointmentForm = this.fb.group({
    notes: [''],
  });

  goBack() {
    this.navigate.emit();
  }

  openBookingModal(doctor: Doctor) {
    this.selectedDoctor.set(doctor);
  }

  closeBookingModal() {
    this.selectedDoctor.set(null);
    this.appointmentForm.reset();
  }

  submitRequest() {
    if (!this.selectedDoctor()) return;

    this.createAppointment.emit({
      doctorId: this.selectedDoctor()!.id,
      notes: this.appointmentForm.value.notes || undefined,
    });
    this.state.set('success');
    this.closeBookingModal();
  }

  bookAnother() {
      this.state.set('list');
  }
}
