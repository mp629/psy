import { Component, ChangeDetectionStrategy, input, output, signal, ViewChild, ElementRef } from '@angular/core';
import { Hospital } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

declare var google: any;

interface HospitalWithDistance extends Hospital {
  distance: number | null;
}

type ViewState = 'idle' | 'loading' | 'success' | 'error';

@Component({
  selector: 'app-find-hospitals',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './find-hospitals.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FindHospitalsComponent {
  hospitals = input.required<Hospital[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();

  @ViewChild('mapContainer') mapContainer!: ElementRef;
  // FIX: Replaced google.maps.Map with any to avoid namespace error when Google Maps types are not available.
  private map!: any;

  state = signal<ViewState>('idle');
  errorMessage = signal<string | null>(null);
  nearbyHospitals = signal<HospitalWithDistance[]>([]);

  goBack() {
    this.navigate.emit();
  }
  
  findHospitals() {
    this.state.set('loading');
    this.errorMessage.set(null);
    this.nearbyHospitals.set([]);

    if (!navigator.geolocation) {
      this.errorMessage.set('Geolocation is not supported by your browser.');
      this.state.set('error');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userLat = position.coords.latitude;
        const userLon = position.coords.longitude;

        const hospitalsWithDistance = this.hospitals().map(hospital => ({
          ...hospital,
          distance: this.calculateDistance(userLat, userLon, hospital.latitude, hospital.longitude)
        })).sort((a, b) => (a.distance ?? Infinity) - (b.distance ?? Infinity));

        this.nearbyHospitals.set(hospitalsWithDistance);
        this.state.set('success');
        
        // Wait for the view to update before initializing the map
        setTimeout(() => this.initMap(userLat, userLon, hospitalsWithDistance), 0);
      },
      (error) => {
        let message = 'An unknown error occurred.';
        switch(error.code) {
          case error.PERMISSION_DENIED:
            message = "Permission to access location was denied. Please enable location services in your browser settings.";
            break;
          case error.POSITION_UNAVAILABLE:
            message = "Location information is unavailable.";
            break;
          case error.TIMEOUT:
            message = "The request to get user location timed out.";
            break;
        }
        this.errorMessage.set(message);
        this.state.set('error');
      }
    );
  }

  private initMap(userLat: number, userLon: number, hospitals: HospitalWithDistance[]): void {
    if (typeof google === 'undefined' || !this.mapContainer) {
      this.errorMessage.set('Google Maps could not be loaded. Please check your API key and internet connection.');
      this.state.set('error');
      return;
    }

    const userLocation = new google.maps.LatLng(userLat, userLon);
    // FIX: Replaced google.maps.MapOptions with any to avoid namespace error when Google Maps types are not available.
    const mapOptions: any = {
      center: userLocation,
      zoom: 13,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    this.map = new google.maps.Map(this.mapContainer.nativeElement, mapOptions);

    // Add marker for user's location
    new google.maps.Marker({
      position: userLocation,
      map: this.map,
      title: 'Your Location',
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 8,
        fillColor: '#4285F4',
        fillOpacity: 1,
        strokeColor: 'white',
        strokeWeight: 2,
      },
    });

    // Add markers for hospitals
    hospitals.forEach(hospital => {
      const hospitalLocation = new google.maps.LatLng(hospital.latitude, hospital.longitude);
      const marker = new google.maps.Marker({
        position: hospitalLocation,
        map: this.map,
        title: hospital.name,
      });

      const infoWindowContent = `
        <div class="p-1">
          <h4 class="font-bold text-md text-gray-800">${hospital.name}</h4>
          <p class="text-sm text-gray-600">${hospital.address}</p>
          <p class="text-sm font-semibold text-red-600 mt-1">Ambulance: ${hospital.ambulancePhone}</p>
        </div>
      `;

      const infoWindow = new google.maps.InfoWindow({
        content: infoWindowContent,
      });

      marker.addListener('click', () => {
        infoWindow.open(this.map, marker);
      });
    });
  }

  // Haversine formula to calculate distance
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Radius of the Earth in km
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
  }

  private deg2rad(deg: number): number {
    return deg * (Math.PI / 180);
  }
}
