import { Component, ChangeDetectionStrategy, input, output, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { PublicUser } from '../../app.component';

@Component({
  selector: 'app-career-counseling',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './career-counseling.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CareerCounselingComponent {
  currentUser = input.required<PublicUser | null>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createEducationLead = output<{ type: 'Career Counseling'; details: string }>();

  private fb: FormBuilder = inject(FormBuilder);
  
  state = signal<'form' | 'success'>('form');

  interestForm = this.fb.group({
    details: ['', [Validators.required, Validators.minLength(20)]],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string) {
    const control = this.interestForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onSubmit() {
    if (this.interestForm.invalid) {
      this.interestForm.markAllAsTouched();
      return;
    }
    const details = this.interestForm.value.details!;
    this.createEducationLead.emit({ type: 'Career Counseling', details });
    this.state.set('success');
  }
}
