import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, computed } from '@angular/core';
import { TopUpRequest } from '../../app.component';

@Component({
  selector: 'app-top-up-management',
  standalone: true,
  templateUrl: './top-up-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TopUpManagementComponent {
  requests = input.required<TopUpRequest[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() resolveTopUp = new EventEmitter<{ requestId: string; resolution: 'approved' | 'rejected' }>();

  pendingRequests = computed(() => 
    this.requests()
      .filter(r => r.status === 'pending')
      .sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime())
  );

  goBack() {
    this.navigate.emit();
  }

  onApprove(requestId: string) {
    this.resolveTopUp.emit({ requestId, resolution: 'approved' });
  }

  onReject(requestId: string) {
    this.resolveTopUp.emit({ requestId, resolution: 'rejected' });
  }
}
