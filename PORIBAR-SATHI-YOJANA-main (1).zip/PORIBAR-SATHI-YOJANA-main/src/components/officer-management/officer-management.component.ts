import { Component, ChangeDetectionStrategy, Output, EventEmitter, input, inject, effect, computed, signal, output } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Officer, Role } from '../../app.component';
import { OfficerLevel } from '../level-management/level-management.component';


@Component({
  selector: 'app-officer-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './officer-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OfficerManagementComponent {
  @Output() navigate = new EventEmitter<void>();
  @Output() createOfficer = new EventEmitter<Omit<Officer, 'id' | 'wallets' | 'status'>>();
  @Output() updateOfficer = new EventEmitter<Officer>();
  @Output() deleteOfficer = new EventEmitter<string>();
  officerStatusUpdate = output<{ officerId: string; status: 'active' | 'suspended' }>();

  officers = input.required<Officer[]>();
  roles = input.required<Role[]>();
  officerLevels = input.required<OfficerLevel[]>();
  appLogoUrl = input<string | null>(null);
  
  private fb: FormBuilder = inject(FormBuilder);
  
  creationSuccess = signal<string | null>(null);
  editingOfficer = signal<Officer | null>(null);

  states = [
    { name: 'Andhra Pradesh', code: 'AP' }, { name: 'Arunachal Pradesh', code: 'AR' }, { name: 'Assam', code: 'AS' },
    { name: 'Bihar', code: 'BR' }, { name: 'Chhattisgarh', code: 'CG' }, { name: 'Goa', code: 'GA' }, { name: 'Gujarat', code: 'GJ' },
    { name: 'Haryana', code: 'HR' }, { name: 'Himachal Pradesh', code: 'HP' }, { name: 'Jharkhand', code: 'JH' }, { name: 'Karnataka', code: 'KA' },
    { name: 'Kerala', code: 'KL' }, { name: 'Madhya Pradesh', code: 'MP' }, { name: 'Maharashtra', code: 'MH' }, { name: 'Manipur', code: 'MN' },
    { name: 'Meghalaya', code: 'ML' }, { name: 'Mizoram', code: 'MZ' }, { name: 'Nagaland', code: 'NL' }, { name: 'Odisha', code: 'OD' },
    { name: 'Punjab', code: 'PB' }, { name: 'Rajasthan', code: 'RJ' }, { name: 'Sikkim', code: 'SK' }, { name: 'Tamil Nadu', code: 'TN' },
    { name: 'Telangana', code: 'TG' }, { name: 'Tripura', code: 'TR' }, { name: 'Uttar Pradesh', code: 'UP' }, { name: 'Uttarakhand', code: 'UK' },
    { name: 'West Bengal', code: 'WB' }, { name: 'Andaman and Nicobar Islands', code: 'AN' }, { name: 'Chandigarh', code: 'CH' },
    { name: 'Dadra and Nagar Haveli and Daman and Diu', code: 'DD' }, { name: 'Delhi', code: 'DL' }, { name: 'Jammu and Kashmir', code: 'JK' },
    { name: 'Ladakh', code: 'LA' }, { name: 'Lakshadweep', code: 'LD' }, { name: 'Puducherry', code: 'PY' },
  ];

  officerForm = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(3)]],
    username: ['', [Validators.required, Validators.minLength(3)]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    dob: ['', [Validators.required]],
    state: ['WB', [Validators.required]],
    roleId: ['', [Validators.required]],
    level: [1, [Validators.required, Validators.min(1), Validators.max(12)]],
    reportsTo: [null as string | null],
  });
  
  potentialSuperiors = computed(() => {
    const editingId = this.editingOfficer()?.id;
    return this.officers().filter(o => o.id !== editingId);
  });
  
  constructor() {
      effect(() => {
          if (this.roles().length > 0 && !this.officerForm.get('roleId')?.value) {
              this.officerForm.get('roleId')?.setValue(this.roles()[0].id);
          }
      });
  }

  getRoleName(roleId: string): string {
    return this.roles().find(r => r.id === roleId)?.name || 'Unknown Role';
  }

  getLevelTitle(level: number): string {
    return this.officerLevels().find(l => l.level === level)?.title || 'Unknown Level';
  }
  
  getOfficerUsername(officerId: string | null): string {
    if (!officerId) return 'Admin';
    return this.officers().find(o => o.id === officerId)?.username || 'Unknown Officer';
  }

  goBack() {
    this.navigate.emit();
  }
  
  isInvalid(controlName: string): boolean {
    const control = this.officerForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onEdit(officer: Officer) {
    this.editingOfficer.set(officer);
    this.officerForm.reset(); 
    this.officerForm.patchValue({
        fullName: officer.fullName,
        username: officer.username,
        password: '', // Don't show current password
        dob: officer.dob, // Explicitly set dob
        state: officer.state,
        roleId: officer.roleId,
        level: officer.level,
        reportsTo: officer.reportsTo
    });

    this.officerForm.get('password')?.setValidators([Validators.minLength(6)]);
    this.officerForm.get('password')?.updateValueAndValidity();

    this.officerForm.get('username')?.disable();
    this.officerForm.get('state')?.disable();
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  onCancelEdit() {
    this.editingOfficer.set(null);
    this.officerForm.reset({ 
        state: 'WB',
        roleId: this.roles()[0]?.id || '',
        level: 1,
        reportsTo: null,
    });

    this.officerForm.get('username')?.enable();
    this.officerForm.get('state')?.enable();
    this.officerForm.get('password')?.setValidators([Validators.required, Validators.minLength(6)]);
    this.officerForm.get('password')?.updateValueAndValidity();
  }

  onSubmit() {
    if (this.officerForm.invalid) {
      this.officerForm.markAllAsTouched();
      return;
    }
    
    const formValue = this.officerForm.getRawValue();

    if (this.editingOfficer()) {
        const currentOfficer = this.editingOfficer()!;
        const updatedOfficer: Officer = {
            ...currentOfficer,
            fullName: formValue.fullName!,
            roleId: formValue.roleId!,
            level: parseInt(String(formValue.level), 10),
            reportsTo: formValue.reportsTo,
            password: formValue.password ? formValue.password : currentOfficer.password,
            dob: formValue.dob!
        };
        this.updateOfficer.emit(updatedOfficer);
        this.creationSuccess.set('Officer updated successfully!');
    } else {
        const officerData = {
            ...formValue,
            level: parseInt(String(formValue.level), 10),
        };
        this.createOfficer.emit(officerData as Omit<Officer, 'id' | 'wallets' | 'status'>);
        this.creationSuccess.set('Officer created successfully!');
    }

    this.onCancelEdit();
    setTimeout(() => this.creationSuccess.set(null), 3000);
  }

  onDeleteOfficer(id: string) {
    const hasSubordinates = this.officers().some(o => o.reportsTo === id);
    if (hasSubordinates) {
        alert('Cannot delete this officer as they are a superior to other officers. Please reassign subordinates first.');
        return;
    }
    if (confirm('Are you sure you want to delete this officer?')) {
      this.deleteOfficer.emit(id);
    }
  }

  toggleStatus(officer: Officer) {
    const newStatus = (officer.status || 'active') === 'active' ? 'suspended' : 'active';
    if (confirm(`Are you sure you want to ${newStatus === 'suspended' ? 'suspend' : 'activate'} officer ${officer.username}?`)) {
      this.officerStatusUpdate.emit({ officerId: officer.id, status: newStatus });
    }
  }
}