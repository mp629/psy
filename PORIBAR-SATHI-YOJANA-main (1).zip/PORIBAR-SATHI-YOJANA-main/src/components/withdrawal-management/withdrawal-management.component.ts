import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, computed } from '@angular/core';
import { WithdrawalRequest } from '../../app.component';

@Component({
  selector: 'app-withdrawal-management',
  standalone: true,
  templateUrl: './withdrawal-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WithdrawalManagementComponent {
  requests = input.required<WithdrawalRequest[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() resolveWithdrawal = new EventEmitter<{ requestId: string; resolution: 'approved' | 'rejected' }>();

  pendingRequests = computed(() => 
    this.requests()
      .filter(r => r.status === 'pending')
      .sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime())
  );

  goBack() {
    this.navigate.emit();
  }

  onApprove(requestId: string) {
    this.resolveWithdrawal.emit({ requestId, resolution: 'approved' });
  }

  onReject(requestId: string) {
    this.resolveWithdrawal.emit({ requestId, resolution: 'rejected' });
  }
}