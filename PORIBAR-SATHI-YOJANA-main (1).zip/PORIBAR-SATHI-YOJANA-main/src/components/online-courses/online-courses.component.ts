import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';

export interface OnlineCourse {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
}

@Component({
  selector: 'app-online-courses',
  standalone: true,
  templateUrl: './online-courses.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OnlineCoursesComponent {
  onlineCourses = input.required<OnlineCourse[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();

  goBack() {
    this.navigate.emit();
  }

  watchVideo(url: string) {
    window.open(url, '_blank');
  }
}
