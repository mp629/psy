import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject, effect } from '@angular/core';
import { PublicUser } from '../../app.component';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-user-modal',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './edit-user-modal.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EditUserModalComponent {
  user = input.required<PublicUser>();
  @Output() close = new EventEmitter<void>();
  @Output() save = new EventEmitter<PublicUser>();

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);
  
  editForm = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(3)]],
    phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
    address: ['', [Validators.required, Validators.minLength(10)]],
  });

  constructor() {
      // Use an effect to reactively update the form when the input user changes.
      effect(() => {
          const currentUser = this.user();
          if (currentUser) {
            this.editForm.patchValue({
                fullName: currentUser.fullName,
                phoneNumber: currentUser.phoneNumber,
                address: currentUser.address
            });
          }
      });
  }

  onClose() {
    this.close.emit();
  }

  onSubmit() {
    if (this.editForm.invalid) {
      this.editForm.markAllAsTouched();
      return;
    }
    
    const formValue = this.editForm.getRawValue();
    const updatedUser: PublicUser = {
      ...this.user(),
      fullName: formValue.fullName!,
      phoneNumber: formValue.phoneNumber!,
      address: formValue.address!
    };
    this.save.emit(updatedUser);
  }
  
  isInvalid(controlName: string): boolean {
    const control = this.editForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }
}