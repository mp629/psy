import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Category } from '../../app.component';

@Component({
  selector: 'app-category-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './category-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CategoryManagementComponent {
  categories = input.required<Category[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() createCategory = new EventEmitter<string>();
  @Output() deleteCategory = new EventEmitter<number>();

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);

  categoryForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(3)]],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.categoryForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onAddCategory() {
    if (this.categoryForm.invalid) {
      this.categoryForm.markAllAsTouched();
      return;
    }
    const name = this.categoryForm.value.name!;
    if (this.categories().some(c => c.name.toLowerCase() === name.toLowerCase())) {
        alert('This category already exists.');
        return;
    }
    this.createCategory.emit(name);
    this.categoryForm.reset();
  }

  onDeleteCategory(id: number) {
    if (confirm('Are you sure you want to delete this category? This might affect existing products.')) {
      this.deleteCategory.emit(id);
    }
  }
}