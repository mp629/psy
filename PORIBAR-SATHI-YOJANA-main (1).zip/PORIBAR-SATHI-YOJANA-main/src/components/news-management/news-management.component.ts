import { Component, ChangeDetectionStrategy, input, output, inject, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-news-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './news-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NewsManagementComponent {
  currentNewsUrl = input<string | null>(null);
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  newsUrlUpdate = output<string>();

  private fb: FormBuilder = inject(FormBuilder);

  newsForm = this.fb.group({
    url: ['', [Validators.required, Validators.pattern('^https?://.+$')]],
  });

  constructor() {
    effect(() => {
      this.newsForm.patchValue({ url: this.currentNewsUrl() || '' });
    });
  }

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.newsForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onSubmit() {
    if (this.newsForm.invalid) {
      this.newsForm.markAllAsTouched();
      return;
    }
    this.newsUrlUpdate.emit(this.newsForm.value.url!);
    alert('News URL updated successfully!');
    this.newsForm.markAsPristine();
  }
}