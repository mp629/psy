import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject, signal, effect } from '@angular/core';
import { PublicUser, Officer } from '../../app.component';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-my-profile',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './my-profile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MyProfileComponent {
  user = input.required<(PublicUser | Officer) | null>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<string>();
  @Output() profileUpdate = new EventEmitter<PublicUser | Officer>();

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);
  
  editMode = signal(false);
  imagePreview = signal<string | null | undefined>(null);

  profileForm = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(3)]],
    phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
    address: ['', [Validators.required, Validators.minLength(10)]],
    dob: ['', [Validators.required]],
    bankAccountNumber: ['', [Validators.pattern('^[0-9]{9,18}$')]],
    bankName: ['', [Validators.minLength(3)]],
    ifscCode: ['', [Validators.pattern('^[A-Z]{4}0[A-Z0-9]{6}$')]],
    profilePicture: [null as string | null],
    occupation: [''],
    nomineeName: [''],
    nomineeAge: [null as number | null],
    nomineeRelation: [''],
  });
  
  constructor() {
    effect(() => {
        this.updateFormAndPreview(this.user());
    });
  }

  updateFormAndPreview(currentUser: (PublicUser | Officer) | null) {
      if (currentUser) {
        const isPublic = 'registeredBy' in currentUser;
        this.profileForm.patchValue({
            fullName: currentUser.fullName,
            phoneNumber: currentUser.phoneNumber,
            address: currentUser.address,
            dob: currentUser.dob,
            bankAccountNumber: currentUser.bankAccountNumber,
            bankName: currentUser.bankName,
            ifscCode: currentUser.ifscCode,
            profilePicture: currentUser.profilePicture,
            occupation: isPublic ? (currentUser as PublicUser).occupation : undefined,
            nomineeName: isPublic ? (currentUser as PublicUser).nomineeName : undefined,
            nomineeAge: isPublic ? (currentUser as PublicUser).nomineeAge : undefined,
            nomineeRelation: isPublic ? (currentUser as PublicUser).nomineeRelation : undefined
        });
        this.imagePreview.set(currentUser.profilePicture);
      }
  }

  goBack() {
    const currentUser = this.user();
    if (!currentUser) {
        this.navigate.emit('home');
        return;
    }
    const role = 'registeredBy' in currentUser ? 'public' : 'officer';
    this.navigate.emit(role === 'public' ? 'public_panel' : 'officer');
  }

  toggleEditMode(enabled: boolean) {
    if (!enabled) {
      // If cancelling, reset form to original user state
      this.updateFormAndPreview(this.user());
    }
    this.editMode.set(enabled);
  }

  async onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      try {
        const compressedDataUrl = await this.compressImage(file, 800, 800, 0.92);
        this.imagePreview.set(compressedDataUrl);
        this.profileForm.patchValue({ profilePicture: compressedDataUrl });
        this.profileForm.get('profilePicture')?.markAsDirty();
      } catch (error) {
        console.error('Image compression failed:', error);
        // Fallback
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          this.imagePreview.set(result);
          this.profileForm.patchValue({ profilePicture: result });
          this.profileForm.get('profilePicture')?.markAsDirty();
        };
        reader.readAsDataURL(file);
      }
    }
  }
  
  removeProfilePicture() {
    this.imagePreview.set(null);
    this.profileForm.patchValue({ profilePicture: null });
    this.profileForm.get('profilePicture')?.markAsDirty();
  }

  isInvalid(controlName: string): boolean {
    const control = this.profileForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  toUpperCase(event: Event) {
    const input = event.target as HTMLInputElement;
    const uppercaseValue = input.value.toUpperCase();
    this.profileForm.get('ifscCode')?.setValue(uppercaseValue, { emitEvent: false });
    // Manually update the input value in the DOM if Angular doesn't immediately reflect it
    input.value = uppercaseValue;
  }

  private async compressImage(file: File, maxWidth: number, maxHeight: number, quality: number): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxWidth) {
                        height = Math.round(height * (maxWidth / width));
                        width = maxWidth;
                    }
                } else {
                    if (height > maxHeight) {
                        width = Math.round(width * (maxHeight / height));
                        height = maxHeight;
                    }
                }
                
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    return reject(new Error('Could not get canvas context'));
                }
                
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.onerror = (error) => reject(error);
        };
        reader.onerror = (error) => reject(error);
    });
  }

  onSubmit() {
    if (this.profileForm.invalid) {
      this.profileForm.markAllAsTouched();
      return;
    }
    
    if (!this.profileForm.dirty) {
        this.editMode.set(false);
        return;
    }

    const formValue = this.profileForm.getRawValue();
    const updatedUser: PublicUser | Officer = {
      ...this.user()!,
      fullName: formValue.fullName!,
      phoneNumber: formValue.phoneNumber!,
      address: formValue.address!,
      dob: formValue.dob!,
      bankAccountNumber: formValue.bankAccountNumber || undefined,
      bankName: formValue.bankName || undefined,
      ifscCode: formValue.ifscCode || undefined,
      profilePicture: formValue.profilePicture || undefined
    };

    if ('registeredBy' in updatedUser) {
        (updatedUser as PublicUser).occupation = formValue.occupation || undefined;
        (updatedUser as PublicUser).nomineeName = formValue.nomineeName || undefined;
        (updatedUser as PublicUser).nomineeAge = formValue.nomineeAge || undefined;
        (updatedUser as PublicUser).nomineeRelation = formValue.nomineeRelation || undefined;
    }

    this.profileUpdate.emit(updatedUser);
    this.editMode.set(false);
  }
}