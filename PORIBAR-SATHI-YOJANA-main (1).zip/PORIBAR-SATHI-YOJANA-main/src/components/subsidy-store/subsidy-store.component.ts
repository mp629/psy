import { Component, ChangeDetectionStrategy, Output, EventEmitter, signal, computed, input, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Product, Category } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { LanguageService } from '../../services/language.service';

@Component({
  selector: 'app-subsidy-store',
  standalone: true,
  imports: [FormsModule, TranslatePipe],
  templateUrl: './subsidy-store.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SubsidyStoreComponent {
  @Output() navigate = new EventEmitter<void>();
  @Output() purchase = new EventEmitter<{ product: Product, callback: (result: { success: boolean, message?: string }) => void }>();
  products = input.required<Product[]>();
  categories = input.required<Category[]>();
  mainWalletBalance = input<number>(0);
  appLogoUrl = input<string | null>(null);

  private languageService = inject(LanguageService);

  selectedProduct = signal<Product | null>(null);
  purchaseSuccess = signal(false);
  purchaseError = signal<string | null>(null);

  displayCategories = computed(() => {
    return [{ id: 0, name: this.languageService.translate('store.allCategories') }, ...this.categories()];
  });

  searchTerm = signal('');
  selectedCategory = signal(this.languageService.translate('store.allCategories'));

  filteredProducts = computed(() => {
    const term = this.searchTerm().toLowerCase();
    const category = this.selectedCategory();
    const allText = this.languageService.translate('store.allCategories');
    return this.products().filter(product => {
      const matchesCategory = category === allText || product.category === category;
      const matchesSearch = product.name.toLowerCase().includes(term);
      return matchesCategory && matchesSearch;
    });
  });

  goBack() {
    if (this.selectedProduct()) {
      this.selectedProduct.set(null);
    } else {
      this.navigate.emit();
    }
  }
  
  selectCategory(categoryName: string) {
    this.selectedCategory.set(categoryName);
  }

  onSearch(event: Event) {
    const value = (event.target as HTMLInputElement).value;
    this.searchTerm.set(value);
  }

  onPurchase(product: Product) {
    this.purchaseError.set(null); // Reset error
    this.purchase.emit({
      product: product,
      callback: (result) => {
        if (result.success) {
          this.purchaseSuccess.set(true);
          setTimeout(() => {
              this.purchaseSuccess.set(false);
              this.selectedProduct.set(null);
          }, 2500);
        } else {
          this.purchaseError.set(result.message || this.languageService.translate('aiAssistant.error.unexpected'));
          setTimeout(() => this.purchaseError.set(null), 3000); // Clear error after 3s
        }
      }
    });
  }

  selectProduct(product: Product) {
    this.purchaseError.set(null);
    this.selectedProduct.set(product);
  }
}
