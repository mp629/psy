import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Officer } from '../../app.component';
import { LanguageService } from '../../services/language.service';
import { TranslatePipe } from '../../pipes/translate.pipe';

export interface User {
  username: string;
  role: 'admin' | 'officer';
}


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, TranslatePipe],
  templateUrl: './login.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  @Output() navigate = new EventEmitter<string>();
  @Output() loginSuccess = new EventEmitter<User>();
  
  officers = input<Officer[]>([]);
  adminCredentials = input.required<{ username: string; password: string; }>();
  appLogoUrl = input<string | null>(null);

  private languageService = inject(LanguageService);

  loading = signal(false);
  error = signal<string | null>(null);

  username = signal('');
  password = signal('');

  goBack() {
    this.navigate.emit('home');
  }

  onForgotPassword() {
    this.navigate.emit('forgot_password');
  }

  onSubmit() {
    const username = this.username().trim();
    const password = this.password().trim();

    if (!username || !password) {
      this.error.set(this.languageService.translate('login.error.required'));
      return;
    }

    this.loading.set(true);
    this.error.set(null);

    // Simulate API call
    setTimeout(() => {
      this.loading.set(false);
      
      const admin = this.adminCredentials();
      // 1. Check for Admin
      if (username === admin.username && password === admin.password) {
        this.loginSuccess.emit({ username: 'admin', role: 'admin' });
        return; // Success, exit
      }
      
      // 2. Check for Officer
      const officer = this.officers().find(o => o.username === username && o.password === password);
      if (officer) {
        if (officer.status === 'suspended') {
          this.error.set(this.languageService.translate('login.error.suspended'));
          return;
        }
        this.loginSuccess.emit({ username: officer.username, role: 'officer' });
        return; // Success, exit
      }
      
      // 3. If neither matched, it's an error.
      this.error.set(this.languageService.translate('login.error.invalid'));
      
    }, 1500);
  }
}