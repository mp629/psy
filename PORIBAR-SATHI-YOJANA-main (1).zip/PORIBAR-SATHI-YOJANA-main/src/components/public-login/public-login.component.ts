import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { PublicUser } from '../../app.component';

@Component({
  selector: 'app-public-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './public-login.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PublicLoginComponent {
  @Output() navigate = new EventEmitter<string>();
  @Output() loginSuccess = new EventEmitter<PublicUser>();
  
  publicUsers = input.required<PublicUser[]>();
  appLogoUrl = input<string | null>(null);

  loading = signal(false);
  error = signal<string | null>(null);
  
  username = signal('');
  password = signal('');

  goBack() {
    this.navigate.emit('home');
  }

  onForgotPassword() {
    this.navigate.emit('forgot_password');
  }

  onSubmit() {
    const username = this.username().trim();
    const password = this.password().trim();

    if (!username || !password) {
      this.error.set('Username and password are required.');
      return;
    }

    this.loading.set(true);
    this.error.set(null);

    setTimeout(() => {
      this.loading.set(false);
      
      const user = this.publicUsers().find(u => u.username === username && u.password === password);

      if (user) {
        if (user.status === 'suspended') {
          this.error.set('Your account has been suspended. Please contact an administrator.');
          return;
        }
        // Create a copy without the password for security before emitting
        const { password, ...userToEmit } = user;
        this.loginSuccess.emit(userToEmit as PublicUser);
      } else {
        this.error.set('Invalid username or password.');
      }
      
    }, 1500);
  }
}