import { Component, ChangeDetectionStrategy, input, output, signal, computed, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Complaint } from '../complaint-box/complaint-box.component';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-complaint-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe, DatePipe],
  templateUrl: './complaint-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ComplaintManagementComponent {
  allComplaints = input.required<Complaint[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  resolveComplaint = output<{ complaintId: string; resolution: string }>();

  private fb: FormBuilder = inject(FormBuilder);
  
  filter = signal<'pending' | 'resolved'>('pending');
  selectedComplaint = signal<Complaint | null>(null);

  resolutionForm = this.fb.group({
    resolution: ['', [Validators.required, Validators.minLength(10)]],
  });

  sortedComplaints = computed(() => {
    return [...this.allComplaints()].sort((a, b) => new Date(b.submittedDate).getTime() - new Date(a.submittedDate).getTime());
  });

  filteredComplaints = computed(() => {
    const currentFilter = this.filter();
    return this.sortedComplaints().filter(c => c.status === currentFilter);
  });

  goBack() {
    this.navigate.emit();
  }

  setFilter(newFilter: 'pending' | 'resolved') {
    this.filter.set(newFilter);
  }
  
  openResolveModal(complaint: Complaint) {
    this.selectedComplaint.set(complaint);
    this.resolutionForm.reset();
  }

  closeResolveModal() {
    this.selectedComplaint.set(null);
  }

  submitResolution() {
    if (this.resolutionForm.invalid || !this.selectedComplaint()) return;

    const resolution = this.resolutionForm.value.resolution!;
    const complaintId = this.selectedComplaint()!.id;
    
    this.resolveComplaint.emit({ complaintId, resolution });
    this.closeResolveModal();
  }
}