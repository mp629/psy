import { Component, ChangeDetectionStrategy, output, input, signal } from '@angular/core';

interface School {
  name: string;
  address: string;
  type: 'School' | 'College';
}

type ViewState = 'idle' | 'loading' | 'success' | 'error';

@Component({
  selector: 'app-find-schools',
  standalone: true,
  templateUrl: './find-schools.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FindSchoolsComponent {
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();

  state = signal<ViewState>('idle');
  errorMessage = signal<string | null>(null);
  schools = signal<School[]>([]);

  goBack() {
    this.navigate.emit();
  }

  findSchools() {
    this.state.set('loading');
    this.errorMessage.set(null);
    this.schools.set([]);

    if (!navigator.geolocation) {
      this.errorMessage.set('Geolocation is not supported by your browser.');
      this.state.set('error');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        // Simulate finding schools based on location
        setTimeout(() => {
          this.schools.set([
            { name: 'Govt. High School, Sector 12', address: '123 Main St, Near City Park', type: 'School' },
            { name: 'City Central College', address: '456 College Ave, Downtown', type: 'College' },
            { name: 'Public School No. 5', address: '789 School Ln, Residential Area', type: 'School' },
            { name: 'District Polytechnic', address: '101 Technical Rd, Industrial Zone', type: 'College' },
          ]);
          this.state.set('success');
        }, 1500);
      },
      (error) => {
        let message = 'An unknown error occurred.';
        switch(error.code) {
          case error.PERMISSION_DENIED:
            message = "Permission to access location was denied. Please enable location services in your browser settings.";
            break;
          case error.POSITION_UNAVAILABLE:
            message = "Location information is unavailable.";
            break;
          case error.TIMEOUT:
            message = "The request to get user location timed out.";
            break;
        }
        this.errorMessage.set(message);
        this.state.set('error');
      }
    );
  }
}
