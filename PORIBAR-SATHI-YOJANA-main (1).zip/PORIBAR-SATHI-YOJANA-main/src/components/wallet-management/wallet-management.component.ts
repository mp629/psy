import { Component, ChangeDetectionStrategy, Output, EventEmitter, input, inject, signal, computed } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { PublicUser, Officer, Wallets } from '../../app.component';

export interface WalletUpdateEvent {
  targetId: string | number;
  targetType: 'public' | 'officer';
  wallet: keyof Wallets;
  transactionType: 'credit' | 'debit';
  amount: number;
  reason: string;
}

type UserOrOfficer = (PublicUser & { type: 'public' }) | (Officer & { type: 'officer' });

@Component({
  selector: 'app-wallet-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './wallet-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WalletManagementComponent {
  @Output() navigate = new EventEmitter<void>();
  @Output() walletUpdate = new EventEmitter<WalletUpdateEvent>();

  publicUsers = input.required<PublicUser[]>();
  officers = input.required<Officer[]>();
  appLogoUrl = input<string | null>(null);

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);

  selectedUserId = signal<string | number | null>(null);
  selectedUserType = signal<'public' | 'officer'>('public');

  loading = signal(false);
  successMessage = signal<string | null>(null);

  walletForm = this.fb.group({
    wallet: ['main', [Validators.required]],
    transactionType: ['credit', [Validators.required]],
    amount: [null as number | null, [Validators.required, Validators.min(0.01)]],
    reason: ['', [Validators.required, Validators.minLength(5)]],
  });

  allUsers = computed<UserOrOfficer[]>(() => [
    ...this.publicUsers().map(u => ({ ...u, type: 'public' as const })),
    ...this.officers().map(o => ({ ...o, type: 'officer' as const }))
  ]);

  filteredUsers = computed(() => {
    return this.allUsers().filter(u => u.type === this.selectedUserType());
  });
  
  selectedUser = computed<UserOrOfficer | null>(() => {
    const userId = this.selectedUserId();
    if (!userId) return null;
    return this.allUsers().find(u => String(u.id) === String(userId)) ?? null;
  });

  walletsArray = computed(() => {
    const user = this.selectedUser();
    if (!user) return [];
    
    const walletLabels: Record<keyof Wallets, string> = {
      main: 'Main',
      subsidy: 'Subsidy',
      incentive: 'Incentive',
      pf: 'PF',
      psyCoin: 'PSY Coin'
    };
    
    return (Object.keys(user.wallets) as Array<keyof Wallets>).map(key => ({
      key: key,
      label: walletLabels[key],
      balance: user.wallets[key].balance
    }));
  });

  goBack() {
    this.navigate.emit();
  }

  onUserTypeChange(event: Event) {
    this.selectedUserType.set((event.target as HTMLSelectElement).value as 'public' | 'officer');
    this.selectedUserId.set(null);
    this.successMessage.set(null); // Clear success message on list change
  }

  onUserChange(event: Event) {
    this.selectedUserId.set((event.target as HTMLSelectElement).value);
    this.successMessage.set(null);
  }

  isInvalid(controlName: string): boolean {
    const control = this.walletForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onSubmit() {
    if (this.walletForm.invalid || !this.selectedUserId()) {
      this.walletForm.markAllAsTouched();
      if (!this.selectedUserId()) {
        alert('Please select a user first.');
      }
      return;
    }

    this.loading.set(true);
    this.successMessage.set(null);
    const formValue = this.walletForm.getRawValue();

    setTimeout(() => {
      this.walletUpdate.emit({
        targetId: this.selectedUserId()!,
        targetType: this.selectedUserType(),
        wallet: formValue.wallet as keyof Wallets,
        transactionType: formValue.transactionType as 'credit' | 'debit',
        amount: formValue.amount!,
        reason: formValue.reason!
      });
      
      this.loading.set(false);
      const user = this.selectedUser();
      const walletLabel = this.walletsArray().find(w => w.key === formValue.wallet)?.label;
      this.successMessage.set(`Successfully ${formValue.transactionType === 'credit' ? 'credited' : 'debited'} ${user?.username}'s ${walletLabel} wallet.`);
      this.walletForm.reset({
        wallet: 'main',
        transactionType: 'credit',
        amount: null,
        reason: ''
      });
    }, 1500);
  }
}