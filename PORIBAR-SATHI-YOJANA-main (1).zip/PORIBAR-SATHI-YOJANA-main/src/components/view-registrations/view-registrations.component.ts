import { Component, ChangeDetectionStrategy, Output, EventEmitter, input, computed } from '@angular/core';
import { RegisteredIndividual, LoggedInOfficial } from '../../app.component';

@Component({
  selector: 'app-view-registrations',
  standalone: true,
  templateUrl: './view-registrations.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ViewRegistrationsComponent {
  @Output() navigate = new EventEmitter<string>();
  
  allRegistrations = input.required<RegisteredIndividual[]>();
  currentUser = input.required<LoggedInOfficial | null>();
  appLogoUrl = input<string | null>(null);

  myRegistrations = computed(() => {
    const username = this.currentUser()?.username;
    if (!username) return [];
    return this.allRegistrations().filter(reg => reg.registeredBy === username);
  });

  goBack() {
    this.navigate.emit('officer');
  }
}