import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject, signal, computed, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { PublicUser, Officer, Wallets } from '../../app.component';

type Recipient = { id: string, name: string, type: 'public' | 'officer' };

@Component({
  selector: 'app-p2p-transfer',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './p2p-transfer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class P2pTransferComponent {
  currentUser = input.required<(PublicUser | Officer) | null>();
  currentWallets = input.required<Wallets>();
  allUsers = input.required<PublicUser[]>();
  allOfficers = input.required<Officer[]>();
  preselectedRecipient = input<{ id: string; type: 'public' | 'officer' } | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() p2pTransfer = new EventEmitter<{
    fromId: string;
    fromType: 'public' | 'officer';
    toId: string;
    toType: 'public' | 'officer';
    amount: number;
  }>();

  private fb: FormBuilder = inject(FormBuilder);

  state = signal<'form' | 'loading' | 'success'>('form');
  successDetails = signal<{ amount: number; recipientName: string } | null>(null);

  transferForm = this.fb.group({
    recipient: ['', Validators.required],
    amount: [null as number | null, [Validators.required, Validators.min(0.0001)]],
  });

  recipients = computed<Recipient[]>(() => {
    const currentUserId = this.currentUser()?.id;
    const users = this.allUsers()
      .filter(u => u.id !== currentUserId)
      .map(u => ({ id: u.id, name: `${u.username} (User)`, type: 'public' as const }));
    const officers = this.allOfficers()
      .filter(o => o.id !== currentUserId)
      .map(o => ({ id: o.id, name: `${o.username} (Officer)`, type: 'officer' as const }));
    return [...users, ...officers].sort((a, b) => a.name.localeCompare(b.name));
  });

  constructor() {
    effect(() => {
        const recipient = this.preselectedRecipient();
        if (recipient) {
            const recipientValue = `${recipient.id}:${recipient.type}`;
            this.transferForm.get('recipient')?.setValue(recipientValue);
        }
    });

    this.transferForm.get('amount')?.valueChanges.subscribe(() => {
        this.updateAmountValidators();
    });
  }
  
  updateAmountValidators() {
    const balance = this.currentWallets().psyCoin.balance;
    this.transferForm.get('amount')?.setValidators([
        Validators.required, 
        Validators.min(0.0001), 
        Validators.max(balance)
    ]);
    this.transferForm.get('amount')?.updateValueAndValidity({ emitEvent: false });
  }

  goBack() {
    this.navigate.emit();
  }
  
  isInvalid(controlName: string) {
    const control = this.transferForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onSubmit() {
    this.updateAmountValidators(); // Final check before submitting
    if (this.transferForm.invalid) {
      this.transferForm.markAllAsTouched();
      return;
    }
    
    this.state.set('loading');
    const formValue = this.transferForm.getRawValue();
    const recipientInfo = formValue.recipient!.split(':');
    const toId = recipientInfo[0];
    const toType = recipientInfo[1] as 'public' | 'officer';
    const amount = formValue.amount!;
    const fromUser = this.currentUser()!;

    setTimeout(() => {
        this.p2pTransfer.emit({
            fromId: fromUser.id,
            fromType: 'registeredBy' in fromUser ? 'public' : 'officer',
            toId: toId,
            toType: toType,
            amount: amount,
        });
        
        const recipientName = this.recipients().find(r => r.id === toId)?.name || 'the recipient';
        this.successDetails.set({ amount, recipientName });
        this.state.set('success');
    }, 1500);
  }
  
  startNewTransfer() {
      this.state.set('form');
      this.transferForm.reset();
      this.successDetails.set(null);
  }
}