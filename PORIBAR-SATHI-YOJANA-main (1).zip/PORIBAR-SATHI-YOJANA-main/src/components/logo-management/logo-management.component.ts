
import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, signal } from '@angular/core';

@Component({
  selector: 'app-logo-management',
  standalone: true,
  templateUrl: './logo-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogoManagementComponent {
  currentLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() logoUpdate = new EventEmitter<string | null>();

  newLogoPreview = signal<string | null>(null);
  selectedFile = signal<File | null>(null);

  goBack() {
    this.navigate.emit();
  }

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      if (file.type.startsWith('image/')) {
        this.selectedFile.set(file);
        const reader = new FileReader();
        reader.onload = (e) => {
          this.newLogoPreview.set(e.target?.result as string);
        };
        reader.readAsDataURL(file);
      } else {
        alert('Please select a valid image file (PNG, JPG, etc.).');
      }
    }
  }

  saveLogo() {
    if (this.newLogoPreview()) {
      this.logoUpdate.emit(this.newLogoPreview());
      this.reset();
    }
  }

  removeLogo() {
    if (confirm('Are you sure you want to remove the app logo?')) {
      this.logoUpdate.emit(null);
      this.reset();
    }
  }

  private reset() {
    this.selectedFile.set(null);
    this.newLogoPreview.set(null);
    const fileInput = document.getElementById('logo-upload') as HTMLInputElement;
    if (fileInput) {
        fileInput.value = '';
    }
  }
}
