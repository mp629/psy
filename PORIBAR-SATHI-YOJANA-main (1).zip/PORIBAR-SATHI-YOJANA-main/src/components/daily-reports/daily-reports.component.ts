import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject, computed, signal } from '@angular/core';
import { Officer, DailyReport } from '../../app.component';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

export type DailyReportSubmission = Omit<DailyReport, 'officerUsername' | 'date'>;

@Component({
  selector: 'app-daily-reports',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './daily-reports.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DailyReportsComponent {
  officer = input.required<Officer | null>();
  myReports = input.required<DailyReport[]>();
  appLogoUrl = input<string | null>(null);
  
  @Output() navigate = new EventEmitter<void>();
  @Output() submitReport = new EventEmitter<DailyReportSubmission>();

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);
  loading = signal(false);

  reportForm = this.fb.group({
    registrationsCompleted: [0, [Validators.required, Validators.min(0)]],
    applicationsAssisted: [0, [Validators.required, Validators.min(0)]],
    villagesVisited: ['', [Validators.required]],
    summary: ['', [Validators.required, Validators.minLength(10)]],
  });

  todaysDate = computed(() => new Date().toISOString().split('T')[0]);

  todaysReport = computed<DailyReport | undefined>(() => {
    const today = this.todaysDate();
    return this.myReports().find(report => report.date === today);
  });

  hasSubmittedToday = computed<boolean>(() => !!this.todaysReport());
  
  pastReports = computed<DailyReport[]>(() => {
    const today = this.todaysDate();
    return this.myReports().filter(report => report.date !== today);
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.reportForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onSubmit() {
    if (this.reportForm.invalid || this.hasSubmittedToday()) {
      this.reportForm.markAllAsTouched();
      return;
    }

    this.loading.set(true);
    // Simulate API call
    setTimeout(() => {
      this.loading.set(false);
      this.submitReport.emit(this.reportForm.getRawValue() as DailyReportSubmission);
      this.reportForm.reset({
        registrationsCompleted: 0,
        applicationsAssisted: 0,
        villagesVisited: '',
        summary: ''
      });
    }, 1500);
  }
}