import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, signal } from '@angular/core';
import { Order } from '../../app.component';

@Component({
  selector: 'app-purchase-history',
  standalone: true,
  templateUrl: './purchase-history.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PurchaseHistoryComponent {
  orders = input.required<Order[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  
  selectedOrderDetails = signal<Order | null>(null);

  goBack() {
    this.navigate.emit();
  }
  
  viewDetails(order: Order) {
    this.selectedOrderDetails.set(order);
  }
  
  closeDetails() {
    this.selectedOrderDetails.set(null);
  }
}
