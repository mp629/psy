import { Component, ChangeDetectionStrategy, input, output, signal, computed, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Appointment, HealthRecord } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-appointment-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe, DatePipe],
  templateUrl: './appointment-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppointmentManagementComponent {
  appointments = input.required<Appointment[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  updateAppointment = output<Appointment>();
  createHealthRecord = output<Omit<HealthRecord, 'id'>>();

  private fb: FormBuilder = inject(FormBuilder);
  
  filter = signal<'pending' | 'approved' | 'completed' | 'rejected'>('pending');
  selectedForScheduling = signal<Appointment | null>(null);
  selectedForRecord = signal<Appointment | null>(null);

  scheduleForm = this.fb.group({
    scheduledTime: ['', Validators.required]
  });

  healthRecordForm = this.fb.group({
    diagnosis: ['', Validators.required],
    prescription: ['', Validators.required],
  });

  sortedAppointments = computed(() => {
    return [...this.appointments()].sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime());
  });

  filteredAppointments = computed(() => {
    const currentFilter = this.filter();
    return this.sortedAppointments().filter(app => app.status === currentFilter);
  });

  goBack() {
    this.navigate.emit();
  }

  setFilter(newFilter: 'pending' | 'approved' | 'completed' | 'rejected') {
    this.filter.set(newFilter);
  }

  onUpdateStatus(appointment: Appointment, status: Appointment['status']) {
    this.updateAppointment.emit({ ...appointment, status });
  }

  openScheduleModal(appointment: Appointment) {
    this.selectedForScheduling.set(appointment);
    this.scheduleForm.reset();
  }

  closeScheduleModal() {
    this.selectedForScheduling.set(null);
  }

  submitSchedule() {
    if (this.scheduleForm.invalid || !this.selectedForScheduling()) return;
    const { scheduledTime } = this.scheduleForm.value;
    this.updateAppointment.emit({ ...this.selectedForScheduling()!, scheduledTime: scheduledTime!, status: 'approved' });
    this.closeScheduleModal();
  }

  openRecordModal(appointment: Appointment) {
    this.selectedForRecord.set(appointment);
    this.healthRecordForm.reset();
  }

  closeRecordModal() {
    this.selectedForRecord.set(null);
  }

  submitHealthRecord() {
    if (this.healthRecordForm.invalid || !this.selectedForRecord()) return;

    const appointment = this.selectedForRecord()!;
    const { diagnosis, prescription } = this.healthRecordForm.value;

    this.createHealthRecord.emit({
      userId: appointment.userId,
      appointmentId: appointment.id,
      recordDate: new Date().toISOString().split('T')[0],
      doctorName: appointment.doctorName,
      specialization: 'N/A', // Specialization would ideally be on the doctor object
      diagnosis: diagnosis!,
      prescription: prescription!
    });
    
    this.updateAppointment.emit({ ...appointment, status: 'completed' });
    this.closeRecordModal();
  }
}