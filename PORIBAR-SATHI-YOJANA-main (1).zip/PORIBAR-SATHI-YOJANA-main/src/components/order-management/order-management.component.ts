import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, signal, inject, computed } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Order, PublicUser } from '../../app.component';

@Component({
  selector: 'app-order-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './order-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderManagementComponent {
  orders = input.required<Order[]>();
  users = input.required<PublicUser[]>();
  appLogoUrl = input<string | null>(null);

  @Output() navigate = new EventEmitter<void>();
  @Output() updateOrder = new EventEmitter<Order>();

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);

  selectedOrderForEdit = signal<Order | null>(null);

  orderStatuses: Order['status'][] = ['Processing', 'Shipped', 'Delivered', 'Cancelled'];

  editForm = this.fb.group({
    status: ['Processing' as Order['status'], [Validators.required]],
    courierName: [''],
    trackingNumber: [''],
  });

  sortedOrders = computed(() => {
    return [...this.orders()].sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());
  });

  goBack() {
    this.navigate.emit();
  }

  getUserFullName(userId: string): string {
    return this.users().find(u => u.id === userId)?.fullName || 'Unknown User';
  }

  onEditOrder(order: Order) {
    this.selectedOrderForEdit.set(order);
    this.editForm.patchValue({
      status: order.status,
      courierName: order.courierName || '',
      trackingNumber: order.trackingNumber || '',
    });
  }

  closeEditModal() {
    this.selectedOrderForEdit.set(null);
    this.editForm.reset({ status: 'Processing', courierName: '', trackingNumber: '' });
  }

  onSubmit() {
    if (this.editForm.invalid || !this.selectedOrderForEdit()) {
      return;
    }
    
    const formValue = this.editForm.getRawValue();
    const updatedOrder: Order = {
      ...this.selectedOrderForEdit()!,
      status: formValue.status!,
      courierName: formValue.courierName || undefined,
      trackingNumber: formValue.trackingNumber || undefined,
    };
    
    this.updateOrder.emit(updatedOrder);
    this.closeEditModal();
  }
}