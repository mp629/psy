import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, signal, inject, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Product, Category } from '../../app.component';

@Component({
  selector: 'app-product-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './product-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductManagementComponent {
    products = input.required<Product[]>();
    categories = input.required<Category[]>();
    appLogoUrl = input<string | null>(null);
    @Output() navigate = new EventEmitter<void>();
    @Output() createProduct = new EventEmitter<Omit<Product, 'id'>>();
    @Output() updateProduct = new EventEmitter<Product>();
    @Output() deleteProduct = new EventEmitter<number>();

    // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
    private fb: FormBuilder = inject(FormBuilder);

    editingProduct = signal<Product | null>(null);
    
    productForm = this.fb.group({
        name: ['', [Validators.required, Validators.minLength(3)]],
        description: ['', [Validators.required, Validators.minLength(10)]],
        category: ['', [Validators.required]],
        price: [null as number | null, [Validators.required, Validators.min(0)]],
        originalPrice: [null as number | null, [Validators.required, Validators.min(0)]],
        imageUrl: ['', [Validators.required, Validators.pattern('^https?://.+$')]]
    });
    
    constructor() {
        // Set default category when categories are loaded
        effect(() => {
            if (this.categories().length > 0 && !this.productForm.get('category')?.value) {
                this.productForm.get('category')?.setValue(this.categories()[0].name);
            }
        });
    }

    goBack() { 
        this.navigate.emit();
    }

    isInvalid(controlName: string): boolean {
        const control = this.productForm.get(controlName);
        return !!control && control.invalid && (control.dirty || control.touched);
    }

    onEdit(product: Product) {
        this.editingProduct.set(product);
        this.productForm.patchValue(product);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    onCancelEdit() {
        this.editingProduct.set(null);
        const defaultCategory = this.categories().length > 0 ? this.categories()[0].name : '';
        this.productForm.reset({ category: defaultCategory });
    }

    onDelete(id: number) {
        if (confirm('Are you sure you want to delete this product?')) {
            this.deleteProduct.emit(id);
        }
    }

    onSubmit() {
        if (this.productForm.invalid) {
            this.productForm.markAllAsTouched();
            return;
        }

        const formValue = this.productForm.getRawValue();

        if (this.editingProduct()) {
            const updatedProduct: Product = {
                ...this.editingProduct()!,
                name: formValue.name!,
                description: formValue.description!,
                category: formValue.category!,
                price: formValue.price!,
                originalPrice: formValue.originalPrice!,
                imageUrl: formValue.imageUrl!,
            };
            this.updateProduct.emit(updatedProduct);
        } else {
            this.createProduct.emit(formValue as Omit<Product, 'id'>);
        }
        this.onCancelEdit(); // Reset form and state
    }
}