
import { Component, ChangeDetectionStrategy, input, Output, EventEmitter } from '@angular/core';
import { Transaction } from '../../app.component';

@Component({
  selector: 'app-transaction-detail-modal',
  standalone: true,
  templateUrl: './transaction-detail-modal.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TransactionDetailModalComponent {
  transaction = input.required<Transaction>();
  @Output() close = new EventEmitter<void>();

  onClose() {
    this.close.emit();
  }
}
