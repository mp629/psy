import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators, AbstractControl, ValidationErrors } from '@angular/forms';

export interface PasswordChangeEvent {
  currentPassword: string;
  newPassword: string;
  callback: (success: boolean) => void;
}

// Custom validator to check if new password and confirm password match
export function passwordsMatchValidator(control: AbstractControl): ValidationErrors | null {
  const newPassword = control.get('newPassword');
  const confirmPassword = control.get('confirmPassword');
  
  if (newPassword && confirmPassword && newPassword.value !== confirmPassword.value) {
    return { passwordsMismatch: true };
  }
  
  return null;
}

@Component({
  selector: 'app-change-password',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './change-password.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChangePasswordComponent {
  @Output() navigate = new EventEmitter<void>();
  @Output() passwordChangeRequest = new EventEmitter<PasswordChangeEvent>();
  appLogoUrl = input<string | null>(null);

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);

  changeStatus = signal<'idle' | 'loading' | 'success' | 'error'>('idle');
  errorMessage = signal('');

  passwordForm = this.fb.group({
    currentPassword: ['', [Validators.required]],
    newPassword: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', [Validators.required]],
  }, { validators: passwordsMatchValidator });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string, errorName?: string): boolean {
    const control = this.passwordForm.get(controlName);
    if (errorName) {
      return !!control && control.hasError(errorName) && (control.dirty || control.touched);
    }
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  isFormInvalid(errorName: string): boolean {
    return this.passwordForm.hasError(errorName) && (this.passwordForm.get('confirmPassword')?.dirty || this.passwordForm.get('confirmPassword')?.touched);
  }

  onSubmit() {
    if (this.passwordForm.invalid) {
      this.passwordForm.markAllAsTouched();
      return;
    }

    this.changeStatus.set('loading');
    this.errorMessage.set('');

    const formValue = this.passwordForm.value;
    
    this.passwordChangeRequest.emit({
      currentPassword: formValue.currentPassword!,
      newPassword: formValue.newPassword!,
      callback: (success) => {
        if (success) {
          this.changeStatus.set('success');
          this.passwordForm.reset();
        } else {
          this.changeStatus.set('error');
          this.errorMessage.set('The current password you entered is incorrect.');
        }
      }
    });
  }
  
  returnToAdmin() {
    this.navigate.emit();
  }
}