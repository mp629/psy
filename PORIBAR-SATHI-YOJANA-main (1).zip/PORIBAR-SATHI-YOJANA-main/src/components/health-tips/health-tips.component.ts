import { Component, ChangeDetectionStrategy, inject, signal, input, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';

export interface HealthArticle {
  id: string;
  title: string;
  description: string;
  url: string;
}

interface AiHealthTip {
  title: string;
  tip: string;
}

@Component({
  selector: 'app-health-tips',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './health-tips.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HealthTipsComponent {
  @Output() navigate = new EventEmitter<void>();
  appLogoUrl = input<string | null>(null);
  articles = input.required<HealthArticle[]>();
  
  private geminiService = inject(GeminiService);

  activeTab = signal<'ai' | 'articles'>('ai');
  healthConcern = signal('');
  loading = signal(false);
  error = signal<string | null>(null);
  aiTips = signal<AiHealthTip[]>([]);

  goBack() {
    this.navigate.emit();
  }
  
  selectTab(tab: 'ai' | 'articles') {
    this.activeTab.set(tab);
  }

  visitArticle(url: string) {
    window.open(url, '_blank');
  }

  async getAiTips() {
    if (!this.healthConcern().trim()) return;

    this.loading.set(true);
    this.error.set(null);
    this.aiTips.set([]);

    const prompt = `
      Based on the health concern "${this.healthConcern()}", provide 3-5 simple, actionable health tips.
      Also include a strong disclaimer that this is not medical advice.
      Respond ONLY with a valid JSON array of objects, where each object has "title" and "tip" string properties. 
      The first object in the array MUST be the disclaimer. For example: [{"title": "Disclaimer", "tip": "This is not a substitute for professional medical advice..."}].
      Do not include any other text or markdown formatting.
    `;

    try {
      const response = await this.geminiService.generateThoughtfulResponse(prompt);
      const responseText = response.text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsedTips: AiHealthTip[] = JSON.parse(responseText);
      this.aiTips.set(parsedTips);
    } catch (e) {
      console.error("AI Health Tips Error:", e);
      this.error.set("The AI could not generate tips for your concern. Please try rephrasing or try again later.");
    } finally {
      this.loading.set(false);
    }
  }
}
