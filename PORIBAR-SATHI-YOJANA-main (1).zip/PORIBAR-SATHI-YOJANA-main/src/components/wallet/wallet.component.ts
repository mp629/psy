import { Component, ChangeDetectionStrategy, Output, EventEmitter, signal, input, computed, inject } from '@angular/core';
import { Wallets, Transaction } from '../../app.component';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TransactionDetailModalComponent } from '../transaction-detail-modal/transaction-detail-modal.component';


@Component({
  selector: 'app-wallet',
  standalone: true,
  imports: [ReactiveFormsModule, TransactionDetailModalComponent],
  templateUrl: './wallet.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WalletComponent {
  @Output() navigate = new EventEmitter<string>();
  @Output() buyCoins = new EventEmitter<number>();
  @Output() sellCoins = new EventEmitter<number>();
  @Output() withdrawalRequest = new EventEmitter<{ amount: number; wallet: 'subsidy' | 'incentive' }>();

  wallets = input.required<Wallets>();
  userRole = input<'public' | 'officer' | 'admin' | null>(null);
  psyCoinPrice = input.required<number>();
  appLogoUrl = input<string | null>(null);

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);
  
  viewMode = signal<'dashboard' | 'buy' | 'sell'>('dashboard');
  loading = signal(false);
  transactionSuccess = signal(false);
  selectedTransaction = signal<Transaction | null>(null);

  // Withdrawal Modal State
  showWithdrawModal = signal(false);
  withdrawWallet = signal<'subsidy' | 'incentive' | null>(null);

  // Filter signals
  filterType = signal<'all' | 'credit' | 'debit'>('all');
  filterWallet = signal<string>('all'); // 'all' or keyof Wallets

  tradeForm = this.fb.group({
    amount: [null as number | null, [Validators.required, Validators.min(0.0001)]]
  });

  withdrawForm = this.fb.group({
    amount: [null as number | null, [Validators.required, Validators.min(1)]]
  });

  allTransactions = computed(() => {
    const w = this.wallets();
    const role = this.userRole();

    const transactions: Transaction[] = [
      ...w.main.transactions,
      ...w.subsidy.transactions,
      ...w.pf.transactions,
      ...w.psyCoin.transactions,
    ];

    if (role === 'officer' || role === 'admin') {
      transactions.push(...w.incentive.transactions);
    }

    // Sort by date, newest first
    return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });
  
  walletFilterOptions = computed(() => {
    const availableWallets = [
        { key: 'all', label: 'All Wallets' },
        { key: 'main', label: 'Main' },
        { key: 'subsidy', label: 'Subsidy' },
        { key: 'pf', label: 'PF' },
        { key: 'psyCoin', label: 'PSY Coin' },
    ];
    if (this.userRole() === 'officer' || this.userRole() === 'admin') {
        availableWallets.splice(3, 0, { key: 'incentive', label: 'Incentive' });
    }
    return availableWallets;
  });

  filteredTransactions = computed(() => {
    const type = this.filterType();
    const wallet = this.filterWallet();
    
    return this.allTransactions().filter(tx => {
        const typeMatch = type === 'all' || tx.type === type;
        const walletMatch = wallet === 'all' || tx.wallet === wallet;
        return typeMatch && walletMatch;
    });
  });

  psyCoinValue = computed(() => {
    return this.wallets().psyCoin.balance * this.psyCoinPrice();
  });

  conversionValue = computed(() => {
    const amount = this.tradeForm.get('amount')?.value;
    if (!amount) return 0;
    return this.viewMode() === 'buy' ? amount / this.psyCoinPrice() : amount * this.psyCoinPrice();
  });

  goBack() {
    this.navigate.emit(this.userRole() === 'public' ? 'public_panel' : (this.userRole() ? 'officer' : 'home'));
  }

  isInvalid(form: 'trade' | 'withdraw', controlName: string): boolean {
    const control = form === 'trade' ? this.tradeForm.get(controlName) : this.withdrawForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  openTradeView(mode: 'buy' | 'sell') {
    this.transactionSuccess.set(false);
    this.tradeForm.reset();
    
    const maxAmount = mode === 'buy' 
      ? this.wallets().main.balance 
      : this.wallets().psyCoin.balance;
    this.tradeForm.get('amount')?.setValidators([Validators.required, Validators.min(0.0001), Validators.max(maxAmount)]);
    this.tradeForm.get('amount')?.updateValueAndValidity();

    this.viewMode.set(mode);
  }

  returnToDashboard() {
    this.viewMode.set('dashboard');
  }

  onActionClick(action: string) {
    if (action === 'Transfer') {
      this.navigate.emit('p2p_transfer');
    } else {
      this.navigate.emit(`coming_soon:${action}`);
    }
  }

  onTopUp() {
    this.navigate.emit('top_up');
  }
  
  onSubmitTrade() {
    if (this.tradeForm.invalid) {
      this.tradeForm.markAllAsTouched();
      return;
    }
    
    this.loading.set(true);
    const amount = this.tradeForm.get('amount')?.value;

    setTimeout(() => {
      if (this.viewMode() === 'buy') {
        this.buyCoins.emit(amount);
      } else {
        this.sellCoins.emit(amount);
      }
      this.loading.set(false);
      this.transactionSuccess.set(true);
    }, 1500);
  }

  setFilterType(type: 'all' | 'credit' | 'debit') {
    this.filterType.set(type);
  }

  setFilterWallet(event: Event) {
    const walletKey = (event.target as HTMLSelectElement).value;
    this.filterWallet.set(walletKey);
  }

  showTransactionDetails(transaction: Transaction) {
    this.selectedTransaction.set(transaction);
  }

  closeTransactionModal() {
    this.selectedTransaction.set(null);
  }
  
  openWithdrawModal(wallet: 'subsidy' | 'incentive') {
    this.withdrawWallet.set(wallet);
    const maxAmount = this.wallets()[wallet].balance;
    this.withdrawForm.get('amount')?.setValidators([Validators.required, Validators.min(1), Validators.max(maxAmount)]);
    this.withdrawForm.reset();
    this.showWithdrawModal.set(true);
  }

  closeWithdrawModal() {
    this.showWithdrawModal.set(false);
  }

  submitWithdrawal() {
    if (this.withdrawForm.invalid || !this.withdrawWallet()) {
      return;
    }
    const amount = this.withdrawForm.value.amount!;
    this.withdrawalRequest.emit({ amount, wallet: this.withdrawWallet()! });
    this.closeWithdrawModal();
    alert('Withdrawal request sent successfully!');
  }
}
