import { Component, ChangeDetectionStrategy, Output, EventEmitter, input, inject, signal, effect, DestroyRef } from '@angular/core';
import { Banner } from '../banner-management/banner-management.component';
import { PublicUser } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { LanguageService } from '../../services/language.service';
import { Advertisement } from '../advertisement-management/advertisement-management.component';

interface Service {
  name: string;
  icon: string;
  action: string;
}

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [TranslatePipe]
})
export class HomeComponent {
  @Output() navigate = new EventEmitter<string>();
  @Output() logout = new EventEmitter<void>();
  
  banners = input.required<Banner[]>();
  advertisementBanners = input.required<Advertisement[]>();
  loggedInPublicUser = input<PublicUser | null>(null);
  appLogoUrl = input<string | null>(null);

  languageService = inject(LanguageService);

  services: Service[] = [
    { name: 'home.service.store', icon: 'storefront', action: 'store' },
    { name: 'home.service.health', icon: 'health_and_safety', action: 'health' },
    { name: 'home.service.bmi', icon: 'scale', action: 'bmi_calculator' },
    { name: 'home.service.health_guide', icon: 'mic', action: 'health_guide' },
    { name: 'home.service.nutrition_scanner', icon: 'camera_alt', action: 'nutrition_scanner' },
    { name: 'home.service.game', icon: 'sports_esports', action: 'game' },
    { name: 'home.service.scan_qr', icon: 'qr_code_scanner', action: 'qr_scanner' },
    { name: 'home.service.news', icon: 'newspaper', action: 'news' },
    { name: 'home.service.sarkari_seva', icon: 'account_balance', action: 'sarkari_seva' },
    { name: 'home.service.sarkari_seva_finder', icon: 'manage_search', action: 'sarkari_seva_finder' },
    { name: 'home.service.complaint_box', icon: 'feedback', action: 'complaint_box' },
    { name: 'home.service.benefits', icon: 'redeem', action: 'benefits' },
    { name: 'home.service.apply', icon: 'assignment', action: 'apply' },
    { name: 'home.service.image_studio', icon: 'palette', action: 'editor' },
    { name: 'home.service.ai_assistant', icon: 'psychology', action: 'ai_assistant' },
    { name: 'home.service.education', icon: 'school', action: 'education' },
    { name: 'home.service.other_services', icon: 'public', action: 'services' },
    { name: 'home.service.admin_panel', icon: 'admin_panel_settings', action: 'admin' },
    { name: 'home.service.officer_panel', icon: 'badge', action: 'officer' },
    { name: 'home.service.user_login', icon: 'person', action: 'public_login' },
  ];

  // Slider logic
  currentBannerIndex = signal(0);
  currentAdIndex = signal(0);
  private bannerInterval: any;
  private adInterval: any;
  private destroyRef = inject(DestroyRef);

  constructor() {
    // Effect for the main banner slider
    effect(() => {
      const mainBanners = this.banners();
      this.stopBannerSlider();
      this.currentBannerIndex.set(0);

      if (mainBanners && mainBanners.length > 1) {
        this.bannerInterval = setInterval(() => {
          this.currentBannerIndex.update(i => (i + 1) % mainBanners.length);
        }, 4000); // Change banner every 4 seconds

        this.destroyRef.onDestroy(() => {
          this.stopBannerSlider();
        });
      }
    });

    // Effect for the advertisement banner slider
    effect(() => {
      const adBanners = this.advertisementBanners();
      this.stopAdSlider();
      this.currentAdIndex.set(0);

      if (adBanners && adBanners.length > 1) {
        this.adInterval = setInterval(() => {
          this.currentAdIndex.update(i => (i + 1) % adBanners.length);
        }, 5000); // Change ad every 5 seconds

        this.destroyRef.onDestroy(() => {
          this.stopAdSlider();
        });
      }
    });
  }
  
  private stopBannerSlider() {
    if (this.bannerInterval) {
      clearInterval(this.bannerInterval);
      this.bannerInterval = null;
    }
  }

  private stopAdSlider() {
    if (this.adInterval) {
      clearInterval(this.adInterval);
      this.adInterval = null;
    }
  }

  onServiceClick(action: string) {
    this.navigate.emit(action);
  }

  onLogout() {
    this.logout.emit();
  }

  setLanguage(lang: 'en' | 'bn' | 'hi') {
    this.languageService.setLanguage(lang);
  }
}
