import { Component, ChangeDetectionStrategy, input, output, signal, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { PublicUser } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { DatePipe } from '@angular/common';

export interface Complaint {
  id: string;
  userId: string;
  username: string;
  subject: string;
  details: string;
  submittedDate: string;
  status: 'pending' | 'resolved';
  resolution?: string;
  resolvedDate?: string;
}

@Component({
  selector: 'app-complaint-box',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe, DatePipe],
  templateUrl: './complaint-box.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ComplaintBoxComponent {
  currentUser = input.required<PublicUser | null>();
  myComplaints = input.required<Complaint[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createComplaint = output<{ subject: string; details: string; callback: (complaintId: string) => void }>();

  private fb: FormBuilder = inject(FormBuilder);
  
  activeTab = signal<'submit' | 'history'>('submit');
  state = signal<'form' | 'loading' | 'success'>('form');
  submittedComplaintId = signal<string | null>(null);

  complaintForm = this.fb.group({
    subject: ['', [Validators.required, Validators.minLength(5)]],
    details: ['', [Validators.required, Validators.minLength(20)]],
  });

  goBack() {
    this.navigate.emit();
  }

  selectTab(tab: 'submit' | 'history') {
    this.activeTab.set(tab);
  }

  isInvalid(controlName: string): boolean {
    const control = this.complaintForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onSubmit() {
    if (this.complaintForm.invalid) {
      this.complaintForm.markAllAsTouched();
      return;
    }

    this.state.set('loading');
    const { subject, details } = this.complaintForm.value;

    this.createComplaint.emit({
      subject: subject!,
      details: details!,
      callback: (complaintId) => {
        this.submittedComplaintId.set(complaintId);
        this.state.set('success');
      }
    });
  }
  
  submitAnother() {
    this.state.set('form');
    this.complaintForm.reset();
    this.submittedComplaintId.set(null);
  }
}