import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, signal, computed, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { PendingApplication, Officer } from '../../app.component';

@Component({
  selector: 'app-application-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './application-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ApplicationManagementComponent {
  pendingApplications = input.required<PendingApplication[]>();
  officers = input.required<Officer[]>();
  appLogoUrl = input<string | null>(null);

  @Output() navigate = new EventEmitter<void>();
  @Output() approveApplication = new EventEmitter<{ applicationId: string; officerUsername: string; }>();
  @Output() rejectApplication = new EventEmitter<string>();
  
  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);

  selectedApplicationForDetails = signal<PendingApplication | null>(null);
  selectedApplicationForApproval = signal<PendingApplication | null>(null);
  
  approvalForm = this.fb.group({
    officerUsername: ['', Validators.required]
  });

  filteredApplications = computed(() => 
    this.pendingApplications()
      .filter(a => a.status === 'pending')
      .sort((a, b) => new Date(b.submissionDate).getTime() - new Date(a.submissionDate).getTime())
  );
  
  goBack() {
    this.navigate.emit();
  }

  viewDetails(app: PendingApplication) {
    this.selectedApplicationForDetails.set(app);
  }

  closeDetailsModal() {
    this.selectedApplicationForDetails.set(null);
  }
  
  openApprovalModal(app: PendingApplication) {
    this.selectedApplicationForApproval.set(app);
    this.approvalForm.reset();
  }
  
  closeApprovalModal() {
    this.selectedApplicationForApproval.set(null);
  }

  onReject(appId: string) {
    if (confirm('Are you sure you want to reject this application?')) {
      this.rejectApplication.emit(appId);
    }
  }
  
  submitApproval() {
    if (this.approvalForm.invalid || !this.selectedApplicationForApproval()) {
      return;
    }
    
    const officerUsername = this.approvalForm.value.officerUsername!;
    const applicationId = this.selectedApplicationForApproval()!.id;
    
    this.approveApplication.emit({ applicationId, officerUsername });
    this.closeApprovalModal();
  }
}
