import { Component, ChangeDetectionStrategy, Output, EventEmitter, signal, computed, input } from '@angular/core';

interface SarkariSeva {
  name: string;
  description: string;
  url: string;
  category: 'central' | 'state';
  state?: string;
}

@Component({
  selector: 'app-sarkari-seva',
  standalone: true,
  templateUrl: './sarkari-seva.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SarkariSevaComponent {
  @Output() navigate = new EventEmitter<void>();
  appLogoUrl = input<string | null>(null);

  selectedState = signal<string>('central');

  states = [
    { code: 'central', name: 'Central Government' },
    { code: 'WB', name: 'West Bengal' },
    { code: 'DL', name: 'Delhi' },
    { code: 'MH', name: 'Maharashtra' },
    { code: 'UP', name: 'Uttar Pradesh' },
    // Add more states as needed
  ];

  allServices: SarkariSeva[] = [
    // Central
    { name: 'PM-KISAN', description: 'Financial support for farmers.', url: 'https://pmkisan.gov.in/', category: 'central' },
    { name: 'Ayushman Bharat', description: 'National health protection scheme.', url: 'https://nha.gov.in/ayushman-bharat/', category: 'central' },
    { name: 'DigiLocker', description: 'Secure cloud platform for documents.', url: 'https://www.digilocker.gov.in/', category: 'central' },
    { name: 'MyGov.in', description: 'Citizen engagement platform.', url: 'https://www.mygov.in/', category: 'central' },
    // West Bengal
    { name: 'Swasthya Sathi', description: 'Cashless health care treatment.', url: 'https://swasthyasathi.gov.in/', category: 'state', state: 'WB' },
    { name: 'Kanyashree Prakalpa', description: 'Scheme for empowering girls.', url: 'https://www.wbkanyashree.gov.in/kp_4.0/index.php', category: 'state', state: 'WB' },
    { name: 'Banglarbhumi', description: 'Land records and information.', url: 'https://banglarbhumi.gov.in/', category: 'state', state: 'WB' },
    // Add more services for other states
  ];

  filteredServices = computed(() => {
    const state = this.selectedState();
    if (state === 'central') {
      return this.allServices.filter(s => s.category === 'central');
    }
    return this.allServices.filter(s => s.category === 'state' && s.state === state);
  });

  goBack() {
    this.navigate.emit();
  }

  onStateChange(event: Event) {
    this.selectedState.set((event.target as HTMLSelectElement).value);
  }
  
  visitWebsite(url: string) {
    window.open(url, '_blank');
  }
}
