import { Component, ChangeDetectionStrategy, Output, EventEmitter, input } from '@angular/core';
import { PublicUser } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

interface Service {
  name: string;
  icon: string;
  action: string;
  description: string;
}

@Component({
  selector: 'app-public-panel',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './public-panel.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PublicPanelComponent {
  @Output() navigate = new EventEmitter<string>();
  @Output() logout = new EventEmitter<void>();

  loggedInUser = input.required<PublicUser | null>();
  appLogoUrl = input<string | null>(null);

  services: Service[] = [
    { name: 'Scan & Pay', icon: 'qr_code_scanner', action: 'qr_scanner', description: 'Transfer PSY coins via QR.' },
    { name: 'Health Services', icon: 'health_and_safety', action: 'health', description: 'Access health facilities.' },
    { name: 'My Appointments', icon: 'event_note', action: 'my_appointments', description: 'View your appointments.' },
    { name: 'Subsidy Store', icon: 'storefront', action: 'store', description: 'Buy subsidized products.' },
    { name: 'My Orders', icon: 'receipt_long', action: 'purchase_history', description: 'View your purchase history.' },
    { name: 'My Wallet', icon: 'account_balance_wallet', action: 'wallet', description: 'View balance & transactions.' },
    { name: 'My Profile', icon: 'account_circle', action: 'my_profile', description: 'View and edit your details.' },
    { name: 'Change Password', icon: 'lock_reset', action: 'user_change_password', description: 'Update your login password.' },
    { name: 'My PSY Card', icon: 'credit_card', action: 'psy_card', description: 'View your digital ID card.' },
    { name: 'PSY Benefits', icon: 'redeem', action: 'benefits', description: 'Explore scheme benefits.' },
    { name: 'Education Hub', icon: 'school', action: 'education', description: 'Find educational resources.' },
    { name: 'Complaint Box', icon: 'feedback', action: 'complaint_box', description: 'Report issues and get help.' },
  ];

  onServiceClick(action: string) {
    this.navigate.emit(action);
  }

  onLogout() {
    this.logout.emit();
  }
}