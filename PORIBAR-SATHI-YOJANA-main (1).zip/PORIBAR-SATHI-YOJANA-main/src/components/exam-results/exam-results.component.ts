import { Component, ChangeDetectionStrategy, input, output, signal, computed } from '@angular/core';
import { TranslatePipe } from '../../pipes/translate.pipe';

export interface ExamLink {
  id: string;
  title: string;
  url: string;
  type: 'government' | 'private';
}

@Component({
  selector: 'app-exam-results',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './exam-results.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExamResultsComponent {
  examLinks = input.required<ExamLink[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();

  activeTab = signal<'government' | 'private'>('government');

  filteredLinks = computed(() => {
    return this.examLinks().filter(link => link.type === this.activeTab());
  });

  goBack() {
    this.navigate.emit();
  }

  selectTab(tab: 'government' | 'private') {
    this.activeTab.set(tab);
  }

  visitWebsite(url: string) {
    window.open(url, '_blank');
  }
}
