import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';
import { ExternalService } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-services',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './services.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ServicesComponent {
  services = input.required<ExternalService[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<string>();

  goBack() {
    this.navigate.emit('home');
  }

  visitWebsite(url: string) {
    window.open(url, '_blank');
  }
}
