import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { PublicUser, Officer } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

export interface UserPasswordChangeEvent {
  user: PublicUser | Officer;
  currentPassword: string;
  newPassword: string;
  callback: (success: boolean, error?: string) => void;
}

export function passwordsMatchValidator(control: AbstractControl): ValidationErrors | null {
  const newPassword = control.get('newPassword');
  const confirmPassword = control.get('confirmPassword');
  if (newPassword && confirmPassword && newPassword.value !== confirmPassword.value) {
    return { passwordsMismatch: true };
  }
  return null;
}

@Component({
  selector: 'app-user-change-password',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './user-change-password.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserChangePasswordComponent {
  @Output() navigate = new EventEmitter<string>();
  @Output() passwordChange = new EventEmitter<UserPasswordChangeEvent>();
  currentUser = input.required<(PublicUser | Officer) | null>();
  appLogoUrl = input<string | null>(null);

  private fb: FormBuilder = inject(FormBuilder);

  state = signal<'form' | 'loading' | 'success'>('form');
  errorMessage = signal('');

  passwordForm = this.fb.group({
    currentPassword: ['', [Validators.required]],
    newPassword: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', [Validators.required]],
  }, { validators: passwordsMatchValidator });

  goBack() {
    const user = this.currentUser();
    if (!user) {
      this.navigate.emit('home');
      return;
    }
    const role = 'registeredBy' in user ? 'public' : 'officer';
    this.navigate.emit(role === 'public' ? 'public_panel' : 'officer');
  }

  isInvalid(controlName: string, errorName?: string): boolean {
    const control = this.passwordForm.get(controlName);
    if (errorName) {
      return !!control && control.hasError(errorName) && (control.dirty || control.touched);
    }
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  isFormInvalid(errorName: string): boolean {
    return this.passwordForm.hasError(errorName) && (this.passwordForm.get('confirmPassword')?.dirty || this.passwordForm.get('confirmPassword')?.touched);
  }

  onSubmit() {
    if (this.passwordForm.invalid || !this.currentUser()) {
      this.passwordForm.markAllAsTouched();
      return;
    }

    this.state.set('loading');
    this.errorMessage.set('');

    const formValue = this.passwordForm.value;
    
    this.passwordChange.emit({
      user: this.currentUser()!,
      currentPassword: formValue.currentPassword!,
      newPassword: formValue.newPassword!,
      callback: (success, error) => {
        if (success) {
          this.state.set('success');
          this.passwordForm.reset();
        } else {
          this.state.set('form');
          this.errorMessage.set(error || 'An unknown error occurred.');
        }
      }
    });
  }
}
