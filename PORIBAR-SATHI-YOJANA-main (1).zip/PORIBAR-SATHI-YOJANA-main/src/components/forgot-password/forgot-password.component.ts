import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, input } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { PublicUser, Officer } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

export interface PasswordResetEvent {
  username: string;
  panNumber: string;
  newPassword: string;
  callback: (success: boolean, error?: string) => void;
}

export function passwordsMatchValidator(control: AbstractControl): ValidationErrors | null {
  const newPassword = control.get('newPassword');
  const confirmPassword = control.get('confirmPassword');
  if (newPassword && confirmPassword && newPassword.value !== confirmPassword.value) {
    return { passwordsMismatch: true };
  }
  return null;
}

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './forgot-password.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ForgotPasswordComponent {
  @Output() navigate = new EventEmitter<string>();
  @Output() passwordReset = new EventEmitter<PasswordResetEvent>();
  
  publicUsers = input.required<PublicUser[]>();
  officers = input.required<Officer[]>();
  appLogoUrl = input<string | null>(null);

  private fb: FormBuilder = inject(FormBuilder);

  state = signal<'enterUser' | 'verifyIdentity' | 'resetPassword' | 'success' | 'officerInfo'>('enterUser');
  errorMessage = signal('');
  loading = signal(false);

  usernameForm = this.fb.group({
    username: ['', Validators.required],
  });

  verificationForm = this.fb.group({
    panNumber: ['', [Validators.required, Validators.pattern('^[A-Z]{5}[0-9]{4}[A-Z]{1}$')]],
  });

  resetForm = this.fb.group({
    newPassword: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', Validators.required],
  }, { validators: passwordsMatchValidator });

  goBack(targetView: string) {
    this.navigate.emit(targetView);
  }

  isInvalid(form: 'username' | 'verification' | 'reset', controlName: string, errorName?: string): boolean {
    const formGroup = form === 'username' ? this.usernameForm : (form === 'verification' ? this.verificationForm : this.resetForm);
    const control = formGroup.get(controlName);
    if (errorName) {
      return !!control && control.hasError(errorName) && (control.dirty || control.touched);
    }
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  isFormInvalid(errorName: string): boolean {
    return this.resetForm.hasError(errorName) && (this.resetForm.get('confirmPassword')?.dirty || this.resetForm.get('confirmPassword')?.touched);
  }
  
  toUpperCase(event: Event) {
    const input = event.target as HTMLInputElement;
    const uppercaseValue = input.value.toUpperCase();
    this.verificationForm.get('panNumber')?.setValue(uppercaseValue, { emitEvent: false });
    input.value = uppercaseValue;
  }

  handleUsernameSubmit() {
    if (this.usernameForm.invalid) return;
    this.errorMessage.set('');

    const username = this.usernameForm.value.username!;
    const isOfficer = this.officers().some(o => o.username === username);
    
    if (isOfficer) {
      this.state.set('officerInfo');
    } else {
      this.state.set('verifyIdentity');
    }
  }

  handleVerificationSubmit() {
    if (this.verificationForm.invalid) return;
    this.errorMessage.set('');
    
    // At this point, we only proceed for public users, so no need to re-check officer list.
    const username = this.usernameForm.value.username!;
    const user = this.publicUsers().find(u => u.username === username);

    if (user && user.panNumber.toUpperCase() === this.verificationForm.value.panNumber?.toUpperCase()) {
      this.state.set('resetPassword');
    } else {
      this.errorMessage.set('Username or PAN number is incorrect.');
    }
  }
  
  handleResetSubmit() {
    if (this.resetForm.invalid) return;

    this.loading.set(true);
    this.errorMessage.set('');

    this.passwordReset.emit({
      username: this.usernameForm.value.username!,
      panNumber: this.verificationForm.value.panNumber!,
      newPassword: this.resetForm.value.newPassword!,
      callback: (success, error) => {
        this.loading.set(false);
        if (success) {
          this.state.set('success');
        } else {
          this.errorMessage.set(error || 'An unexpected error occurred.');
          this.state.set('verifyIdentity'); // Go back to verification
        }
      }
    });
  }
}
