import { Component, ChangeDetectionStrategy, input, output, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Scholarship } from '../scholarships/scholarships.component';

@Component({
  selector: 'app-scholarship-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './scholarship-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ScholarshipManagementComponent {
  scholarships = input.required<Scholarship[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createScholarship = output<Omit<Scholarship, 'id'>>();
  deleteScholarship = output<string>();

  private fb: FormBuilder = inject(FormBuilder);

  scholarshipForm = this.fb.group({
    title: ['', [Validators.required, Validators.minLength(5)]],
    description: ['', [Validators.required, Validators.minLength(10)]],
    url: ['', [Validators.required, Validators.pattern('^https?://.+$')]],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.scholarshipForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onAdd() {
    if (this.scholarshipForm.invalid) {
      this.scholarshipForm.markAllAsTouched();
      return;
    }
    this.createScholarship.emit(this.scholarshipForm.value as Omit<Scholarship, 'id'>);
    this.scholarshipForm.reset();
  }

  onDelete(id: string) {
    if (confirm('Are you sure you want to delete this scholarship?')) {
      this.deleteScholarship.emit(id);
    }
  }
}
