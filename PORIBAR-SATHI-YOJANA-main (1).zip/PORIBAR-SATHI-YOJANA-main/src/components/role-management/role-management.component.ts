import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject, signal, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Role, Permission, ALL_PERMISSIONS } from '../../app.component';

@Component({
  selector: 'app-role-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './role-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RoleManagementComponent {
  roles = input.required<Role[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() createRole = new EventEmitter<Omit<Role, 'id'>>();
  @Output() updateRole = new EventEmitter<Role>();
  @Output() deleteRole = new EventEmitter<string>();

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);
  
  editingRole = signal<Role | null>(null);
  allPermissions = ALL_PERMISSIONS;

  roleForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(3)]],
    permissions: this.fb.array(this.allPermissions.map(() => this.fb.control(false)))
  });

  get permissionsFormArray() {
    return this.roleForm.get('permissions') as FormArray;
  }

  goBack() {
    this.navigate.emit();
  }

  formatPermissionName(permission: Permission): string {
    return permission.replace(/_/g, ' ')
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.substring(1).toLowerCase())
      .join(' ');
  }

  isInvalid(controlName: string): boolean {
    const control = this.roleForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onEdit(role: Role) {
    this.editingRole.set(role);
    this.roleForm.get('name')?.setValue(role.name);

    const permissionValues = this.allPermissions.map(p => role.permissions.includes(p));
    this.permissionsFormArray.setValue(permissionValues);
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  onCancelEdit() {
    this.editingRole.set(null);
    this.roleForm.reset();
  }

  onDelete(id: string) {
    if (confirm('Are you sure you want to delete this role?')) {
      this.deleteRole.emit(id);
    }
  }

  onSubmit() {
    if (this.roleForm.invalid) {
      this.roleForm.markAllAsTouched();
      return;
    }

    const formValue = this.roleForm.getRawValue();
    const selectedPermissions = this.allPermissions.filter((_, i) => formValue.permissions[i]);
    
    const roleData = {
      name: formValue.name!,
      permissions: selectedPermissions,
    };

    if (this.editingRole()) {
      this.updateRole.emit({ ...this.editingRole()!, ...roleData });
    } else {
      this.createRole.emit(roleData);
    }
    
    this.onCancelEdit();
  }
}