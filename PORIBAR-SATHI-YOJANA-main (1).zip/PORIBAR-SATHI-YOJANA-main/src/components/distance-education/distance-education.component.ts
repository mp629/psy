import { Component, ChangeDetectionStrategy, input, output, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { PublicUser } from '../../app.component';

@Component({
  selector: 'app-distance-education',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './distance-education.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DistanceEducationComponent {
  currentUser = input.required<PublicUser | null>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createEducationLead = output<{ type: 'Distance Education'; details: string }>();

  private fb: FormBuilder = inject(FormBuilder);
  
  state = signal<'form' | 'success'>('form');

  interestForm = this.fb.group({
    courseLevel: ['', Validators.required],
  });

  courseLevels = [
    'Class X',
    'Class XII',
    'Graduate (BA, BSc, BCom)',
    'Post Graduate (MA, MSc, MCom)',
    'PhD'
  ];

  goBack() {
    this.navigate.emit();
  }

  onSubmit() {
    if (this.interestForm.invalid) {
      return;
    }
    const details = `Course Level: ${this.interestForm.value.courseLevel}`;
    this.createEducationLead.emit({ type: 'Distance Education', details });
    this.state.set('success');
  }

  submitAnother() {
    this.state.set('form');
    this.interestForm.reset();
  }
}
