import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TopUpRequest } from '../../app.component';

@Component({
  selector: 'app-top-up',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './top-up.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TopUpComponent {
  qrCodeUrl = input<string | null>(null);
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() topUpRequest = new EventEmitter<Omit<TopUpRequest, 'id' | 'status' | 'requestDate' | 'userType' | 'userId' | 'fullName' | 'username'>>();

  state = signal<'form' | 'loading' | 'success'>('form');

  paymentMethods = ['Google Pay', 'PhonePe', 'Paytm', 'BHIM', 'Other UPI'];

  // Form fields as signals
  amount = signal<number | null>(null);
  paymentMethod = signal<string>(this.paymentMethods[0]);
  transactionId = signal<string>('');


  goBack() {
    this.navigate.emit();
  }

  onSubmit() {
    // Validation is now primarily handled by the template
    this.state.set('loading');
    
    const requestData = {
      amount: this.amount()!,
      paymentMethod: this.paymentMethod(),
      transactionId: this.transactionId(),
    };

    setTimeout(() => {
        this.topUpRequest.emit(requestData);
        this.state.set('success');
    }, 1500);
  }

  startNewRequest() {
    this.state.set('form');
    this.amount.set(null);
    this.paymentMethod.set(this.paymentMethods[0]);
    this.transactionId.set('');
  }
}
