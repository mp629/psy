import { Component, ChangeDetectionStrategy, output, input, signal, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { GeminiService } from '../../services/gemini.service';
import { TranslatePipe } from '../../pipes/translate.pipe';

interface SymptomResult {
  disclaimer: string;
  possibleCauses: string[];
  nextSteps: string[];
}

@Component({
  selector: 'app-ai-symptom-checker',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './ai-symptom-checker.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AiSymptomCheckerComponent {
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();

  private fb: FormBuilder = inject(FormBuilder);
  private geminiService = inject(GeminiService);

  state = signal<'form' | 'loading' | 'result'>('form');
  error = signal<string | null>(null);
  result = signal<SymptomResult | null>(null);

  symptomForm = this.fb.group({
    symptoms: ['', [Validators.required, Validators.minLength(10)]],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.symptomForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  startNewSearch() {
    this.state.set('form');
    this.result.set(null);
    this.error.set(null);
    this.symptomForm.reset();
  }

  async checkSymptoms() {
    if (this.symptomForm.invalid) {
      this.symptomForm.markAllAsTouched();
      return;
    }

    this.state.set('loading');
    this.error.set(null);
    const symptoms = this.symptomForm.value.symptoms;

    const prompt = `
      A user describes their symptoms as: "${symptoms}".
      Based on this, provide general health information.
      
      Respond ONLY with a valid JSON object with three keys: "disclaimer", "possibleCauses", and "nextSteps".
      - "disclaimer": A strong, clear warning that this is not a medical diagnosis and they must see a doctor.
      - "possibleCauses": An array of strings with general, non-specific potential causes. Do not provide a diagnosis.
      - "nextSteps": An array of strings suggesting sensible actions, like resting, staying hydrated, and consulting a doctor.

      Example response format:
      {
        "disclaimer": "This is AI-generated information and not a medical diagnosis. Consult a qualified healthcare professional for any health concerns.",
        "possibleCauses": ["Viral infection", "Dehydration", "Lack of sleep"],
        "nextSteps": ["Rest and get adequate sleep.", "Stay hydrated by drinking plenty of water.", "Consult a doctor for a proper diagnosis and treatment."]
      }
    `;

    try {
      const response = await this.geminiService.generateThoughtfulResponse(prompt);
      const responseText = response.text.replace(/```json/g, '').replace(/```/g, '').trim();
      
      try {
        const parsedResult: SymptomResult = JSON.parse(responseText);
        if (parsedResult.disclaimer && parsedResult.possibleCauses && parsedResult.nextSteps) {
            this.result.set(parsedResult);
            this.state.set('result');
        } else {
            throw new Error("AI response did not match the expected format.");
        }
      } catch (parseError) {
        console.error("Failed to parse AI response for symptom checker:", parseError);
        console.error("Raw AI response:", responseText);
        this.error.set("The AI returned an invalid response. Please try again.");
        this.state.set('form');
      }

    } catch (e) {
      console.error("AI Symptom Checker Error:", e);
      this.error.set("An error occurred while contacting the AI. Please try again later.");
      this.state.set('form');
    }
  }
}
