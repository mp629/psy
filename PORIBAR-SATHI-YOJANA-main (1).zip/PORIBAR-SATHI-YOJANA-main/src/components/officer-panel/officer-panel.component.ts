import { Component, ChangeDetectionStrategy, Output, EventEmitter, input, computed } from '@angular/core';
// FIX: Import OfficerLevel from its source file to resolve module resolution error.
import { Officer, PublicUser, LoggedInOfficial } from '../../app.component';
import { OfficerLevel } from '../level-management/level-management.component';

interface Kpi {
  title: string;
  value: string;
  icon: string;
  color: string;
}

interface OfficerAction {
  title: string;
  description: string;
  icon: string;
  action: string;
  requiredPermission: string;
}

@Component({
  selector: 'app-officer-panel',
  standalone: true,
  templateUrl: './officer-panel.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OfficerPanelComponent {
  @Output() navigate = new EventEmitter<string>();
  @Output() logout = new EventEmitter<void>();
  
  currentOfficer = input.required<Officer | null>();
  allOfficers = input.required<Officer[]>();
  officerLevels = input.required<OfficerLevel[]>();
  loggedInOfficial = input.required<LoggedInOfficial | null>();
  registrations = input.required<PublicUser[]>();
  appLogoUrl = input<string | null>(null);

  mySubordinates = computed(() => {
    const officer = this.currentOfficer();
    if (!officer) return [];
    return this.allOfficers().filter(o => o.reportsTo === officer.id);
  });

  kpis = computed<Kpi[]>(() => {
    const officer = this.currentOfficer();
    if (!officer) return [];
    
    const myRegistrationsCount = this.registrations().filter(
      r => r.registeredBy === officer.username
    ).length;

    const today = new Date().toISOString().split('T')[0];
    const todayIncome = officer.wallets.incentive.transactions
      .filter(tx => tx.date === today && tx.type === 'credit')
      .reduce((sum, tx) => sum + tx.amount, 0);

    return [
      { title: 'My Registrations', value: myRegistrationsCount.toString(), icon: 'groups', color: 'text-green-500' },
      { title: 'My Team', value: this.mySubordinates().length.toString(), icon: 'supervised_user_circle', color: 'text-blue-500' },
      { title: `Today's Income`, value: `₹${todayIncome.toLocaleString('en-IN')}`, icon: 'account_balance_wallet', color: 'text-green-600' },
      { title: 'Applications Submitted', value: '5', icon: 'assignment', color: 'text-amber-500' },
    ];
  });

  actions: OfficerAction[] = [
    { title: 'My Team Details', description: 'View your subordinate officers.', icon: 'groups', action: 'my_team', requiredPermission: 'is_officer' },
    { title: 'Daily Reports', description: 'Submit and view your daily activity reports.', icon: 'summarize', action: 'daily_reports', requiredPermission: 'submit_daily_reports' },
    { title: 'Public Registration', description: 'Register a new individual under the PSY scheme.', icon: 'person_add', action: 'public_registration', requiredPermission: 'register_public_user' },
    { title: 'View My Registrations', description: 'See a list of individuals you have registered.', icon: 'list_alt', action: 'view_registrations', requiredPermission: 'view_own_registrations' },
    { title: 'My Wallet & Income', description: 'Check your earnings and transaction history.', icon: 'wallet', action: 'wallet', requiredPermission: 'is_officer' },
    { title: 'My Profile', description: 'Update your personal and bank details.', icon: 'manage_accounts', action: 'my_profile', requiredPermission: 'is_officer' },
    { title: 'Change Password', description: 'Update your login password.', icon: 'lock_reset', action: 'user_change_password', requiredPermission: 'is_officer' },
    { title: 'My ID Card', description: 'View and present your official ID card.', icon: 'badge', action: 'officer_id_card', requiredPermission: 'is_officer' },
  ];
  
  hasPermission(permission: string): boolean {
      return this.loggedInOfficial()?.role.permissions.includes(permission as any) ?? false;
  }

  goBack() {
    this.navigate.emit('home');
  }
  
  onLogout() {
    this.logout.emit();
  }

  onOfficerActionClick(action: string) {
    this.navigate.emit(action);
  }
}