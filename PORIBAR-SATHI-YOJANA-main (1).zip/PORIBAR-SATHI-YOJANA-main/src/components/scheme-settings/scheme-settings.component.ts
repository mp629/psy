import { Component, ChangeDetectionStrategy, input, output, inject, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { LanguageService } from '../../services/language.service';

@Component({
  selector: 'app-scheme-settings',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './scheme-settings.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SchemeSettingsComponent {
  currentRates = input.required<{ subsidyRate: number, pfRate: number }>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  ratesUpdate = output<{ subsidyRate: number, pfRate: number }>();

  private fb: FormBuilder = inject(FormBuilder);
  languageService = inject(LanguageService);

  settingsForm = this.fb.group({
    subsidyRate: [20, [Validators.required, Validators.min(0), Validators.max(100)]],
    pfRate: [5, [Validators.required, Validators.min(0), Validators.max(100)]],
  });

  constructor() {
    effect(() => {
        this.settingsForm.patchValue({ 
            subsidyRate: this.currentRates().subsidyRate,
            pfRate: this.currentRates().pfRate 
        });
    });
  }

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.settingsForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onSubmit() {
    if (this.settingsForm.invalid) {
      this.settingsForm.markAllAsTouched();
      return;
    }
    const newRates = {
        subsidyRate: this.settingsForm.value.subsidyRate!,
        pfRate: this.settingsForm.value.pfRate!
    };
    this.ratesUpdate.emit(newRates);
    alert(this.languageService.translate('schemeSettings.success'));
    this.settingsForm.markAsPristine();
  }
}