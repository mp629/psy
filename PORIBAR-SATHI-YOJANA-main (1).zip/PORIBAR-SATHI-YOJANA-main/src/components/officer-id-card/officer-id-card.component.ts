import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, computed, ViewChild, ElementRef } from '@angular/core';
import { Officer } from '../../app.component';
import { OfficerLevel } from '../level-management/level-management.component';
import { DatePipe } from '@angular/common';

declare var html2canvas: any;

@Component({
  selector: 'app-officer-id-card',
  standalone: true,
  templateUrl: './officer-id-card.component.html',
  imports: [DatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OfficerIdCardComponent {
  officer = input.required<Officer | null>();
  officerLevels = input.required<OfficerLevel[]>();
  idCardLogoUrl = input<string | null>(null);
  appLogoUrl = input<string | null>(null);
  authorizedSignatureUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  
  @ViewChild('officerCard') officerCardElement!: ElementRef;

  fullName = computed(() => {
    // A simple way to capitalize and format the username if no full name is available
    const username = this.officer()?.username || '';
    return username.replace('.', ' ').replace(/\b\w/g, char => char.toUpperCase());
  });

  officerTitle = computed(() => {
    const officer = this.officer();
    if (!officer) return 'Officer';
    return this.officerLevels().find(l => l.level === officer.level)?.title || `Level ${officer.level} Officer`;
  });

  issueDate = computed(() => new Date().toISOString().split('T')[0]);

  qrCodeUrl = computed(() => {
    const officerData = this.officer();
    if (!officerData) return '';
    const dataToEncode = JSON.stringify({
      id: officerData.id,
      username: officerData.username,
      type: 'officer'
    });
    return `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(dataToEncode)}`;
  });

  goBack() {
    this.navigate.emit();
  }

  onDownloadCard() {
    if (typeof html2canvas === 'undefined') {
      alert('Download functionality is currently unavailable. Please try again later.');
      console.error('html2canvas is not loaded.');
      return;
    }

    html2canvas(this.officerCardElement.nativeElement, {
        scale: 3,
        useCORS: true,
        backgroundColor: null
    }).then((canvas: HTMLCanvasElement) => {
      const link = document.createElement('a');
      link.download = `officer-id-card-${this.officer()?.id}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    });
  }
}