import { Component, ChangeDetectionStrategy, Output, EventEmitter, input } from '@angular/core';
import { TranslatePipe } from '../../pipes/translate.pipe';

interface Benefit {
  title: string;
  description: string;
  icon: string;
}

@Component({
  selector: 'app-psy-benefits',
  standalone: true,
  templateUrl: './psy-benefits.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [TranslatePipe]
})
export class PsyBenefitsComponent {
  @Output() navigate = new EventEmitter<void>();
  appLogoUrl = input<string | null>(null);

  benefits: Benefit[] = [
    {
      title: 'benefits.benefit1.title',
      description: 'benefits.benefit1.desc',
      icon: 'shield'
    },
    {
      title: 'benefits.benefit2.title',
      description: 'benefits.benefit2.desc',
      icon: 'medication'
    },
    {
      title: 'benefits.benefit3.title',
      description: 'benefits.benefit3.desc',
      icon: 'school'
    },
    {
      title: 'benefits.benefit4.title',
      description: 'benefits.benefit4.desc',
      icon: 'work'
    },
    {
      title: 'benefits.benefit5.title',
      description: 'benefits.benefit5.desc',
      icon: 'shopping_cart'
    },
    {
      title: 'benefits.benefit6.title',
      description: 'benefits.benefit6.desc',
      icon: 'savings'
    }
  ];

  goBack() {
    this.navigate.emit();
  }
}
