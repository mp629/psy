import { Component, ChangeDetectionStrategy, Output, EventEmitter, input } from '@angular/core';
import { TranslatePipe } from '../../pipes/translate.pipe';

interface EducationService {
  title: string;
  description: string;
  icon: string;
  action: string;
}

@Component({
  selector: 'app-education',
  standalone: true,
  templateUrl: './education.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [TranslatePipe]
})
export class EducationComponent {
  @Output() navigate = new EventEmitter<string>();
  appLogoUrl = input<string | null>(null);

  services: EducationService[] = [
    {
      title: 'education.service.findSchools',
      description: 'education.service.findSchools.desc',
      icon: 'school',
      action: 'find_schools'
    },
    {
      title: 'education.service.scholarships',
      description: 'education.service.scholarships.desc',
      icon: 'monetization_on',
      action: 'scholarships'
    },
    {
      title: 'education.service.onlineCourses',
      description: 'education.service.onlineCourses.desc',
      icon: 'cast_for_education',
      action: 'online_courses'
    },
    {
      title: 'education.service.distanceEducation',
      description: 'education.service.distanceEducation.desc',
      icon: 'school',
      action: 'distance_education'
    },
    {
      title: 'education.service.skillDevelopment',
      description: 'education.service.skillDevelopment.desc',
      icon: 'construction',
      action: 'skill_development'
    },
    {
      title: 'education.service.examResults',
      description: 'education.service.examResults.desc',
      icon: 'grading',
      action: 'exam_results'
    },
    {
      title: 'education.service.careerCounseling',
      description: 'education.service.careerCounseling.desc',
      icon: 'work',
      action: 'career_counseling'
    }
  ];

  goBack() {
    this.navigate.emit('public_panel');
  }

  onServiceClick(action: string) {
    this.navigate.emit(action);
  }
}
