import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';
import { TranslatePipe } from '../../pipes/translate.pipe';

export interface PopupMessage {
  enabled: boolean;
  title: string;
  message: string;
  imageUrl: string | null;
  link: string | null;
}

@Component({
  selector: 'app-popup-message',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './popup-message.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PopupMessageComponent {
  messageData = input<PopupMessage | null>(null);
  closePopup = output<void>();

  onClose() {
    this.closePopup.emit();
  }

  onLinkClick() {
    const data = this.messageData();
    if (data && data.link) {
      window.open(data.link, '_blank');
      this.onClose();
    }
  }
}
