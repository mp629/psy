import { Component, ChangeDetectionStrategy, input, output, signal, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Doctor } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-doctor-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './doctor-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DoctorManagementComponent {
  doctors = input.required<Doctor[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createDoctor = output<Omit<Doctor, 'id'>>();
  updateDoctor = output<Doctor>();
  deleteDoctor = output<string>();

  private fb: FormBuilder = inject(FormBuilder);
  
  editingDoctor = signal<Doctor | null>(null);
  imagePreview = signal<string | null>(null);

  doctorForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(3)]],
    specialization: ['', [Validators.required]],
    qualifications: ['', [Validators.required]],
    experience: [null as number | null, [Validators.required, Validators.min(0)]],
    consultationFee: [null as number | null, [Validators.required, Validators.min(0)]],
    profilePicture: [null as string | null],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.doctorForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }
  
  async onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      try {
        const compressedDataUrl = await this.compressImage(file, 800, 800, 0.92);
        this.imagePreview.set(compressedDataUrl);
        this.doctorForm.patchValue({ profilePicture: compressedDataUrl });
      } catch (error) {
        console.error('Image compression failed:', error);
        // Fallback
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          this.imagePreview.set(result);
          this.doctorForm.patchValue({ profilePicture: result });
        };
        reader.readAsDataURL(file);
      }
    }
  }

  private async compressImage(file: File, maxWidth: number, maxHeight: number, quality: number): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxWidth) {
                        height = Math.round(height * (maxWidth / width));
                        width = maxWidth;
                    }
                } else {
                    if (height > maxHeight) {
                        width = Math.round(width * (maxHeight / height));
                        height = maxHeight;
                    }
                }
                
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    return reject(new Error('Could not get canvas context'));
                }
                
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.onerror = (error) => reject(error);
        };
        reader.onerror = (error) => reject(error);
    });
  }

  onEdit(doctor: Doctor) {
    this.editingDoctor.set(doctor);
    this.doctorForm.patchValue(doctor);
    this.imagePreview.set(doctor.profilePicture || null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  onCancelEdit() {
    this.editingDoctor.set(null);
    this.doctorForm.reset();
    this.imagePreview.set(null);
  }

  onDelete(id: string) {
    if (confirm('Are you sure you want to delete this doctor?')) {
      this.deleteDoctor.emit(id);
    }
  }

  onSubmit() {
    if (this.doctorForm.invalid) {
      this.doctorForm.markAllAsTouched();
      return;
    }

    const formValue = this.doctorForm.getRawValue();

    if (this.editingDoctor()) {
      const updatedDoctor: Doctor = {
        ...this.editingDoctor()!,
        ...formValue,
      };
      this.updateDoctor.emit(updatedDoctor);
    } else {
      this.createDoctor.emit(formValue as Omit<Doctor, 'id'>);
    }
    this.onCancelEdit();
  }
}