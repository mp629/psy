import { Component, ChangeDetectionStrategy, Output, EventEmitter, input, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

export interface Banner {
  id: number;
  title: string;
  description: string;
  colorClass: string;
}

@Component({
  selector: 'app-banner-management',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './banner-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BannerManagementComponent {
  @Output() navigate = new EventEmitter<void>();
  @Output() createBanner = new EventEmitter<Omit<Banner, 'id'>>();
  @Output() deleteBanner = new EventEmitter<number>();

  banners = input.required<Banner[]>();
  appLogoUrl = input<string | null>(null);
  
  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);
  
  colors = [
    { name: 'Green', class: 'bg-green-600' },
    { name: 'Teal', class: 'bg-teal-500' },
    { name: 'Emerald', class: 'bg-emerald-600' },
    { name: 'Light Green', class: 'bg-green-400' },
    { name: 'Lime', class: 'bg-lime-500' },
    { name: 'Dark Green', class: 'bg-green-800' },
  ];

  bannerForm = this.fb.group({
    title: ['', [Validators.required, Validators.minLength(5)]],
    description: ['', [Validators.required, Validators.minLength(10)]],
    colorClass: [this.colors[0].class, [Validators.required]],
  });

  goBack() {
    this.navigate.emit();
  }
  
  isInvalid(controlName: string): boolean {
    const control = this.bannerForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onAddBanner() {
    if (this.bannerForm.invalid) {
      this.bannerForm.markAllAsTouched();
      return;
    }
    this.createBanner.emit(this.bannerForm.value as Omit<Banner, 'id'>);
    this.bannerForm.reset({ colorClass: this.colors[0].class });
  }

  onDeleteBanner(id: number) {
    if (confirm('Are you sure you want to delete this banner?')) {
      this.deleteBanner.emit(id);
    }
  }
}