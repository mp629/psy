import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';

export interface Scholarship {
  id: string;
  title: string;
  description: string;
  url: string;
}

@Component({
  selector: 'app-scholarships',
  standalone: true,
  templateUrl: './scholarships.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ScholarshipsComponent {
  scholarships = input.required<Scholarship[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();

  goBack() {
    this.navigate.emit();
  }

  visitWebsite(url: string) {
    window.open(url, '_blank');
  }
}
