import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, computed, signal, ViewChild, ElementRef } from '@angular/core';
import { PublicUser } from '../../app.component';

declare var html2canvas: any;

@Component({
  selector: 'app-psy-card',
  standalone: true,
  templateUrl: './psy-card.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PsyCardComponent {
  user = input.required<PublicUser | null>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();
  @Output() orderPhysicalCard = new EventEmitter<void>();

  @ViewChild('psyCard') psyCardElement!: ElementRef;

  orderStatus = signal<'idle' | 'ordered'>('idle');

  issueDate = computed(() => new Date().toISOString().split('T')[0].split('-').reverse().join('/'));

  formattedId = computed(() => {
    const id = this.user()?.id;
    if (!id) return '';
    const parts = id.split('-');
    // Assuming format PSY-ST-NNNNNNNN
    if (parts.length === 3 && parts[2].length === 8) {
      const numberPart = parts[2];
      return `${parts[0]}-${parts[1]}-${numberPart.substring(0, 4)} ${numberPart.substring(4)}`;
    }
    return id; // Fallback for any other format
  });

  canAffordPhysicalCard = computed(() => {
    return (this.user()?.wallets.main.balance ?? 0) >= 100;
  });

  qrCodeUrl = computed(() => {
    const userData = this.user();
    if (!userData) return '';
    const dataToEncode = JSON.stringify({
      id: userData.id,
      username: userData.username,
      type: 'public'
    });
    return `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(dataToEncode)}`;
  });

  goBack() {
    this.navigate.emit();
  }

  onDownloadCard() {
    if (typeof html2canvas === 'undefined') {
      alert('Download functionality is currently unavailable. Please try again later.');
      console.error('html2canvas is not loaded.');
      return;
    }

    const cardElement = this.psyCardElement.nativeElement;
    
    // Temporarily remove overflow-hidden to capture decorative elements
    const hadOverflowHidden = cardElement.classList.contains('overflow-hidden');
    if (hadOverflowHidden) {
        cardElement.classList.remove('overflow-hidden');
    }

    html2canvas(cardElement, {
        scale: 3,
        useCORS: true,
        backgroundColor: null 
    }).then((canvas: HTMLCanvasElement) => {
      const link = document.createElement('a');
      link.download = `psy-card-${this.user()?.id}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    }).finally(() => {
        // Restore the class after capture is complete
        if (hadOverflowHidden) {
            cardElement.classList.add('overflow-hidden');
        }
    });
  }

  onOrderCard() {
    if (this.canAffordPhysicalCard()) {
      if(confirm('Are you sure you want to order a physical card for ₹100? This amount will be deducted from your Main Wallet.')) {
        this.orderPhysicalCard.emit();
        this.orderStatus.set('ordered');
      }
    }
  }
}