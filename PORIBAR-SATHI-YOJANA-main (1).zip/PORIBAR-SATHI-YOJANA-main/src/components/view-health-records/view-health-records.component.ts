import { Component, ChangeDetectionStrategy, input, output, signal } from '@angular/core';
import { HealthRecord } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-view-health-records',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './view-health-records.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ViewHealthRecordsComponent {
  healthRecords = input.required<HealthRecord[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();

  selectedRecord = signal<HealthRecord | null>(null);

  goBack() {
    this.navigate.emit();
  }

  viewDetails(record: HealthRecord) {
    this.selectedRecord.set(record);
  }

  closeDetails() {
    this.selectedRecord.set(null);
  }
}
