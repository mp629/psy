import { Component, ChangeDetectionStrategy, input, output, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TranslatePipe } from '../../pipes/translate.pipe';

export interface Advertisement {
  id: string;
  imageUrl: string;
  linkUrl: string;
}

@Component({
  selector: 'app-advertisement-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './advertisement-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdvertisementManagementComponent {
  advertisements = input.required<Advertisement[]>();
  appLogoUrl = input<string | null>(null);
  
  navigate = output<void>();
  createAd = output<Omit<Advertisement, 'id'>>();
  deleteAd = output<string>();

  private fb: FormBuilder = inject(FormBuilder);

  adForm = this.fb.group({
    imageUrl: ['', [Validators.required, Validators.pattern('^https?://.+$')]],
    linkUrl: ['', [Validators.required, Validators.pattern('^https?://.+$')]],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.adForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onAdd() {
    if (this.adForm.invalid) {
      this.adForm.markAllAsTouched();
      return;
    }
    this.createAd.emit(this.adForm.value as Omit<Advertisement, 'id'>);
    this.adForm.reset();
  }

  onDelete(id: string) {
    this.deleteAd.emit(id);
  }
}