import { Component, ChangeDetectionStrategy, input, output, ViewChild, ElementRef } from '@angular/core';
import { TranslatePipe } from '../../pipes/translate.pipe';
import { PublicUser } from '../../app.component';
import { UserSkillEnrollment } from '../skill-development/skill-development.component';
import { SkillProgram } from '../skill-program-management/skill-program-management.component';

declare var html2canvas: any;

@Component({
  selector: 'app-view-certificate',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './view-certificate.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ViewCertificateComponent {
  user = input.required<PublicUser | null>();
  enrollment = input.required<UserSkillEnrollment | null>();
  program = input.required<SkillProgram | null>();
  navigate = output<void>();
  
  @ViewChild('certificate') certificateElement!: ElementRef;

  goBack() {
    this.navigate.emit();
  }

  onDownload() {
    if (typeof html2canvas === 'undefined') {
      alert('Download functionality is not available.');
      return;
    }
    html2canvas(this.certificateElement.nativeElement, { scale: 2 }).then((canvas: HTMLCanvasElement) => {
      const link = document.createElement('a');
      link.download = `PSY_Certificate_${this.user()?.fullName}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    });
  }
}
