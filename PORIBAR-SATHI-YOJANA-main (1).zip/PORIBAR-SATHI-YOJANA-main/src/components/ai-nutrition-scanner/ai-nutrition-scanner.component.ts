import { Component, ChangeDetectionStrategy, Output, EventEmitter, signal, input, ViewChild, ElementRef, OnDestroy, effect, inject } from '@angular/core';
import { GeminiService, NutritionInfo } from '../../services/gemini.service';

@Component({
  selector: 'app-ai-nutrition-scanner',
  standalone: true,
  templateUrl: './ai-nutrition-scanner.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AiNutritionScannerComponent implements OnDestroy {
  @Output() navigate = new EventEmitter<void>();
  appLogoUrl = input<string | null>(null);

  @ViewChild('videoElement') videoElement!: ElementRef<HTMLVideoElement>;

  state = signal<'idle' | 'camera' | 'loading' | 'result'>('idle');
  error = signal<string | null>(null);
  stream = signal<MediaStream | null>(null);
  capturedImage = signal<string | null>(null);
  nutritionInfo = signal<NutritionInfo | null>(null);
  cameraReady = signal(false);

  private geminiService = inject(GeminiService);

  constructor() {
    effect((onCleanup) => {
      if (this.state() === 'camera') {
        // Use a microtask to ensure the video element is available in the DOM after the state change
        Promise.resolve().then(() => this.startCameraStream());
      }
      onCleanup(() => {
        this.stopCamera();
      });
    });
  }

  ngOnDestroy() {
    this.stopCamera();
  }

  goBack() {
    this.stopCamera();
    this.navigate.emit();
  }
  
  resetScanner() {
    this.stopCamera();
    this.state.set('idle');
    this.error.set(null);
    this.capturedImage.set(null);
    this.nutritionInfo.set(null);
    this.cameraReady.set(false);
  }

  startCamera() {
    this.error.set(null); // Clear previous errors
    this.state.set('camera');
  }

  private async startCameraStream() {
    try {
      if (!this.videoElement) {
        console.warn('startCameraStream called before videoElement is ready.');
        return;
      }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API is not supported by your browser.');
      }
      
      let stream: MediaStream;
      const environmentConstraint = { video: { facingMode: 'environment' } };
      const anyCameraConstraint = { video: true };

      try {
        // Prefer the rear camera
        stream = await navigator.mediaDevices.getUserMedia(environmentConstraint);
      } catch (err) {
        console.warn('Could not get environment camera, trying any camera...', err);
        // If rear camera fails (e.g., on a laptop), try any camera
        stream = await navigator.mediaDevices.getUserMedia(anyCameraConstraint);
      }

      this.stream.set(stream);
      
      const video = this.videoElement.nativeElement;
      video.srcObject = stream;
      video.onloadeddata = () => {
        this.cameraReady.set(true);
      };
      await video.play();

    } catch (err) {
      console.error("Camera access error:", err);
      let errorMessage = "Could not access the camera. Please ensure you have granted permission.";

      if (err && typeof err === 'object' && 'name' in err) {
        const errorName = (err as Error).name;
        if (errorName === 'NotFoundError' || errorName === 'DevicesNotFoundError') {
            errorMessage = "No camera was found on your device. This can happen if your device has no camera, or if it is disabled in your system settings.";
        } else if (errorName === 'NotAllowedError' || errorName === 'PermissionDeniedError') {
            errorMessage = "Camera access was denied. To use this feature, please grant permission in your browser or system settings.";
        } else if (errorName === 'NotReadableError' || errorName === 'TrackStartError') {
            errorMessage = "The camera is currently in use by another application or a hardware error occurred. Please close other apps using the camera and try again.";
        } else if (errorName === 'OverconstrainedError' || errorName === 'ConstraintNotSatisfiedError') {
            errorMessage = "The camera on your device does not support the required settings.";
        }
      }
      this.error.set(errorMessage);
      this.state.set('idle');
    }
  }

  stopCamera() {
    this.stream()?.getTracks().forEach(track => track.stop());
    this.stream.set(null);
    this.cameraReady.set(false);
  }

  captureImage() {
    try {
      if (!this.videoElement || !this.cameraReady()) {
        console.warn("Capture button clicked before camera was ready.");
        this.error.set("Failed to capture image. Camera may not be fully initialized.");
        return;
      }
      const video = this.videoElement.nativeElement;
      if (video.videoWidth === 0 || video.videoHeight === 0) {
          this.error.set("Failed to capture image. Camera may not be fully initialized.");
          this.state.set('result'); // Show the error on the result screen
          return;
      }

      const canvas = document.createElement('canvas');
      
      // --- Image Resizing and Compression Logic ---
      const maxWidth = 800;
      const maxHeight = 800;
      const quality = 0.9;

      let width = video.videoWidth;
      let height = video.videoHeight;

      // Calculate new dimensions to maintain aspect ratio
      if (width > height) {
          if (width > maxWidth) {
              height = Math.round(height * (maxWidth / width));
              width = maxWidth;
          }
      } else {
          if (height > maxHeight) {
              width = Math.round(width * (maxHeight / height));
              height = maxHeight;
          }
      }

      canvas.width = width;
      canvas.height = height;
      
      const context = canvas.getContext('2d');
      if (!context) {
          this.error.set("Failed to create image context for capture.");
          this.state.set('result');
          return;
      }
      // Draw the resized image onto the canvas
      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      // Get the compressed data URL from the resized canvas
      const dataUrl = canvas.toDataURL('image/jpeg', quality);
      if (!dataUrl || dataUrl.length < 100) { // Simple validation for empty data URL
        throw new Error("Captured image data is invalid or empty.");
      }
      this.capturedImage.set(dataUrl);
      this.stopCamera();
      this.state.set('loading');
      this.getNutritionInfo(dataUrl);
    } catch (e) {
      console.error("Image capture failed:", e);
      const message = e instanceof Error ? e.message : "An unknown error occurred during capture.";
      this.error.set(message);
      this.state.set('result');
    }
  }

  async getNutritionInfo(base64ImageDataUrl: string) {
    this.error.set(null);
    const base64Data = base64ImageDataUrl.split(',')[1];
    
    try {
      const parsedResponse = await this.geminiService.analyzeFoodImage(base64Data);

      if (parsedResponse.error) {
          throw new Error(`Could not identify the food item. The AI said: ${parsedResponse.error}`);
      }

      if (parsedResponse.foodName && parsedResponse.nutrients) {
        this.nutritionInfo.set(parsedResponse);
      } else {
        throw new Error("AI response did not match the expected format.");
      }
    } catch (e) {
      console.error("AI Nutrition Scanner Error:", e);
      const message = e instanceof Error ? e.message : "An unknown error occurred.";
      this.error.set(`Failed to analyze image. ${message}`);
      this.nutritionInfo.set(null);
    } finally {
        this.state.set('result');
    }
  }
}