import { Component, ChangeDetectionStrategy, input, Output, EventEmitter, inject, computed, signal } from '@angular/core';
import { Officer, Transaction } from '../../app.component';
import { OfficerLevel } from '../level-management/level-management.component';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

interface ReportData {
    officer: Officer;
    total: number;
    transactions: Transaction[];
}

@Component({
  selector: 'app-incentive-report',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './incentive-report.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class IncentiveReportComponent {
  officers = input.required<Officer[]>();
  officerLevels = input.required<OfficerLevel[]>();
  appLogoUrl = input<string | null>(null);
  @Output() navigate = new EventEmitter<void>();

  // FIX: Explicitly type FormBuilder to prevent type inference issues with inject().
  private fb: FormBuilder = inject(FormBuilder);
  
  // Set default start date to one month ago
  private oneMonthAgo = new Date();
  
  reportForm = this.fb.group({
    startDate: [this.oneMonthAgo.toISOString().split('T')[0], Validators.required],
    endDate: [new Date().toISOString().split('T')[0], Validators.required],
  });
  
  // Signal to hold the dates when the user clicks 'generate'
  private dateRange = signal<{startDate: string, endDate: string} | null>(null);

  reportData = computed(() => {
    const range = this.dateRange();
    if (!range) return null;
    const { startDate, endDate } = range;

    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999); // Include the whole end day

    const officerIncentives = new Map<string, ReportData>();

    this.officers().forEach(officer => {
      const incentiveTxs = officer.wallets.incentive.transactions
        .filter(tx => {
          const txDate = new Date(tx.date);
          return txDate >= start && txDate <= end;
        });

      if (incentiveTxs.length > 0) {
        const total = incentiveTxs.reduce((sum, tx) => sum + tx.amount, 0);
        officerIncentives.set(officer.id, {
          officer,
          total,
          transactions: incentiveTxs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        });
      }
    });

    const sortedReport = Array.from(officerIncentives.values()).sort((a, b) => b.total - a.total);
    const grandTotal = sortedReport.reduce((sum, item) => sum + item.total, 0);

    return {
      startDate,
      endDate,
      grandTotal,
      officers: sortedReport
    };
  });
  
  constructor() {
    this.oneMonthAgo.setMonth(this.oneMonthAgo.getMonth() - 1);
    this.reportForm.get('startDate')?.setValue(this.oneMonthAgo.toISOString().split('T')[0]);
    this.generateReport(); // Generate initial report on load
  }

  getLevelTitle(level: number): string {
    return this.officerLevels().find(l => l.level === level)?.title || `Level ${level}`;
  }

  generateReport() {
    if (this.reportForm.valid) {
      this.dateRange.set(this.reportForm.value as {startDate: string, endDate: string});
    }
  }

  goBack() {
    this.navigate.emit();
  }
}