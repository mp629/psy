import { Component, ChangeDetectionStrategy, input, output, inject, effect } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-coin-price-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './coin-price-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CoinPriceManagementComponent {
  currentPrice = input.required<number>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  priceUpdate = output<number>();

  private fb: FormBuilder = inject(FormBuilder);

  priceForm = this.fb.group({
    price: [null as number | null, [Validators.required, Validators.min(0.01)]],
  });

  constructor() {
    effect(() => {
      this.priceForm.patchValue({ price: this.currentPrice() });
    });
  }

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.priceForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  onSubmit() {
    if (this.priceForm.invalid) {
      this.priceForm.markAllAsTouched();
      return;
    }
    const newPrice = this.priceForm.value.price!;
    this.priceUpdate.emit(newPrice);
    alert('PSY Coin price updated successfully!');
    this.priceForm.markAsPristine();
  }
}
