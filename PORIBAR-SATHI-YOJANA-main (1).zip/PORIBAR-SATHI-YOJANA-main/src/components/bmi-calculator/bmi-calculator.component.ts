
import { Component, ChangeDetectionStrategy, Output, EventEmitter, inject, signal, computed, input } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';

interface RecommendedAction {
  title: string;
  description: string;
  icon: string;
  action: string;
}

@Component({
  selector: 'app-bmi-calculator',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './bmi-calculator.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BmiCalculatorComponent {
  @Output() navigate = new EventEmitter<string>();
  appLogoUrl = input<string | null>(null);

  private fb: FormBuilder = inject(FormBuilder);

  bmiResult = signal<number | null>(null);

  bmiForm = this.fb.group({
    height: [null as number | null, [Validators.required, Validators.min(50), Validators.max(250)]],
    weight: [null as number | null, [Validators.required, Validators.min(10), Validators.max(300)]],
  });

  bmiCategory = computed(() => {
    const bmi = this.bmiResult();
    if (bmi === null) return null;

    if (bmi < 18.5) return 'Underweight';
    if (bmi >= 18.5 && bmi < 25) return 'Normal weight';
    if (bmi >= 25 && bmi < 30) return 'Overweight';
    return 'Obesity';
  });
  
  bmiCategoryColor = computed(() => {
    const category = this.bmiCategory();
    switch (category) {
      case 'Underweight': return 'text-blue-500';
      case 'Normal weight': return 'text-green-500';
      case 'Overweight': return 'text-yellow-500';
      case 'Obesity': return 'text-red-500';
      default: return '';
    }
  });

  recommendedActions = computed<RecommendedAction[]>(() => {
    const category = this.bmiCategory();
    if (!category) return [];

    switch (category) {
      case 'Normal weight':
        return [
          { title: 'Daily Health Tips', description: 'Get tips for a healthy lifestyle.', icon: 'lightbulb', action: 'health_tips' }
        ];
      case 'Underweight':
      case 'Overweight':
      case 'Obesity':
        return [
          { title: 'Book an Appointment', description: 'Schedule a visit to a local clinic.', icon: 'event', action: 'book_appointment' },
          { title: 'Video Consultation', description: 'Consult with a doctor remotely.', icon: 'videocam', action: 'video_consult' }
        ];
      default:
        return [];
    }
  });

  goBack() {
    this.navigate.emit('health');
  }

  isInvalid(controlName: string): boolean {
    const control = this.bmiForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }

  calculateBmi() {
    if (this.bmiForm.invalid) {
      this.bmiForm.markAllAsTouched();
      return;
    }

    const { height, weight } = this.bmiForm.value;
    if (height && weight) {
      const heightInMeters = height / 100;
      const bmi = weight / (heightInMeters * heightInMeters);
      this.bmiResult.set(parseFloat(bmi.toFixed(2)));
    }
  }

  onActionClick(action: RecommendedAction) {
    this.navigate.emit(`coming_soon:${action.title}`);
  }
}
