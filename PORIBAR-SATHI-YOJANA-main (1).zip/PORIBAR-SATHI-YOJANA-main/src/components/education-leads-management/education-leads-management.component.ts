import { Component, ChangeDetectionStrategy, input, output, signal, computed } from '@angular/core';
import { EducationLead } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-education-leads-management',
  standalone: true,
  imports: [TranslatePipe],
  templateUrl: './education-leads-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EducationLeadsManagementComponent {
  educationLeads = input.required<EducationLead[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  updateLeadStatus = output<string>();

  filter = signal<'all' | 'Pending' | 'Contacted'>('Pending');

  sortedLeads = computed(() => {
    return [...this.educationLeads()].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });

  filteredLeads = computed(() => {
    const currentFilter = this.filter();
    if (currentFilter === 'all') {
      return this.sortedLeads();
    }
    return this.sortedLeads().filter(lead => lead.status === currentFilter);
  });

  goBack() {
    this.navigate.emit();
  }

  setFilter(newFilter: 'all' | 'Pending' | 'Contacted') {
    this.filter.set(newFilter);
  }

  onMarkAsContacted(leadId: string) {
    this.updateLeadStatus.emit(leadId);
  }
}
