import { Component, ChangeDetectionStrategy, input, output, signal, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Hospital } from '../../app.component';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-hospital-management',
  standalone: true,
  imports: [ReactiveFormsModule, TranslatePipe],
  templateUrl: './hospital-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HospitalManagementComponent {
  hospitals = input.required<Hospital[]>();
  appLogoUrl = input<string | null>(null);
  navigate = output<void>();
  createHospital = output<Omit<Hospital, 'id'>>();
  updateHospital = output<Hospital>();
  deleteHospital = output<string>();

  private fb: FormBuilder = inject(FormBuilder);
  
  editingHospital = signal<Hospital | null>(null);

  hospitalForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(5)]],
    address: ['', [Validators.required]],
    latitude: [null as number | null, [Validators.required, Validators.min(-90), Validators.max(90)]],
    longitude: [null as number | null, [Validators.required, Validators.min(-180), Validators.max(180)]],
    ambulancePhone: ['', [Validators.required, Validators.pattern('^[0-9\\s,-]+$')]],
    type: ['Government' as 'Government' | 'Private', [Validators.required]],
  });

  goBack() {
    this.navigate.emit();
  }

  isInvalid(controlName: string): boolean {
    const control = this.hospitalForm.get(controlName);
    return !!control && control.invalid && (control.dirty || control.touched);
  }
  
  onEdit(hospital: Hospital) {
    this.editingHospital.set(hospital);
    this.hospitalForm.patchValue(hospital);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  onCancelEdit() {
    this.editingHospital.set(null);
    this.hospitalForm.reset({ type: 'Government' });
  }

  onDelete(id: string) {
    if (confirm('Are you sure you want to delete this hospital record?')) {
      this.deleteHospital.emit(id);
    }
  }

  onSubmit() {
    if (this.hospitalForm.invalid) {
      this.hospitalForm.markAllAsTouched();
      return;
    }

    const formValue = this.hospitalForm.getRawValue();

    if (this.editingHospital()) {
      const updatedHospital: Hospital = {
        ...this.editingHospital()!,
        ...formValue,
      };
      this.updateHospital.emit(updatedHospital);
    } else {
      this.createHospital.emit(formValue as Omit<Hospital, 'id'>);
    }
    this.onCancelEdit();
  }
}
