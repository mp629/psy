import { Pipe, PipeTransform, inject } from '@angular/core';
import { LanguageService } from '../services/language.service';

@Pipe({
  name: 'translate',
  standalone: true,
  pure: false // Important for reacting to language changes
})
export class TranslatePipe implements PipeTransform {
  private languageService = inject(LanguageService);

  transform(value: string, args?: any): string {
    if (!value) {
      return '';
    }
    let translated = this.languageService.translate(value);
    
    // Basic interpolation
    if (args) {
        Object.keys(args).forEach(key => {
            const regex = new RegExp(`{{${key}}}`, 'g');
            translated = translated.replace(regex, args[key]);
        });
    }
    
    return translated;
  }
}